# Publicar J-GAMES STUDIO en GitHub Pages

## Opción recomendada: repositorio público gratuito

1. Crea una cuenta en GitHub.
2. Crea un repositorio público, por ejemplo `j-games-studio`.
3. Descomprime este ZIP y sube el contenido de la carpeta raíz al repositorio. `index.html` debe quedar en la raíz.
4. En el repositorio abre **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**.
6. Elige la rama `main` y la carpeta `/ (root)`.
7. Guarda. GitHub mostrará la URL cuando termine el despliegue.

El archivo `.nojekyll` ya está incluido para publicar los HTML, CSS y JavaScript directamente.

## Actualizaciones

Sustituye o modifica archivos en el repositorio y confirma los cambios. GitHub Pages vuelve a desplegar automáticamente.

## Registro y economía

El perfil actual es una demo local basada en `localStorage`. Cada navegador tiene su propio perfil, saldo e historial. Para cuentas reales, IDs correlativas, recompensas administradas a distancia y sincronización entre dispositivos se necesita un backend con autenticación y base de datos, por ejemplo Supabase o Firebase.

## Formulario de soporte

El formulario abre Gmail con el destinatario, asunto y contenido preparados. No existe envío silencioso porque el sitio es estático y no incluye servidor de correo.