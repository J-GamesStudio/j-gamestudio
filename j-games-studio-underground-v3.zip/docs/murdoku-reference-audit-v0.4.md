# DETECTIVE BLACK — Auditoría del corpus Murdoku de referencia

**Build:** v0.4  
**Material analizado:** 14 parejas de puzzle + solución facilitadas por el usuario  
**Uso:** calibración lógica, editorial y de dificultad. No se redistribuye arte ni contenido oficial.

## Corpus revisado

| Expediente de referencia | Dificultad declarada |
|---|---|
| A Walk in the Park | Easy |
| Car Repair | Easy |
| Netflix and Kill | Easy |
| The Backyard Garden | Easy |
| The Courtroom | Easy |
| Preppers | Medium |
| The Art School | Medium |
| Sleeping with the Fishes | Hard |
| The Botanical Garden | Hard |
| The Hiking Trip | Hard |
| The Golf Course | Expert |
| The Movie Studio | Expert |
| The Mystery Islands | Expert |
| The Zoo | Expert |

## Conclusiones de diseño

### 1. La dificultad no depende solo del tamaño

Los ejemplos sencillos utilizan tableros compactos y varias pistas que fijan objetos, áreas o posiciones de soledad. Sin embargo, también existen tableros visualmente grandes cuya resolución sigue siendo accesible porque ofrecen colocaciones directas. En los casos avanzados, la dificultad crece por la combinación de restricciones, no únicamente por añadir filas y columnas.

### 2. Curva de aprendizaje observada

- **Easy:** objetos ocupables únicos, áreas concretas, “solo en”, “junto a” y cadenas cortas de bloqueo de fila/columna.
- **Medium:** primeras negaciones, zonas similares, objetos repetidos y necesidad de combinar dos testimonios antes de colocar.
- **Hard:** relaciones entre personas, recuentos por área, pistas generales que afectan a varios sujetos y cadenas largas sin una colocación inicial evidente.
- **Expert:** múltiples reglas globales, relaciones encadenadas, densidad alta, grupos o categorías de personajes y explicaciones de muchas etapas.

### 3. Qué hace que una pista sea buena

Una pista eficaz tiene una interpretación geométrica exacta, reduce candidatos de forma visible y participa en una cadena posterior. Las mejores soluciones explican por qué una posición queda aislada y cómo ese bloqueo fuerza la siguiente. Las pistas ambiguas o puramente narrativas no deben entrar en el motor.

### 4. Vocabulario lógico que adoptamos

- Una persona por fila y columna.
- Adyacencia ortogonal, nunca diagonal, dentro de la misma área.
- Diferencia explícita entre objetos ocupables y bloqueados.
- Relaciones de área, dirección, soledad y negación.
- El culpable es la única persona que comparte el área de la víctima.

### 5. Decisiones para DETECTIVE BLACK

- El contenido será completamente original: escenarios, personajes, textos, objetos, geometría y soluciones.
- Muy Fácil y Fácil introducirán una técnica nueva por caso, no una acumulación abrupta.
- Normal incorporará intersecciones de restricciones y objetos repetidos.
- Difícil y Experto usarán pistas globales y relaciones cruzadas, pero siempre con lenguaje cerrado y comprobable.
- Cada caso pasará por Solver exhaustivo, Solver humano y una explicación editorial antes de publicarse.

## Aplicación en v0.4

- **Caso 02 — Habitación seis:** objetos directos, una adyacencia y una pista de soledad.
- **Caso 03 — Última función:** primera negación explícita y adyacencia cuyo valor aparece después de bloquear una fila.
- **Caso 04 — Humo en el archivo:** primer tablero 7×7, áreas visualmente parecidas y primera relación entre dos personas.

## Límite de referencia

Esta auditoría estudia el lenguaje del rompecabezas y su progresión. Ningún expediente oficial, personaje, ilustración, texto, colocación o solución se incorpora a DETECTIVE BLACK.
