# TRI-ANGLE SHIP — versión 0.14

## Bloque: Órbita terrestre

La campaña dispone ahora de nueve fases definitivas.

### Fase 8 — Ruinas orbitales

- mundo de 5700 × 2400 unidades;
- roca combinada con restos metálicos de estaciones;
- cinco torretas antiguas con proyectiles dirigidos lentos;
- seis minas de proximidad;
- tres puertas destructibles que requieren el cañón;
- dos zonas de interferencia de navegación;
- rutas alternativas, corrientes y meteoritos;
- satélites y estructuras orbitales destruidas.

### Fase 9 — Última órbita

- mundo de 6600 × 2800 unidades;
- Tierra visible y creciente al fondo;
- gravedad terrestre progresiva según la aproximación;
- escombros rápidos destructibles e indestructibles;
- cinco plataformas orbitales móviles;
- tres defensas antiguas, cuatro minas y dos puertas;
- anomalías, corrientes y combustible ajustado;
- preparación mecánica y visual para la fase final.

### Sistemas incorporados

- torretas con puntería y anticipación básica;
- proyectiles enemigos que pueden interceptarse;
- minas armadas por proximidad y destruibles;
- estructuras destructibles con integridad y puntuación protegida;
- radar degradado dentro de zonas de interferencia;
- materiales diferenciados para roca y metal;
- plataformas orbitales móviles;
- gravedad dinámica y fondo terrestre.

La fase 10, el final, el TOP 100 y los cofres se desarrollarán en los siguientes bloques.
