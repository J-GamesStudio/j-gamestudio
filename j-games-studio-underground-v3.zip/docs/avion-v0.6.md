# AVIÓN — versión 0.6

Nombre provisional del Proyecto 005.

## Mecánica

- La nave triangular se orienta hacia el cursor.
- Mantener clic o barra espaciadora activa el propulsor.
- La gravedad y la inercia permanecen activas durante el vuelo.
- Chocar con paredes, límites, compuertas o pinchos destruye la nave.
- La plataforma verde es la salida y la roja es la meta.
- Para aterrizar deben controlarse velocidad horizontal, velocidad vertical y orientación.

## Contenido actual

Cinco niveles: Despegue, Corredor, Aguja, Pulso y Memoria. El progreso y las mejores marcas se guardan localmente.

## Pendiente

Ajuste fino de dificultad, más circuitos, elección del nombre definitivo, estadísticas ampliadas y posibles modos de contrarreloj.
