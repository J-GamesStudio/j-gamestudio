# TRI-ANGLE SHIP v0.17 — Final Balance & Arcade Polish

## Objetivo

Último bloque grande previo a la evaluación 1.0. La versión aplica un perfil de equilibrio único a las diez fases y valida el flujo completo de la recreativa.

## Equilibrio

- Perfil `FINAL-0.17` para consumo de fuel, empuje, tiempos objetivo y tolerancias de aterrizaje.
- Ajustes específicos para las fases 2, 7, 9 y 10.
- STATION 07-B restaura 100 % de fuel.
- STATION 10-A, 10-B y 10-C restauran 100 %, 88 % y 58 % respectivamente.
- Las celdas restauran entre 10 % y 12 % según fase.
- Cada celda vale 1.250 puntos y reunir las tres concede 4.500 adicionales.
- Penalización por muerte: 650 puntos.
- Bonus temporal limitado para que el score dependa principalmente de precisión, exploración y supervivencia.
- Farming bloqueado mediante identificadores persistentes de amenazas puntuadas.

## Presentación

- Ambiente musical sintetizado y opcional.
- Transiciones de fase y checkpoint dentro del CRT.
- CRT reajustado para conservar legibilidad.
- Barra de repostaje con flujo animado.
- Acabados Dorado y Rainbow Foil reforzados.
- Ocho registros iniciales de máquina en el TOP 100.

## Validación

Se comprobó mediante navegador sin interfaz:

- carga de las diez fases;
- configuración de fuel, checkpoints y aterrizaje;
- inserción de 100 JCOIN;
- menú y High Scores;
- sobrecarga y recuperación del cañón;
- recarga de combustible;
- registro de nombre;
- TOP 100 y Cargo Recovery;
- desbloqueo persistente de color;
- renderizado de todas las fases;
- ausencia de errores JavaScript;
- diseño móvil sin desbordamiento horizontal.

La validación automatizada no sustituye una partida humana completa de equilibrio fino. La versión permanece al 99 % hasta realizar esa última prueba de juego.
