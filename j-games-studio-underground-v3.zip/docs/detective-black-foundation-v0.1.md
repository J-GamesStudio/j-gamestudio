# DETECTIVE BLACK — Foundation v0.1

## Project 006

Primera build navegable del proyecto. Todavía no contiene ninguno de los diez casos completos.

## Alcance completado

- Branding definitivo `BLACK ARCHIVE`.
- Integración de Project 006 en J-GAMES STUDIO.
- Portada propia de DETECTIVE BLACK.
- Catálogo de diez expedientes con dificultad y tamaño previstos.
- Reglas interactivas en cuatro bloques.
- Shell responsive de investigación 6×6.
- Selección de sujeto, colocación, marcas X y candidatos.
- Historial de deshacer y rehacer.
- Guardado local de la shell y ajustes.
- Esquema JSON versionado.
- Rule Engine para ocupación, filas, columnas, áreas y pistas.
- Solver exhaustivo de unicidad.
- Human Logic Solver básico para colocaciones forzadas.
- Fixture interno de diagnóstico con una única solución y un único culpable.

## Archivos técnicos

- `assets/data/detective-black/case-schema-v1.json`
- `assets/data/detective-black/case-catalog.json`
- `assets/data/detective-black/foundation-fixture.json`
- `assets/js/detective-black/rule-engine.js`
- `assets/js/detective-black/solver.js`
- `assets/js/detective-black/app.js`

## Estado del Caso 01

`Turno de cierre` aparece como **En producción**, pero no se ha diseñado todavía su reparto, su geometría, sus pistas ni su solución. La shell utiliza sujetos y casillas de laboratorio para no revelar o fingir contenido del caso.

## Resultado del self-test

- Esquema: válido.
- Soluciones del fixture: 1.
- Unicidad: confirmada.
- Regla víctima-área: confirmada.
- Human Logic Solver: resuelve el fixture mediante cuatro colocaciones forzadas.

## Siguiente bloque

### Vertical Slice — Caso 01

- Diseñar `Turno de cierre` como caso original 6×6.
- Crear víctima, seis personajes, escena, áreas y objetos.
- Generar y reducir pistas hasta conservar una única solución.
- Integrar briefing, investigación completa, ayudas y acusación.
- Construir explicación paso a paso.
- Probar guardado, teclado, tacto y zoom al 200 %.
