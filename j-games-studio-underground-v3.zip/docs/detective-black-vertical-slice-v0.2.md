# DETECTIVE BLACK — Vertical Slice v0.2

## Project 006 / Bloque 2

El primer expediente real, **Caso 01 — Turno de cierre**, está implementado como una experiencia completa de principio a fin.

## Caso

- Dificultad: Muy fácil
- Tablero: 6×6
- Escenario: Minimercado Orfeo
- Áreas: Entrada, Cajas, Bebidas, Limpieza, Pasillo central y Almacén
- Personas: Clara Vega, Hugo Serrano, Mateo Rivas, Iris León, Darío Campos y Nora Vidal
- Víctima: Mateo Rivas
- Culpable: Iris León

## Pistas finales

1. Clara estaba sentada en el taburete de caja.
2. Hugo permanecía sobre el carro de reparto.
3. La cámara muestra a Mateo más al norte que Iris.
4. Iris permanecía en la zona de Limpieza.
5. Darío estaba más al norte que Nora.
6. Nora estaba más al oeste que Clara.

El Solver confirma que existe exactamente una reconstrucción incluso cuando la identidad del culpable no se utiliza como restricción. Al eliminar individualmente cualquiera de las seis pistas aparecen varias soluciones, por lo que todas son esenciales.

## Solución

- Clara: F1-C4
- Hugo: F2-C5
- Mateo: F3-C1
- Iris: F4-C2
- Darío: F5-C6
- Nora: F6-C3

Mateo e Iris son las únicas personas de la zona de Limpieza; Iris es la culpable.

## Funciones incluidas

- Briefing narrativo.
- Seis retratos vectoriales originales.
- Tablero 6×6 con seis regiones y dieciocho objetos.
- Modos Colocar, X y Candidatos.
- Bloqueo de fila y columna.
- Deshacer y rehacer.
- Comprobación de contradicciones.
- Tres capas de ayuda.
- Acusación interactiva.
- Reconstrucción de siete pasos.
- Resultado con rango, tiempo, ayudas y comprobaciones.
- Guardado y continuación mediante localStorage.
- Navegación por teclado y adaptación táctil.

## Diagnóstico

- Esquema: válido
- Soluciones: 1
- Unicidad: confirmada
- Pistas esenciales: 6/6
- Culpable por regla víctima-área: Iris León
- Pasos editoriales: 7
