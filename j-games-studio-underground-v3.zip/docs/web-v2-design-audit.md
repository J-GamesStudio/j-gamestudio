# J-GAMES STUDIO — Auditoría y rediseño Web V2

## Diagnóstico de la versión anterior

### 1. La portada no comunicaba el catálogo real

El hero utilizaba una pieza abstracta de archivo que funcionaba como decoración, pero no explicaba que ya existen cinco juegos terminados ni conectaba visualmente con sus proyectos.

### 2. La jerarquía se repetía demasiado

Las páginas utilizaban la misma combinación de título gigante, texto lateral y líneas divisorias. La identidad era sólida, pero el ritmo visual se volvía predecible al recorrer la web completa.

### 3. Las tarjetas seguían hablando de “desarrollo”

Todos los proyectos están al 100 %, pero las tarjetas continuaban dando protagonismo a una barra de progreso. El dato ya no aportaba diferenciación y transmitía una sensación de portfolio todavía provisional.

### 4. El archivo dependía demasiado del banner

La portada permitía reconocer visualmente el juego, pero faltaban datos navegables: número de proyecto, versión, familia, descripción breve y características principales.

### 5. El Devlog era correcto pero difícil de explorar

La cronología completa se presentaba como una sola columna larga, sin filtros ni lectura rápida por proyecto. TRI-ANGLE SHIP concentraba muchas entradas y hacía más difícil encontrar los lanzamientos anteriores.

### 6. La página Estudio resultaba demasiado breve

Explicaba el origen, pero no mostraba el método de trabajo, el estado del archivo ni los principios que conectan los proyectos.

### 7. La economía JCOIN no aparecía en el sitio principal

JCOIN ya conectaba varios juegos, pero esa continuidad no estaba representada fuera de ellos. La web parecía un contenedor de enlaces, no una capa común entre experiencias.

### 8. El pie de página era funcional pero poco editorial

No ofrecía accesos rápidos, información de estado ni una conclusión visual acorde con el resto del diseño.

## Cambios aplicados en Web V2

### Command Archive

La portada se reconstruye como un centro de control del archivo. El nuevo SVG conecta los cinco proyectos alrededor del emblema de J-GAMES y presenta TRI-ANGLE SHIP como señal destacada.

### Cabecera premium

- Contenedor flotante con cristal oscuro.
- Estado del archivo.
- Saldo JCOIN compartido y actualizado.
- Acceso directo al último lanzamiento.
- Barra superior de progreso de lectura.
- Menú móvil conservando navegación por teclado.

### Nueva portada

- Mensaje principal más directo: “Juegos con pulso propio”.
- Métricas reales del archivo.
- Ticker de proyectos.
- Consola editorial para el lanzamiento destacado.
- Vista previa de los otros cuatro juegos.
- Manifiesto y principios de diseño.
- Última entrada del Devlog integrada como pieza editorial.

### Tarjetas de proyecto V2

- Número de proyecto.
- Estado Release.
- Categoría y versión.
- Título, subtítulo y resumen.
- Etiquetas principales.
- Indicador de finalización más discreto.
- Capa de reproducción con estados hover, foco y táctil.
- Acento específico por proyecto sin abandonar la identidad negra, blanca y roja.

### Archivo filtrable

Los proyectos pueden filtrarse entre Arcade y Mesa/Colección. El resultado se actualiza sin recargar la página y mantiene controles nativos accesibles.

### Devlog V2

- Resumen de actividad.
- Filtros por proyecto.
- Secuencia visual numerada.
- Tipografía más contenida para poder recorrer muchas entradas.
- Mejora del texto de CARTAS para reflejar su estado final actual.

### Estudio V2

- Métricas del archivo.
- Historia ampliada.
- Método de tres etapas: recuerdo, sistema y release.
- Nueva banda cinética de influencias.
- Cierre editorial más fuerte.

### Footer V2

- Presentación de marca.
- Estado del archivo.
- Accesos al catálogo y a juegos destacados.
- Cierre técnico y editorial consistente en todas las páginas públicas.

## Accesibilidad y comportamiento

- Foco visible conservado.
- Botones de filtro con `aria-pressed`.
- Contenido accesible sin depender del hover.
- Respeto a `prefers-reduced-motion`.
- Estados táctiles para las tarjetas.
- Navegación móvil con cierre mediante Escape.
- Contraste reforzado en textos secundarios importantes.

## Alcance del rediseño

La V2 modifica la capa pública de J-GAMES STUDIO: Inicio, Proyectos, Devlog y Estudio. Los juegos conservan sus interfaces propias, porque su personalidad independiente forma parte del sistema de diseño del estudio.
