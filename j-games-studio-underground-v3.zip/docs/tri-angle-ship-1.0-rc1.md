# TRI-ANGLE SHIP 1.0 RC1 — Release Candidate

## Correcciones de lanzamiento

- Resultados de campaña separados de los récords históricos: las celdas y aterrizajes finales pertenecen únicamente a la partida actual.
- Eliminada la puntuación infinita por interceptar proyectiles recurrentes.
- Selector de fases bloqueado durante una campaña para impedir saltos y puntuaciones inválidas.
- Nueva persistencia de celdas, rangos y desglose de score por fase.
- El crédito temporal se invalida también al abandonar mediante el historial del navegador.
- Entradas de teclado y táctiles bloqueadas mientras hay un panel de fase o pausa abierto.
- Modo Arcade completamente controlable en móvil mediante cruceta táctil y disparo independiente.
- Datos guardados saneados y límites de tamaño para objetivos ya puntuados.

## Estado

La build se mantiene como Release Candidate hasta completar una campaña humana de extremo a extremo. Las pruebas estructurales, de persistencia, economía, metajuego, geometría y flujo no detectan bloqueos de lanzamiento.
