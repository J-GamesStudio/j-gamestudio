# TRI-ANGLE SHIP — versión 0.12

## Bloque Dominio

La campaña se amplía a seis fases reales.

- Fase 4: Cinturón muerto — patrones sincronizados de meteoritos destructibles e indestructibles.
- Fase 5: Cantera 9 — rutas divididas, compuertas y tres desprendimientos programados.
- Fase 6: Campo inverso — cuatro anomalías de atracción/repulsión y compuertas móviles.

## Sistemas

- trayectorias de meteoritos por ejes y rutas cerradas;
- fragmentos de derrumbe destructibles con puntuación protegida contra farming;
- núcleos gravitatorios con zona de influencia y núcleo mortal;
- radar ampliado para amenazas dinámicas;
- desglose de score por base, categoría, celdas, tiempo y supervivencia;
- bonus de supervivencia por superar una fase sin morir.

## Siguiente bloque

Fase 7 — Aguanta: gran ascenso vertical con mapa modular, un checkpoint de repostaje y progresión de dificultad por tramos.
