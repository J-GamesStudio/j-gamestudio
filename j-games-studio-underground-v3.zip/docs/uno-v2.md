# UNO — V2

## Estado

- Proyecto 003.
- Versión 1.0.
- Progreso editorial: 100%.
- Juego estático sin dependencias externas.

## Reglas implementadas

- Baraja de 108 cartas.
- Cuatro colores adaptados a J-GAMES: blanco, negro, gris y rojo.
- 7 cartas iniciales por jugador.
- Partidas de 2 a 10 jugadores.
- Coincidencia por color, número o símbolo.
- Robo voluntario aunque exista una jugada válida.
- Tras robar, solo puede jugarse la carta recién robada.
- Chúpate 2, Reversa, Saltar turno, Elige color y Chúpate 4.
- Restricción legal del Chúpate 4.
- Sistema de desafío del Chúpate 4 contra los NPC.
- Declaración de UNO y penalización de dos cartas.
- Reposición de la pila de robo usando el descarte.
- Puntuación oficial: números por valor, acciones 20 y comodines 50.
- Ronda rápida y modo clásico a 500 puntos.
- Recompensa de un sobre para CARTAS si el usuario gana la partida.

## NPC

La partida selecciona al azar los rivales entre diez perfiles. Cada perfil modifica:

- preferencia de color;
- prioridad de acciones;
- conservación de comodines;
- presión sobre manos pequeñas;
- probabilidad de desafiar un +4;
- posibilidad de farol;
- posibilidad de olvidar declarar UNO;
- nivel de comportamiento caótico.

## No incluido todavía

Las reglas de la casa del documento original no están activas en la versión 1.0:

- UNO progresivo;
- Siete-0;
- descarte inmediato o Jump-In.

También quedan para una futura fase el sonido, un tutorial interactivo, estadísticas persistentes y animaciones cinemáticas específicas para cada carta de acción.
