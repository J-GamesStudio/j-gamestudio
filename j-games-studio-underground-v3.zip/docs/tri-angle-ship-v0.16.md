# TRI-ANGLE SHIP v0.16 — High Scores & Cargo Recovery

## TOP 100 local

- Identificador arcade de hasta seis caracteres.
- Entrada mediante teclado o controles en pantalla.
- Orden principal por score; tiempo y muertes resuelven empates.
- Color de casco utilizado en cada registro.
- Persistencia mediante localStorage.
- Destacado visual del nuevo récord.

## Cargo Recovery

Cada campaña completada concede un contenedor. La recompensa queda fijada antes de la animación para impedir repetir la tirada recargando la página.

- Naves comunes: 72 %.
- Naves raras: 23 %.
- Naves legendarias: 5 %.
- Dorado y Rainbow Foil tienen revelaciones especiales.
- No aparecen duplicados mientras quede algún acabado bloqueado.

## Hangar

El Hangar muestra 19 acabados, progreso por rareza, vista previa, color equipado e historial de las últimas recuperaciones.

## Persistencia

Se guardan por separado el TOP 100, el perfil del Hangar, las recompensas reclamadas, el nombre de piloto más reciente y la campaña activa.
