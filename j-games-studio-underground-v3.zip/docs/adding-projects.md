# Añadir un proyecto

## 1. Crear su carpeta

```text
projects/nombre-del-proyecto/index.html
```

Los estilos y scripts exclusivos del juego deben vivir en archivos propios dentro de `assets/css/` y `assets/js/`.

## 2. Añadir una portada

Guarda la portada en:

```text
assets/art/nombre-del-proyecto-cover.svg
```

También puede ser una imagen PNG, JPG o WebP.

## 3. Registrar el proyecto

Añade una entrada a `assets/js/projects-data.js`:

```js
{
  id: "nombre-del-proyecto",
  order: "002",
  title: "NOMBRE",
  subtitle: "Subtítulo",
  category: "categoria",
  categoryLabel: "Tipo de juego",
  status: "En desarrollo",
  progress: 40,
  version: "0.4",
  year: "2026",
  featured: false,
  description: "Descripción breve.",
  tags: ["tag 1", "tag 2"],
  seal: "Texto corto",
  cover: "assets/art/nombre-del-proyecto-cover.svg",
  url: "projects/nombre-del-proyecto/index.html"
}
```

La portada y el archivo de proyectos se actualizarán automáticamente.

## 4. Proyecto destacado

Solo una entrada debería usar:

```js
featured: true
```

Ese proyecto alimenta los botones principales y la portada.

## 5. Progreso

La barra utiliza automáticamente estas transiciones:

- 0–15%: rojo.
- 15–50%: rojo a amarillo.
- 50–79%: amarillo.
- 80–99%: amarillo a verde.
- 100%: verde.
