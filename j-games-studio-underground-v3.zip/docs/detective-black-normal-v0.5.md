# DETECTIVE BLACK — Normal v0.5

## Estado de la build

- Proyecto: 006
- Versión: 0.5
- Progreso editorial: 74 %
- Casos jugables: 6 / 10
- Bloque: Normal

## Caso 05 — El invernadero vacío

Tablero 7×7 ambientado en el Laboratorio Botánico Helios. Introduce objetos repetidos mediante cuatro taburetes de inspección y varios bancos. La pista de Alba no identifica una casilla concreta: debe combinarse con la relación de Celia y con los bloqueos de filas y columnas.

Sistemas principales:

- objetos del mismo tipo como conjunto lógico;
- áreas conectadas;
- una pista relacional entre Nora y Diego;
- cuatro pasos de contradicción controlada en el Solver humano;
- siete colocaciones y una acusación final.

Validación:

- solución global única;
- seis restricciones autorales;
- las seis restricciones son necesarias;
- culpable deducido: Diego Arce;
- Solver humano completado en siete colocaciones.

## Caso 06 — Noche de subasta

Primer tablero 8×8 del proyecto, ambientado en la Casa de Subastas Vértice. La escena utiliza relaciones directas entre sospechosos y mantiene pares de candidatos durante varios pasos.

Sistemas principales:

- ocho personajes;
- relaciones norte/sur y este/oeste;
- dos restricciones en el testimonio de Hugo;
- parejas iniciales para Hugo, Basilio, Darío y Clara;
- cinco pasos de contradicción controlada;
- ocho colocaciones y una acusación final.

Validación:

- solución global única;
- ocho restricciones activas;
- culpable deducido: Fabián Orbe;
- Solver humano completado en ocho colocaciones;
- tablero 8×8 válido y completamente ocupable según sus objetos y regiones.

## Case Engine v0.5

El Rule Engine incorpora cuatro relaciones nuevas para escenarios con objetos repetidos:

- `onObjectType`
- `notOnObjectType`
- `besideObjectType`
- `notBesideObjectType`

El generador de pistas del Case Tooling reconoce tipos repetidos y puede producir afirmaciones genéricas sin señalar un objeto individual.

La etiqueta de dificultad conserva dos valores: la categoría editorial declarada y la estimación heurística interna. La categoría de publicación requiere validación lógica y posteriormente prueba humana.

## Persistencia

La build utiliza el espacio `detective-black:v0.5`. Al abrirla por primera vez intenta migrar automáticamente investigaciones guardadas en v0.4, manteniendo el progreso de los Casos 01–04.

## Validaciones efectuadas

- JSON de los Casos 01–06 válido.
- Una única solución en cada expediente.
- Culpable deducido igual al declarado.
- Solver humano completado en los seis casos.
- JavaScript sin errores de sintaxis.
- Retratos SVG estructuralmente válidos.
- Enlaces y recursos locales presentes.
- ZIP comprobado sin errores.

La comodidad final del tablero 8×8 en móvil y la dificultad percibida de los dos casos Normales requieren prueba humana en navegador.
