# TRI-ANGLE SHIP — versión 0.9

> Nota: la versión 0.10 corrige la interpretación del audio. La alarma y el barrido pasan al cañón sobrecalentado; el fuel utiliza una transferencia mecánica sutil.

Primer bloque de la reconstrucción definitiva del Proyecto 005.

## Incluido

- máquina recreativa CRT y modo de demostración;
- pago de 100 JCOIN por sesión;
- menú principal;
- Nueva partida y Continuar;
- guardado local de campaña;
- Hangar con 19 acabados preparados;
- Ajustes persistentes;
- Modo Clásico y Modo Arcade;
- introducción narrativa;
- alarma progresiva de combustible;
- sonido sintetizado de recarga;
- score preliminar y penalización por muerte.

## Pendiente

- campaña definitiva de diez fases y mapas grandes;
- fase vertical Aguanta;
- meteoritos y disparo;
- anomalías gravitatorias avanzadas;
- ranking TOP 100;
- cofres y desbloqueo de colores;
- final de campaña y regreso a la Tierra.
