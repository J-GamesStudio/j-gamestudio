# TRI-ANGLE SHIP — versión 0.10

## Bloque 2: sistema de armas

- Cañón vectorial disponible con `Espacio` en ambos modos.
- En Modo Clásico también puede utilizarse el clic derecho.
- El fuego continuo aumenta la temperatura.
- Al alcanzar el límite aparece `OVERCHARGE! OVERCHARGE!`, suena una alarma original y el arma queda bloqueada.
- El cañón se enfría automáticamente; un barrido ascendente confirma `WEAPON READY`.
- La munición es ilimitada, pero la gestión térmica impide disparar de forma permanente.

## Meteoritos

- Los sectores prototipo 3–6 incluyen meteoritos móviles.
- Los pequeños pueden destruirse y conceden score una sola vez por campaña.
- Los fragmentos masivos son indestructibles y deben esquivarse.
- Las paredes y puntas normales se han rediseñado con aspecto de roca marrón fracturada.
- Las compuertas permanecen metálicas para mantener una lectura clara.

## Repostaje corregido

- El fuel ya no utiliza la alarma de sobrecarga.
- Al aterrizar en el muelle inicial aparece una barra con el nivel actual.
- La barra se llena progresivamente hasta 100 %.
- El sonido es un motor/bombeo mecánico sutil, no un barrido de escudo.

## Estado

Los seis circuitos actuales siguen siendo sectores de prueba. La campaña definitiva tendrá diez fases de mayor tamaño y cámara móvil.
