# TRI-ANGLE SHIP — versión 0.13

## Bloque Supervivencia: Fase 7 — Aguanta

- Mundo vertical de 1800 × 7600 unidades.
- Cámara con anticipación ascendente.
- Zigzags de roca, estalactitas laterales, corrientes y compuertas.
- Seis eventos de desprendimiento con fragmentos destructibles.
- Tres variaciones controladas de la fase.
- STATION 07-B al 61 % del ascenso.
- Checkpoint persistente en localStorage para la campaña activa.
- Reaparición en estación conservando tiempo de checkpoint y celdas obtenidas.
- Repostaje progresivo, score y tiempo visibles durante el servicio.

## Siguiente bloque

Fases 8 y 9: Ruinas orbitales y Última órbita. Se incorporarán torretas, minas, interferencias de radar, escombros orbitales, gravedad terrestre creciente y plataformas móviles.
