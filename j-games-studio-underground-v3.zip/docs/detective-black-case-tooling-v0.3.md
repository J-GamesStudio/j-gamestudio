# DETECTIVE BLACK — Case Tooling v0.3

## Resultado del bloque

La versión 0.3 incorpora una cadena interna de producción para construir los nueve expedientes restantes sin editar a ciegas los datos de cada caso.

### Herramientas

- Editor visual de regiones, suelo, bloqueos, objetos y posiciones de solución.
- Importación, edición, copia y descarga del JSON del caso.
- Generador de afirmaciones verdaderas a partir de la solución.
- Reductor greedy de pistas que mantiene una única solución.
- Informe individual de necesidad de pistas.
- Solver humano con candidato único, single oculto por fila/columna y contradicción controlada.
- Generador inicial de explicaciones basado en los pasos del Solver humano.
- Analizador de dificultad por dominios iniciales, relaciones, técnicas y bifurcaciones.
- Informe automático de esquema, solución, culpable, unicidad y búsqueda.

## Caso 01 — Turno de cierre

- Esquema: válido.
- Soluciones: 1.
- Culpable deducido: Iris.
- Pistas esenciales: 6 de 6.
- Pistas verdaderas generables: 51.
- Solver humano: 6 pasos.
- Dificultad estimada: MUY FÁCIL / score 29.
- Nodos de búsqueda: 15.

## Caso 02 — Habitación seis / borrador técnico

- Tablero: 6×6.
- Áreas: 6.
- Objetos: 19.
- Personajes: 6.
- Esquema: válido.
- Soluciones: 1.
- Culpable deducido: Diego.
- Solver humano: 6 pasos.
- Dificultad estimada: MUY FÁCIL / score 0.
- Pistas verdaderas generables: 53.
- Reducción greedy: 6 pistas autorales → 5 pistas.
- Pista detectada como redundante en el orden de reducción actual: clue-alma.

El borrador es lógicamente válido, pero no se considera un caso terminado. En el siguiente bloque se revisará el conjunto de pistas para que cada testimonio tenga valor editorial, se escribirán las ayudas, se crearán retratos y se realizará la prueba humana.

## Límites

El editor trabaja únicamente en memoria y exporta archivos; por seguridad no sobrescribe el proyecto desde el navegador. La etiqueta automática de dificultad es una señal de producción, no una certificación final. Los casos seguirán necesitando revisión humana.

## Siguiente bloque

**Muy fácil + Fácil v0.4**

1. Finalizar Caso 02 — Habitación seis.
2. Producir Caso 03 — Última función / 6×6.
3. Producir Caso 04 — Humo en el archivo / 7×7.
4. Calibrar el onboarding conjunto de los cuatro primeros expedientes.
