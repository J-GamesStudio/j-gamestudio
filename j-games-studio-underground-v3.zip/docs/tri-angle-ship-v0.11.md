# TRI-ANGLE SHIP — versión 0.11

## Bloque: Campaign Foundation

Esta versión transforma la prueba de una sola pantalla en el comienzo de la campaña definitiva.

### Sistemas incorporados

- mundos mayores que el viewport;
- cámara suave con anticipación basada en velocidad;
- puntero del Modo Clásico corregido para coordenadas de mundo;
- radar táctico con terreno, plataformas, celdas, meteoritos, nave y viewport;
- progreso de ruta dentro del HUD;
- fondo estelar con paralaje;
- plataformas de salida verdes y destino rojas;
- guardado separado de los antiguos circuitos prototipo.

### Campaña / Bloque I

1. **Señal de emergencia** — recorrido largo de introducción con cuatro cámaras.
2. **Galería quebrada** — ascensión progresiva entre pilares y roca afilada.
3. **Deriva** — corrientes, espacio abierto y primeros meteoritos móviles.

Las fases 4–6 formarán el siguiente bloque de desarrollo.
