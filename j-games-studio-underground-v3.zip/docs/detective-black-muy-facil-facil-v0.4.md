# DETECTIVE BLACK — Muy Fácil + Fácil v0.4

## Estado de la build

- Proyecto 006
- Versión 0.4
- Progreso editorial: 62 %
- Casos jugables: 4 / 10
- Dificultades disponibles: Muy Fácil y Fácil
- Tableros disponibles: 6×6 y 7×7

## Caso 01 — Turno de cierre

- Dificultad: Muy Fácil
- Matriz: 6×6
- Escenario: Minimercado Orfeo
- Personajes: 6
- Pistas: 6
- Solución global: única
- Reconstrucción: 7 etapas
- Técnica principal: objetos, direcciones y bloqueo de filas/columnas

## Caso 02 — Habitación seis

- Dificultad: Muy Fácil
- Matriz: 6×6
- Escenario: Hotel Mirador
- Personajes: 6
- Áreas: vestíbulo, recepción, habitación 6, pasillo, lavandería y caldera
- Pistas públicas: 5 testimonios de sospechosos + regla de la víctima
- Solución global: única
- Reconstrucción: 7 etapas
- Técnica principal: tres objetos ocupables, una adyacencia y soledad de área

El caso actúa como segundo tutorial: mantiene varias entradas directas, pero obliga a cerrar la cuadrícula para situar a la víctima y demostrar la acusación.

## Caso 03 — Última función

- Dificultad: Fácil
- Matriz: 6×6
- Escenario: Teatro Ámbar
- Personajes: 6
- Áreas: 7
- Pistas: 6
- Solución global: única
- Reconstrucción: 7 etapas
- Novedades: primera negación y primera adyacencia no inmediatamente resoluble

Damián está en el escenario, pero no junto al baúl de utilería. Esta negación elimina la posición tentadora y obliga a combinarla con los bloqueos anteriores.

## Caso 04 — Humo en el archivo

- Dificultad: Fácil
- Matriz: 7×7
- Escenario: Archivo Municipal
- Personajes: 7
- Áreas: 8
- Pistas: 6
- Solución global: única
- Reconstrucción: 8 etapas
- Novedades: primera relación entre personas, dos depósitos visualmente similares y mayor carga de lectura

La pista de Gala depende de Franco: debe encontrarse más al oeste que el vigilante. El jugador ya no puede resolver todos los testimonios de forma aislada.

## Onboarding conjunto

1. Caso 01 enseña colocación, fila, columna y acusación.
2. Caso 02 consolida objetos, adyacencia y soledad.
3. Caso 03 introduce negación y una deducción aplazada.
4. Caso 04 aumenta la matriz a 7×7 e introduce una relación cruzada.

La dificultad aumenta mediante técnicas, no mediante texto más confuso.

## Persistencia

Cada expediente utiliza un guardado independiente. Se conservan fichas, X, candidatos, historial, tiempo, ayudas, comprobaciones y resultado archivado. El jugador puede abandonar un caso, abrir otro y regresar sin mezclar estados.

## Validación técnica

Los cuatro expedientes cumplen:

- esquema válido;
- una persona por fila y columna;
- posiciones sobre casillas ocupables;
- pistas verdaderas en la solución;
- una única reconstrucción global;
- exactamente un culpable mediante la regla víctima-área;
- resolución completa por el Solver humano;
- explicación editorial vinculada a posiciones reales.

La clasificación de dificultad todavía deberá contrastarse con partidas humanas. El analizador automático sirve como señal interna, no como sustituto del test de jugadores.
