# NAVE — versión 0.8

Nombre provisional del Proyecto 005. El proyecto utiliza la ruta pública `projects/nave/`; los nombres técnicos `avion.js` y `avion.css` se conservan temporalmente mientras el título definitivo sigue abierto.

## Evolución visual

- Nave triangular de acero con núcleo verde.
- Muelles segmentados de atraque con balizas.
- Paredes industriales con paneles, remaches, conductos y bandas de peligro.
- Compuertas mecánicas, pinchos de acero y campos de fuerza.
- Interfaz de navegación verde, plateada y negra.

## Sistemas nuevos

- Combustible limitado por intento.
- Celdas de navegación opcionales en cada circuito.
- Valoración de aterrizaje S, A, B o C.
- Registro de mejor tiempo, mejor categoría y celdas obtenidas.
- Sexto circuito: Dique Vectorial.
- Zonas de corriente que alteran la trayectoria.
