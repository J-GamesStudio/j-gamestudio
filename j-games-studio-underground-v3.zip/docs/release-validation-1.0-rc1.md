# TRI-ANGLE SHIP 1.0 RC1 — Informe de validación

## Decisión

La compilación queda identificada como **1.0 RC1**, estado **Release candidate** y progreso **99 %**.

No se marca todavía como 1.0 final porque el equilibrio percibido, la duración real y la justicia de las diez fases requieren una campaña humana completa. Las pruebas automatizadas validan los sistemas, la persistencia y la transitabilidad estática, pero no sustituyen la valoración de un jugador.

## Flujo de campaña comprobado

Se ha recorrido mediante el núcleo real de la aplicación el flujo:

1. INSERT 100 JCOIN.
2. Menú principal.
3. Nueva partida e introducción.
4. Fases 01–10.
5. Resultado de campaña.
6. Nombre arcade.
7. TOP 100.
8. Cargo Recovery.
9. Desbloqueo persistente en Hangar.

La prueba verificó que el resultado final utiliza únicamente las celdas y categorías de la campaña actual, sin heredar estadísticas históricas del perfil.

## Guardado y continuidad

- Activación real de STATION 07-B mediante colisión de aterrizaje.
- Guardado de checkpoint, tiempo, score, fuel y progreso.
- Nueva sesión sin conservar el crédito arcade.
- Inserción de otros 100 JCOIN y Continuar desde STATION 07-B.
- Migración automática de partidas creadas por la versión 0.17 al nuevo esquema RC1.
- Persistencia separada para campaña, perfil, ajustes, Hangar y High Scores.

## Correcciones de lanzamiento

- Se cerró la selección manual de fases durante una campaña activa.
- Se eliminó la puntuación repetible por interceptar proyectiles enemigos regenerables.
- Los identificadores de objetivos puntuados se sanejan, deduplican y limitan.
- Los controles no actúan detrás de modales, pausas o transiciones.
- El Modo Arcade dispone de cruceta táctil completa y admite direcciones combinadas.
- El crédito se invalida al abandonar la página, incluyendo navegación conservada por la caché del navegador.
- El selector de fases de desarrollo ya no se publica en la interfaz final.
- La API interna de pruebas no se incluye en la compilación distribuida.

## Transitabilidad estática

Se comprobó una ruta continua con margen para la nave en los diez mapas. Longitudes aproximadas de las rutas encontradas:

| Fase | Ruta | Margen mínimo |
|---:|---:|---:|
| 1 | 2670 | 25 px |
| 2 | 2962 | 25 px |
| 3 | 3369 | 25 px |
| 4 | 4646 | 25 px |
| 5 | 4977 | 25 px |
| 6 | 5494 | 25 px |
| 7 | 8073 | 25,7 px |
| 8 | 6136 | 25 px |
| 9 | 7188 | 28,2 px |
| 10 | 10613 | 25 px |

Esta comprobación descarta cierres geométricos estáticos, pero no evalúa por sí sola la dificultad de amenazas móviles.

## Integridad técnica

- 10 documentos HTML sin identificadores duplicados.
- 11 hojas CSS con bloques equilibrados.
- 9 archivos JavaScript válidos mediante comprobación de sintaxis.
- 8 SVG válidos.
- Ninguna referencia local `href` o `src` rota.
- Inicialización, moneda, menú, Ajustes, Modo Arcade y controles táctiles probados sin excepciones.

## Validación pendiente para 1.0 final

- Campaña humana completa con Modo Clásico.
- Campaña humana completa o muestra representativa con Modo Arcade.
- Duración real por fase y campaña.
- Muertes percibidas como justas o injustas.
- Margen de fuel en ruta directa y ruta de 3 celdas.
- Comportamiento en un teléfono real.
- Ajuste de récords CPU usando resultados humanos reales.
