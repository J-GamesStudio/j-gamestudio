(() => {
  "use strict";
  const platform=window.JGS_PLATFORM;
  const register=document.querySelector("[data-register-form]");
  register?.addEventListener("submit",async event=>{
    event.preventDefault(); const status=register.querySelector("[data-register-status]"); const data=new FormData(register);
    if(data.get("password")!==data.get("confirm")){status.textContent="Las claves no coinciden.";return}
    try{status.textContent="Creando perfil local…";await platform.register({nick:data.get("nick"),email:data.get("email"),password:data.get("password"),keepSignedIn:data.get("keep")==="on"});location.href="profile.html"}catch(error){status.textContent=error.message||"No se pudo crear el perfil."}
  });
  const login=document.querySelector("[data-login-form]");
  login?.addEventListener("submit",async event=>{event.preventDefault();const status=login.querySelector("[data-login-status]");const data=new FormData(login);try{status.textContent="Comprobando perfil…";await platform.login({email:data.get("email"),password:data.get("password")});location.href="profile.html"}catch(error){status.textContent=error.message||"No se pudo iniciar sesión."}});
  const content=document.querySelector("[data-profile-content]"); const locked=document.querySelector("[data-profile-locked]");
  function renderProfile(){
    if(!content&&!locked)return; const s=platform.snapshot(); const active=Boolean(s.active&&s.profile); if(content)content.hidden=!active;if(locked)locked.hidden=active;if(!active)return;
    const set=(q,v)=>document.querySelectorAll(q).forEach(n=>n.textContent=v); const pad=(n,l)=>String(Math.max(0,Number(n)||0)).padStart(l,"0");
    set("[data-profile-nick]",s.profile.nick);set("[data-profile-id]",s.profile.id);set("[data-profile-email]",s.profile.email);set("[data-profile-coins]",pad(s.balance,4));set("[data-profile-score]",pad(s.score,6));
    const stats=platform.getStats();set("[data-profile-games]",stats.gamesPlayed);set("[data-profile-sessions]",stats.totalSessions);set("[data-profile-transactions]",stats.transactions);
    const list=document.querySelector("[data-history-list]"); if(list){const rows=platform.getHistory();list.innerHTML=rows.length?rows.map(row=>`<article class="history-row history-row--${row.kind}"><time>${new Date(row.at).toLocaleDateString("es-ES",{day:"2-digit",month:"2-digit",year:"2-digit"})}</time><div><strong>${escapeHtml(row.source)}</strong><small>${escapeHtml(row.reason)}</small></div><b>${row.amount>0?"+":""}${row.amount} ${row.kind==="jcoins"?"JC":"PTS"}</b></article>`).join(""):'<p class="history-empty">Todavía no hay movimientos.</p>'}
  }
  const escapeHtml=value=>String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  document.querySelector("[data-logout]")?.addEventListener("click",()=>{platform.logout();renderProfile()});
  document.querySelector("[data-delete-profile]")?.addEventListener("click",()=>{if(confirm("¿Eliminar el perfil local y todo su historial?")){platform.deleteProfile();renderProfile()}});
  window.addEventListener("jgs:platform-change",renderProfile);renderProfile();
})();