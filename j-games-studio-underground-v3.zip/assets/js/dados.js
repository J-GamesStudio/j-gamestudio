const dieTemplate = document.querySelector("#die-template");
const playerSide = document.querySelector("#player-side");
const npcSide = document.querySelector("#npc-side");
const battleTable = document.querySelector("#battle-table");
const rollButton = document.querySelector("#roll-button");
const gameMessage = document.querySelector("#game-message");
const roundNumber = document.querySelector("#round-number");
const resultModal = document.querySelector("#result-modal");
const restartButton = document.querySelector("#restart-button");
const soundToggle = document.querySelector("#sound-toggle");
const canvas = document.querySelector("#fx-canvas");
const ctx = canvas.getContext("2d");

const playerDice = [...document.querySelectorAll("[data-player-die]")];
const npcDice = [...document.querySelectorAll("[data-npc-die]")];

const ui = {
  playerTotal: document.querySelector("#player-total"),
  npcTotal: document.querySelector("#npc-total"),
  playerDieOne: document.querySelector("#player-die-one"),
  playerDieTwo: document.querySelector("#player-die-two"),
  npcDieOne: document.querySelector("#npc-die-one"),
  npcDieTwo: document.querySelector("#npc-die-two"),
  playerPips: [...document.querySelectorAll("#player-score-pips i")],
  npcPips: [...document.querySelectorAll("#npc-score-pips i")],
  history: [...document.querySelectorAll("#round-history i")],
  recordWins: document.querySelector("#record-wins"),
  recordLosses: document.querySelector("#record-losses"),
  resultTitle: document.querySelector("#result-title"),
  resultCopy: document.querySelector("#result-copy"),
  resultEmblem: document.querySelector("#result-emblem"),
  finalPlayerScore: document.querySelector("#final-player-score"),
  finalNpcScore: document.querySelector("#final-npc-score")
};

const rotations = {
  1: { x: 0, y: 0 },
  6: { x: 0, y: 180 },
  3: { x: 0, y: -90 },
  4: { x: 0, y: 90 },
  2: { x: -90, y: 0 },
  5: { x: 90, y: 0 }
};

const state = {
  playerScore: 0,
  npcScore: 0,
  history: [],
  busy: false,
  sound: true,
  audioContext: null,
  spin: 0,
  particles: [],
  record: readRecord()
};

function readRecord() {
  try {
    const parsed = JSON.parse(localStorage.getItem("jgames-dados-record") || "{}");
    return {
      wins: Number(parsed.wins) || 0,
      losses: Number(parsed.losses) || 0
    };
  } catch {
    return { wins: 0, losses: 0 };
  }
}

function saveRecord() {
  try {
    localStorage.setItem("jgames-dados-record", JSON.stringify(state.record));
  } catch {
    // El juego sigue funcionando aunque el navegador bloquee el almacenamiento local.
  }
}

function buildDice() {
  [...playerDice, ...npcDice].forEach((die, index) => {
    die.appendChild(dieTemplate.content.cloneNode(true));
    setDieValue(die, index % 2 === 0 ? 1 : 6, 0, true);
  });
}

function randomDie() {
  if (window.crypto?.getRandomValues) {
    const values = new Uint32Array(1);
    window.crypto.getRandomValues(values);
    return (values[0] % 6) + 1;
  }
  return Math.floor(Math.random() * 6) + 1;
}

function setDieValue(die, value, spin = 3, immediate = false) {
  const cube = die.querySelector(".die-cube");
  const base = rotations[value];
  const direction = Number(die.dataset.playerDie ?? die.dataset.npcDie ?? 0) % 2 === 0 ? 1 : -1;
  const xTurns = spin * 360 * direction;
  const yTurns = (spin + 1) * 360 * -direction;
  const zTilt = direction * (spin ? 9 : 0);

  if (immediate) cube.style.transition = "none";
  cube.style.transform = `rotateX(${xTurns + base.x}deg) rotateY(${yTurns + base.y}deg) rotateZ(${zTilt}deg)`;
  die.dataset.value = String(value);
  die.setAttribute("aria-label", `Dado con valor ${value}`);

  if (immediate) {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        cube.style.transition = "";
      });
    });
  }
}

function sleep(milliseconds) {
  return new Promise(resolve => window.setTimeout(resolve, milliseconds));
}

function setMessage(message, accent = false) {
  gameMessage.textContent = message;
  gameMessage.classList.toggle("is-accent", accent);
}

function initAudio() {
  if (!state.sound) return null;
  if (!state.audioContext) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return null;
    state.audioContext = new AudioContext();
  }
  if (state.audioContext.state === "suspended") state.audioContext.resume();
  return state.audioContext;
}

function tone(frequency, duration, options = {}) {
  const audio = initAudio();
  if (!audio || !state.sound) return;
  const oscillator = audio.createOscillator();
  const gain = audio.createGain();
  const now = audio.currentTime + (options.delay || 0);

  oscillator.type = options.type || "sine";
  oscillator.frequency.setValueAtTime(frequency, now);
  if (options.endFrequency) oscillator.frequency.exponentialRampToValueAtTime(options.endFrequency, now + duration);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(options.gain || 0.05, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

  oscillator.connect(gain);
  gain.connect(audio.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.03);
}

function noiseBurst(duration = 0.12, gainValue = 0.025) {
  const audio = initAudio();
  if (!audio || !state.sound) return;
  const length = Math.max(1, Math.floor(audio.sampleRate * duration));
  const buffer = audio.createBuffer(1, length, audio.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const source = audio.createBufferSource();
  const filter = audio.createBiquadFilter();
  const gain = audio.createGain();
  filter.type = "bandpass";
  filter.frequency.value = 760;
  filter.Q.value = 0.8;
  gain.gain.value = gainValue;
  source.buffer = buffer;
  source.connect(filter);
  filter.connect(gain);
  gain.connect(audio.destination);
  source.start();
}

function playShakeSound() {
  noiseBurst(.34, .022);
  [0, .12, .24, .36].forEach((delay, index) => tone(105 + index * 13, .07, { type: "triangle", gain: .035, delay }));
}

function playImpactSound(isNpc) {
  tone(isNpc ? 64 : 72, .28, { type: "sine", endFrequency: 42, gain: .085 });
  noiseBurst(.1, .035);
}

function playPointSound(winner) {
  if (winner === "player") {
    tone(330, .16, { type: "triangle", gain: .045 });
    tone(495, .22, { type: "triangle", gain: .05, delay: .12 });
    tone(660, .28, { type: "triangle", gain: .045, delay: .24 });
  } else if (winner === "npc") {
    tone(180, .24, { type: "sawtooth", endFrequency: 92, gain: .035 });
    tone(110, .32, { type: "sine", endFrequency: 58, gain: .06, delay: .12 });
  } else {
    tone(210, .18, { type: "square", gain: .022 });
    tone(210, .18, { type: "square", gain: .022, delay: .2 });
  }
}

function updateRecordUI() {
  ui.recordWins.textContent = state.record.wins;
  ui.recordLosses.textContent = state.record.losses;
}

function updateScores() {
  ui.playerPips.forEach((pip, index) => pip.classList.toggle("is-active", index < state.playerScore));
  ui.npcPips.forEach((pip, index) => pip.classList.toggle("is-active", index < state.npcScore));
  const nextRound = Math.min(state.playerScore + state.npcScore + 1, 5);
  roundNumber.textContent = String(nextRound).padStart(2, "0");
}

function updateHistory() {
  ui.history.forEach((slot, index) => {
    const result = state.history[index];
    slot.className = "";
    if (!result) {
      slot.textContent = "—";
      return;
    }
    slot.classList.add(result);
    slot.textContent = result === "player" ? "J" : result === "npc" ? "R" : "=";
  });
}

async function resetVisuals() {
  const sides = [playerSide, npcSide];
  sides.forEach(side => {
    side.classList.remove("is-shaking", "is-revealing", "is-impact", "is-round-winner", "is-round-loser");
    if (side.classList.contains("is-revealed")) {
      side.classList.remove("is-revealed");
      side.classList.add("is-resetting");
    }
  });
  ui.playerTotal.classList.remove("is-visible");
  ui.npcTotal.classList.remove("is-visible");
  await sleep(500);
  sides.forEach(side => side.classList.remove("is-resetting"));
}

async function animateRoll(side, dice, values, isNpc = false) {
  side.classList.remove("is-revealed", "is-revealing", "is-impact");
  side.classList.add("is-shaking");
  playShakeSound();
  if (navigator.vibrate) navigator.vibrate([18, 24, 18, 24, 28]);

  await sleep(900);
  side.classList.remove("is-shaking");
  side.classList.add("is-revealing");

  dice.forEach((die, index) => {
    die.classList.remove("is-rolling");
    void die.offsetWidth;
    die.classList.add("is-rolling");
    state.spin += 1;
    setDieValue(die, values[index], 3 + (state.spin % 2));
  });

  await sleep(570);
  side.classList.add("is-impact");
  battleTable.classList.remove("is-screen-hit");
  void battleTable.offsetWidth;
  battleTable.classList.add("is-screen-hit");
  playImpactSound(isNpc);
  burstAt(side.querySelector(".throw-zone"), isNpc ? "#d20d20" : "#f5f5f3", 28);

  await sleep(510);
  dice.forEach(die => die.classList.remove("is-rolling"));
  side.classList.remove("is-revealing", "is-impact");
  side.classList.add("is-revealed");
}

function revealValues(owner, values) {
  const total = values[0] + values[1];
  if (owner === "player") {
    ui.playerDieOne.textContent = values[0];
    ui.playerDieTwo.textContent = values[1];
    ui.playerTotal.textContent = total;
    ui.playerTotal.classList.add("is-visible");
  } else {
    ui.npcDieOne.textContent = values[0];
    ui.npcDieTwo.textContent = values[1];
    ui.npcTotal.textContent = total;
    ui.npcTotal.classList.add("is-visible");
  }
  return total;
}

async function playRound() {
  if (state.busy || resultModal.open) return;
  state.busy = true;
  rollButton.disabled = true;
  initAudio();

  await resetVisuals();

  const playerValues = [randomDie(), randomDie()];
  const npcValues = [randomDie(), randomDie()];

  setMessage("Los dados están en movimiento.");
  await animateRoll(playerSide, playerDice, playerValues, false);
  const playerTotal = revealValues("player", playerValues);
  setMessage(`Tu suma es ${playerTotal}. El rival prepara su lanzamiento.`);

  await sleep(650);
  setMessage("El rival lanza sus dados...", true);
  await animateRoll(npcSide, npcDice, npcValues, true);
  const npcTotal = revealValues("npc", npcValues);

  await sleep(420);
  let winner = "tie";
  if (playerTotal > npcTotal) winner = "player";
  if (npcTotal > playerTotal) winner = "npc";

  if (winner === "player") {
    state.playerScore += 1;
    state.history.push("player");
    state.history = state.history.slice(-5);
    playerSide.classList.add("is-round-winner");
    npcSide.classList.add("is-round-loser");
    document.body.classList.add("is-player-win");
    setMessage(`Punto para ti: ${playerTotal} supera a ${npcTotal}.`);
    burstAt(playerSide, "#f5f5f3", 54);
  } else if (winner === "npc") {
    state.npcScore += 1;
    state.history.push("npc");
    state.history = state.history.slice(-5);
    npcSide.classList.add("is-round-winner");
    playerSide.classList.add("is-round-loser");
    document.body.classList.add("is-npc-win");
    setMessage(`Punto para el rival: ${npcTotal} supera a ${playerTotal}.`, true);
    burstAt(npcSide, "#d20d20", 54);
  } else {
    state.history.push("tie");
    state.history = state.history.slice(-5);
    setMessage(`Empate a ${playerTotal}. Nadie conquista el punto.`);
    burstAt(battleTable, "#9d9da3", 32);
  }

  playPointSound(winner);
  updateScores();
  updateHistory();
  window.setTimeout(() => document.body.classList.remove("is-player-win", "is-npc-win"), 650);

  await sleep(1250);
  if (state.playerScore === 3 || state.npcScore === 3) {
    finishMatch(state.playerScore === 3 ? "player" : "npc");
    return;
  }

  rollButton.querySelector("strong").textContent = "SIGUIENTE RONDA";
  rollButton.disabled = false;
  state.busy = false;
}

function finishMatch(winner) {
  state.busy = false;
  rollButton.disabled = true;
  ui.finalPlayerScore.textContent = state.playerScore;
  ui.finalNpcScore.textContent = state.npcScore;

  if (winner === "player") {
    state.record.wins += 1;
    ui.resultTitle.textContent = "Victoria";
    ui.resultCopy.textContent = "Has dominado la mesa y alcanzado tres puntos antes que el rival.";
    ui.resultEmblem.textContent = "J";
    burstAt(battleTable, "#f5f5f3", 100);
    tone(330, .25, { type: "triangle", gain: .06 });
    tone(495, .32, { type: "triangle", gain: .06, delay: .15 });
    tone(660, .5, { type: "triangle", gain: .055, delay: .3 });
  } else {
    state.record.losses += 1;
    ui.resultTitle.textContent = "Derrota";
    ui.resultCopy.textContent = "El rival ha reclamado la mesa. La revancha está lista.";
    ui.resultEmblem.textContent = "◆";
    burstAt(battleTable, "#d20d20", 100);
    tone(160, .35, { type: "sawtooth", endFrequency: 70, gain: .045 });
    tone(75, .65, { type: "sine", endFrequency: 42, gain: .075, delay: .18 });
  }

  saveRecord();
  updateRecordUI();
  window.setTimeout(() => resultModal.showModal(), 420);
}

async function restartMatch() {
  resultModal.close();
  state.playerScore = 0;
  state.npcScore = 0;
  state.history = [];
  state.busy = true;
  updateScores();
  updateHistory();
  ui.playerDieOne.textContent = "–";
  ui.playerDieTwo.textContent = "–";
  ui.npcDieOne.textContent = "–";
  ui.npcDieTwo.textContent = "–";
  ui.playerTotal.textContent = "--";
  ui.npcTotal.textContent = "--";
  rollButton.querySelector("strong").textContent = "LANZAR DADOS";
  await resetVisuals();
  setMessage("La mesa está lista.");
  rollButton.disabled = false;
  state.busy = false;
  rollButton.focus();
}

soundToggle.addEventListener("click", () => {
  state.sound = !state.sound;
  soundToggle.setAttribute("aria-pressed", String(state.sound));
  soundToggle.querySelector(".sound-copy").textContent = state.sound ? "SONIDO ON" : "SONIDO OFF";
  soundToggle.querySelector(".sound-icon").textContent = state.sound ? "◖))" : "◖×";
  if (state.sound) {
    initAudio();
    tone(420, .1, { type: "triangle", gain: .025 });
  }
});

rollButton.addEventListener("click", playRound);
restartButton.addEventListener("click", restartMatch);
resultModal.addEventListener("cancel", event => event.preventDefault());

window.addEventListener("keydown", event => {
  if (event.code !== "Space" || event.repeat) return;
  if (event.target.closest("button, a, input, textarea, select")) return;
  event.preventDefault();
  playRound();
});

function resizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(window.innerWidth * dpr);
  canvas.height = Math.floor(window.innerHeight * dpr);
  canvas.style.width = `${window.innerWidth}px`;
  canvas.style.height = `${window.innerHeight}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function burstAt(element, color, count = 36) {
  const rect = element.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 1.8 + Math.random() * 5.5;
    state.particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - Math.random() * 2.5,
      gravity: .08 + Math.random() * .08,
      life: 1,
      decay: .014 + Math.random() * .022,
      size: 2 + Math.random() * 5,
      color,
      rotation: Math.random() * Math.PI,
      spin: (Math.random() - .5) * .18
    });
  }
}

function animateParticles() {
  ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  state.particles = state.particles.filter(particle => particle.life > 0);

  state.particles.forEach(particle => {
    particle.x += particle.vx;
    particle.y += particle.vy;
    particle.vy += particle.gravity;
    particle.vx *= .992;
    particle.life -= particle.decay;
    particle.rotation += particle.spin;

    ctx.save();
    ctx.globalAlpha = Math.max(0, particle.life);
    ctx.translate(particle.x, particle.y);
    ctx.rotate(particle.rotation);
    ctx.fillStyle = particle.color;
    ctx.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size);
    ctx.restore();
  });

  requestAnimationFrame(animateParticles);
}

window.addEventListener("resize", resizeCanvas);

buildDice();
resizeCanvas();
animateParticles();
updateScores();
updateHistory();
updateRecordUI();
