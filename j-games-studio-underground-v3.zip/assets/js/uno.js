(() => {
  "use strict";

  const BONUS_PACK_KEY = "jgs-bonus-packs";
  const SETTINGS_KEY = "jgs-uno-v2-settings";
  const COLORS = ["white", "black", "gray", "red"];
  const COLOR_LABELS = { white: "Blanco", black: "Negro", gray: "Gris", red: "Rojo" };
  const CARD_POINTS = { draw2: 20, reverse: 20, skip: 20, wild: 50, wild4: 50 };
  const ACTION_LABELS = { draw2: "Chúpate 2", reverse: "Reversa", skip: "Saltar turno", wild: "Elige color", wild4: "Chúpate 4" };
  const ACTION_SYMBOLS = { draw2: "+2", reverse: "↺", skip: "⊘", wild: "W", wild4: "+4" };

  const NPC_PROFILES = Object.freeze([
    { id:"nyx", name:"Nyx Vale", role:"Control", copy:"Conserva acciones para cortar cierres rivales.", traits:["control","negro"], preference:{white:0,black:4,gray:1,red:0}, action:{draw2:2,reverse:3,skip:3,wild:-1,wild4:-2}, conserve:4, punish:3, bluff:.04, challenge:.58, forget:.03, chaos:.15 },
    { id:"scar", name:"Scar Riot", role:"Agresión", copy:"Castiga a la siguiente mano siempre que puede.", traits:["presión","rojo"], preference:{white:0,black:0,gray:0,red:5}, action:{draw2:5,reverse:1,skip:4,wild:0,wild4:3}, conserve:1, punish:5, bluff:.18, challenge:.32, forget:.12, chaos:.55 },
    { id:"mist", name:"Mist Halo", role:"Equilibrio", copy:"Reduce el color más abundante de su mano.", traits:["estable","gris"], preference:{white:2,black:0,gray:3,red:0}, action:{draw2:1,reverse:1,skip:1,wild:0,wild4:0}, conserve:2, punish:1, bluff:.02, challenge:.42, forget:.07, chaos:.2 },
    { id:"grit", name:"Grit Ash", role:"Bloqueo", copy:"Prioriza saltos y reversas para romper el orden.", traits:["bloqueo","gris"], preference:{white:0,black:1,gray:4,red:0}, action:{draw2:1,reverse:5,skip:5,wild:-1,wild4:0}, conserve:3, punish:3, bluff:.06, challenge:.55, forget:.06, chaos:.25 },
    { id:"lumen", name:"Lumen Fade", role:"Gestión de color", copy:"Busca mantener la mesa en el color que domina.", traits:["color","blanco"], preference:{white:5,black:0,gray:1,red:0}, action:{draw2:0,reverse:1,skip:1,wild:3,wild4:1}, conserve:3, punish:1, bluff:.01, challenge:.5, forget:.03, chaos:.12 },
    { id:"vanta", name:"Vanta Coil", role:"Reserva", copy:"Guarda comodines hasta el tramo final.", traits:["paciencia","negro"], preference:{white:0,black:5,gray:0,red:0}, action:{draw2:1,reverse:2,skip:2,wild:-3,wild4:-5}, conserve:6, punish:5, bluff:.03, challenge:.7, forget:.02, chaos:.08 },
    { id:"ember", name:"Ember Flux", role:"Impulso", copy:"Juega rápido y acepta riesgos poco eficientes.", traits:["rápida","rojo"], preference:{white:0,black:0,gray:0,red:4}, action:{draw2:4,reverse:2,skip:2,wild:1,wild4:2}, conserve:0, punish:2, bluff:.3, challenge:.25, forget:.15, chaos:1.1 },
    { id:"opal", name:"Opal Hex", role:"Depuración", copy:"Vacía grupos repetidos antes de usar acciones.", traits:["números","blanco"], preference:{white:3,black:0,gray:1,red:1}, action:{draw2:0,reverse:0,skip:1,wild:-1,wild4:-1}, conserve:4, punish:1, bluff:.02, challenge:.4, forget:.08, chaos:.18 },
    { id:"rune", name:"Rune Static", role:"Respuesta", copy:"Cambia de plan cuando alguien baja de tres cartas.", traits:["reactiva","cazadora"], preference:{white:1,black:1,gray:1,red:1}, action:{draw2:3,reverse:2,skip:3,wild:1,wild4:3}, conserve:2, punish:6, bluff:.12, challenge:.62, forget:.05, chaos:.34 },
    { id:"vox", name:"Vox Shade", role:"Caos", copy:"Alterna prioridades y provoca mesas impredecibles.", traits:["caos","farol"], preference:{white:1,black:1,gray:1,red:1}, action:{draw2:2,reverse:2,skip:2,wild:2,wild4:2}, conserve:0, punish:2, bluff:.42, challenge:.2, forget:.19, chaos:1.7 }
  ]);

  const ui = {
    lobby: document.getElementById("lobby-screen"),
    tableScreen: document.getElementById("table-screen"),
    npcCount: document.getElementById("npc-count"),
    npcCountValue: document.getElementById("npc-count-value"),
    gameMode: document.getElementById("game-mode"),
    reroll: document.getElementById("reroll-opponents-button"),
    start: document.getElementById("start-game-button"),
    leave: document.getElementById("leave-game-button"),
    opponentPreview: document.getElementById("opponent-preview"),
    earnedPacks: document.getElementById("uno-earned-packs"),
    roundNumber: document.getElementById("round-number"),
    scoreboard: document.getElementById("match-scoreboard"),
    boardOpponents: document.getElementById("board-opponents"),
    drawButton: document.getElementById("draw-pile-button"),
    drawCount: document.getElementById("draw-count"),
    discard: document.getElementById("discard-pile-display"),
    activeColor: document.getElementById("active-color-label"),
    activeColorDot: document.getElementById("active-color-dot"),
    direction: document.getElementById("turn-direction-label"),
    turnOwner: document.getElementById("turn-owner-label"),
    turnMessage: document.getElementById("turn-message"),
    turnSubmessage: document.getElementById("turn-submessage"),
    lastPlayed: document.getElementById("last-played-label"),
    handCount: document.getElementById("player-hand-count"),
    playerHand: document.getElementById("player-hand"),
    unoButton: document.getElementById("uno-call-button"),
    endTurn: document.getElementById("end-turn-button"),
    rosterCount: document.getElementById("active-roster-count"),
    roster: document.getElementById("roster-list"),
    eventLog: document.getElementById("event-log"),
    clearLog: document.getElementById("clear-log-button"),
    colorModal: document.getElementById("color-modal"),
    colorChoices: Array.from(document.querySelectorAll("[data-color-choice]")),
    challengeModal: document.getElementById("challenge-modal"),
    challengeCopy: document.getElementById("challenge-copy"),
    acceptDrawFour: document.getElementById("accept-draw-four-button"),
    challengeDrawFour: document.getElementById("challenge-draw-four-button"),
    rulesModal: document.getElementById("rules-modal"),
    showRules: document.getElementById("show-rules-button"),
    closeRules: document.getElementById("close-rules-button"),
    resultModal: document.getElementById("result-modal"),
    resultKicker: document.getElementById("result-kicker"),
    resultTitle: document.getElementById("result-title"),
    resultScore: document.getElementById("result-score"),
    resultCopy: document.getElementById("result-copy"),
    continueGame: document.getElementById("continue-game-button"),
    toast: document.getElementById("uno-toast")
  };

  const state = {
    mode: "quick",
    preview: [],
    players: [],
    deck: [],
    discard: [],
    activeColor: null,
    direction: 1,
    dealerIndex: 0,
    currentIndex: 0,
    round: 1,
    phase: "lobby",
    turnHasDrawn: false,
    drawnCardId: null,
    pendingColor: null,
    pendingChallenge: null,
    pendingNextIndex: null,
    actionLocked: false,
    dealAnimation: false,
    log: [],
    npcTimer: 0,
    unoTimer: 0,
    toastTimer: 0,
    resultAction: "new-match"
  };

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  function shuffle(items) {
    const result = [...items];
    for (let i = result.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  function loadSettings() {
    try {
      const parsed = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "null");
      return {
        npcCount: clamp(Number(parsed?.npcCount) || 3, 1, 9),
        mode: parsed?.mode === "classic" ? "classic" : "quick"
      };
    } catch {
      return { npcCount: 3, mode: "quick" };
    }
  }

  function saveSettings() {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({ npcCount: Number(ui.npcCount.value), mode: ui.gameMode.value }));
  }

  function getBonusPacks() {
    if (window.JGS_ECONOMY) return window.JGS_ECONOMY.getBonusPacks();
    const value = Number.parseInt(localStorage.getItem(BONUS_PACK_KEY) || "0", 10);
    return Number.isFinite(value) ? Math.max(0, value) : 0;
  }

  function awardPack() {
    if (window.JGS_ECONOMY) {
      window.JGS_ECONOMY.addBonusPacks(1);
    } else {
      localStorage.setItem(BONUS_PACK_KEY, String(getBonusPacks() + 1));
    }
    updatePackCounter();
  }

  function updatePackCounter() {
    ui.earnedPacks.textContent = String(getBonusPacks());
  }

  function showToast(message) {
    window.clearTimeout(state.toastTimer);
    ui.toast.textContent = message;
    ui.toast.hidden = false;
    state.toastTimer = window.setTimeout(() => { ui.toast.hidden = true; }, 2300);
  }

  function logEvent(message) {
    state.log.unshift(message);
    state.log = state.log.slice(0, 18);
    renderLog();
  }

  function setMessage(title, copy = "") {
    ui.turnMessage.textContent = title;
    ui.turnSubmessage.textContent = copy;
  }

  function createCard(type, color = null, value = null, serial = 0) {
    return { id: `${type}-${color || "wild"}-${value ?? "x"}-${serial}`, type, color, value };
  }

  function buildDeck() {
    const deck = [];
    let serial = 0;
    COLORS.forEach(color => {
      deck.push(createCard("number", color, 0, serial++));
      for (let number = 1; number <= 9; number += 1) {
        deck.push(createCard("number", color, number, serial++));
        deck.push(createCard("number", color, number, serial++));
      }
      ["draw2", "reverse", "skip"].forEach(type => {
        deck.push(createCard(type, color, null, serial++));
        deck.push(createCard(type, color, null, serial++));
      });
    });
    for (let copy = 0; copy < 4; copy += 1) {
      deck.push(createCard("wild", null, null, serial++));
      deck.push(createCard("wild4", null, null, serial++));
    }
    return shuffle(deck);
  }

  function cardLabel(card) {
    if (!card) return "—";
    if (card.type === "number") return `${COLOR_LABELS[card.color]} ${card.value}`;
    const name = ACTION_LABELS[card.type];
    return card.color ? `${name} ${COLOR_LABELS[card.color]}` : name;
  }

  function cardSymbol(card) {
    return card.type === "number" ? String(card.value) : ACTION_SYMBOLS[card.type];
  }

  function cardSubtitle(card) {
    if (card.type === "number") return "Carta numérica";
    return {
      draw2: "Roba 2 y pierde turno",
      reverse: "Invierte el sentido",
      skip: "Pierde el siguiente turno",
      wild: "Selecciona el color",
      wild4: "Color + roba cuatro"
    }[card.type];
  }

  function cardPoints(card) {
    return card.type === "number" ? card.value : CARD_POINTS[card.type];
  }

  function renderCard(card, options = {}) {
    const { entering = false, played = false, delay = 0 } = options;
    const colorClass = card.color ? `uno-card--${card.color}` : `uno-card--${card.type}`;
    const animationClass = entering ? " is-entering" : played ? " is-played" : "";
    return `<div class="uno-card ${colorClass}${animationClass}" style="--deal-delay:${delay}ms">
      <div class="uno-card__inner">
        <span class="uno-card__corner">${cardSymbol(card)}</span>
        <span class="uno-card__symbol">${cardSymbol(card)}</span>
        <span class="uno-card__corner uno-card__corner--bottom">${cardSymbol(card)}</span>
        <div class="uno-card__footer">
          <strong class="uno-card__color">${card.color ? COLOR_LABELS[card.color] : "Multicolor"}</strong>
          <span class="uno-card__subtitle">${cardSubtitle(card)}</span>
        </div>
      </div>
    </div>`;
  }

  function topCard() {
    return state.discard[state.discard.length - 1] || null;
  }

  function nextIndex(from, steps = 1, direction = state.direction) {
    const length = state.players.length;
    return (from + (steps * direction) % length + length) % length;
  }

  function ensureDeck() {
    if (state.deck.length > 0) return;
    if (state.discard.length <= 1) return;
    const top = state.discard.pop();
    state.deck = shuffle(state.discard);
    state.discard = [top];
    logEvent("La pila de robo se recompone con el descarte.");
  }

  function drawCards(player, amount) {
    const drawn = [];
    for (let i = 0; i < amount; i += 1) {
      ensureDeck();
      const card = state.deck.pop();
      if (!card) break;
      player.hand.push(card);
      drawn.push(card);
    }
    return drawn;
  }

  function hasColor(player, color, excludingCardId = null) {
    return player.hand.some(card => card.id !== excludingCardId && card.color === color);
  }

  function isPlayable(card, player, allowIllegalWildFour = false) {
    const top = topCard();
    if (!top) return true;
    if (card.type === "wild") return true;
    if (card.type === "wild4") return allowIllegalWildFour || !hasColor(player, state.activeColor, card.id);
    if (card.color === state.activeColor) return true;
    if (card.type === "number" && top.type === "number" && card.value === top.value) return true;
    return card.type !== "number" && top.type === card.type;
  }

  function playableCards(player) {
    return player.hand.filter(card => isPlayable(card, player));
  }

  function colorCounts(hand) {
    return hand.reduce((counts, card) => {
      if (card.color) counts[card.color] += 1;
      return counts;
    }, { white:0, black:0, gray:0, red:0 });
  }

  function chooseNpcColor(player) {
    const counts = colorCounts(player.hand);
    return COLORS.map(color => ({ color, score:(counts[color] * 6) + (player.profile.preference[color] || 0) }))
      .sort((a,b) => b.score - a.score)[0].color;
  }

  function chooseOpponents() {
    const count = Number(ui.npcCount.value);
    state.preview = shuffle(NPC_PROFILES).slice(0, count);
    renderPreview();
    saveSettings();
  }

  function renderPreview() {
    ui.npcCountValue.value = String(ui.npcCount.value);
    ui.npcCountValue.textContent = String(ui.npcCount.value);
    ui.opponentPreview.innerHTML = state.preview.map(profile => `<article class="selected-opponent">
      <span class="selected-opponent__role">${profile.role}</span>
      <h3>${profile.name}</h3>
      <p>${profile.copy}</p>
      <div class="selected-opponent__traits">${profile.traits.map(trait => `<span>${trait}</span>`).join("")}</div>
    </article>`).join("");
  }

  function createPlayers() {
    return [
      { id:"human", name:"TÚ", type:"human", hand:[], score:0, profile:null, saidUno:false },
      ...state.preview.map(profile => ({ id:`npc-${profile.id}`, name:profile.name, type:"npc", hand:[], score:0, profile, saidUno:false }))
    ];
  }

  function showLobby() {
    clearTimers();
    state.phase = "lobby";
    ui.tableScreen.hidden = true;
    ui.lobby.hidden = false;
    ui.resultModal.hidden = true;
    ui.challengeModal.hidden = true;
    ui.colorModal.hidden = true;
    setMessage("Configura la mesa.", "Elige rivales y formato antes de repartir.");
    window.setTimeout(() => ui.lobby.scrollIntoView({ behavior:"smooth", block:"start" }), 20);
  }

  function clearTimers() {
    window.clearTimeout(state.npcTimer);
    window.clearTimeout(state.unoTimer);
  }

  function startMatch() {
    clearTimers();
    state.mode = ui.gameMode.value === "classic" ? "classic" : "quick";
    state.players = createPlayers();
    state.round = 1;
    state.dealerIndex = Math.floor(Math.random() * state.players.length);
    state.log = [];
    ui.lobby.hidden = true;
    ui.tableScreen.hidden = false;
    logEvent(`Mesa creada con ${state.players.length} jugadores.`);
    startRound(false);
    ui.tableScreen.scrollIntoView({ behavior:"smooth", block:"start" });
  }

  function startRound(rotateDealer = true) {
    clearTimers();
    if (rotateDealer) state.dealerIndex = nextIndex(state.dealerIndex, 1, 1);
    state.deck = buildDeck();
    state.discard = [];
    state.direction = 1;
    state.activeColor = null;
    state.turnHasDrawn = false;
    state.drawnCardId = null;
    state.pendingColor = null;
    state.pendingChallenge = null;
    state.pendingNextIndex = null;
    state.actionLocked = true;
    state.dealAnimation = true;
    state.players.forEach(player => { player.hand = []; player.saidUno = false; });

    for (let card = 0; card < 7; card += 1) {
      state.players.forEach(player => drawCards(player, 1));
    }

    let starter = state.deck.pop();
    while (starter?.type === "wild4") {
      state.deck.unshift(starter);
      state.deck = shuffle(state.deck);
      starter = state.deck.pop();
    }
    state.discard.push(starter);

    const first = nextIndex(state.dealerIndex, 1, 1);
    state.currentIndex = first;
    state.phase = "playing";
    state.activeColor = starter.color || null;
    ui.roundNumber.textContent = String(state.round);
    logEvent(`Ronda ${state.round}. Reparte ${state.players[state.dealerIndex].name}.`);
    logEvent(`Carta inicial: ${cardLabel(starter)}.`);

    if (starter.type === "wild") {
      if (state.players[first].type === "human") {
        state.pendingColor = { kind:"initial", playerIndex:first };
        state.phase = "awaiting-color";
        ui.colorModal.hidden = false;
        setMessage("Elige el color inicial.", "La carta inicial es un comodín.");
      } else {
        state.activeColor = chooseNpcColor(state.players[first]);
      }
    } else if (starter.type === "reverse") {
      state.direction = -1;
      state.currentIndex = state.dealerIndex;
      logEvent("La Reversa inicial cambia el sentido y el repartidor comienza.");
    } else if (starter.type === "skip") {
      logEvent(`${state.players[first].name} pierde el primer turno.`);
      state.currentIndex = nextIndex(first, 1, 1);
    } else if (starter.type === "draw2") {
      drawCards(state.players[first], 2);
      logEvent(`${state.players[first].name} roba 2 y pierde el primer turno.`);
      state.currentIndex = nextIndex(first, 1, 1);
    }

    renderAll();
    window.setTimeout(() => { state.dealAnimation = false; renderAll(); }, 950);
    if (state.phase === "playing") beginCurrentTurn(850);
  }

  function renderScoreboard() {
    const maxScore = Math.max(0, ...state.players.map(player => player.score));
    ui.scoreboard.innerHTML = state.players.map(player => `<div class="match-score ${player.score === maxScore && maxScore > 0 ? "is-leading" : ""}">
      <span>${player.type === "human" ? "Jugador" : player.profile.role}</span>
      <strong>${player.name} · ${player.score}</strong>
    </div>`).join("");
  }

  function renderOpponents() {
    const current = state.players[state.currentIndex];
    ui.boardOpponents.innerHTML = state.players.slice(1).map(player => `<article class="opponent-seat ${current?.id === player.id ? "is-active" : ""} ${player.hand.length === 0 ? "is-out" : ""}">
      <div class="opponent-seat__head">
        <div class="opponent-seat__meta"><span>${player.profile.role}</span><strong>${player.name}</strong></div>
        <div class="opponent-seat__count">${player.hand.length}</div>
      </div>
      <div class="opponent-seat__cards">${Array.from({length:Math.min(8,player.hand.length)},() => `<i class="mini-card-back"></i>`).join("")}</div>
      ${player.hand.length === 1 && player.saidUno ? `<b class="opponent-seat__uno">UNO</b>` : ""}
    </article>`).join("");
  }

  function renderRoster() {
    const npcs = state.players.slice(1);
    ui.rosterCount.textContent = String(npcs.length);
    ui.roster.innerHTML = npcs.map(player => `<article class="roster-entry"><strong>${player.name}</strong><span>${player.profile.role}</span><p>${player.profile.copy}</p></article>`).join("");
  }

  function renderLog() {
    ui.eventLog.innerHTML = state.log.length ? state.log.map(item => `<p>${item}</p>`).join("") : `<p>Sin acciones registradas.</p>`;
  }

  function renderDiscard() {
    const card = topCard();
    ui.discard.innerHTML = card ? renderCard(card, { played:true }) : "";
    ui.lastPlayed.textContent = cardLabel(card);
  }

  function humanTurnActive() {
    return state.phase === "playing" && state.players[state.currentIndex]?.type === "human" && !state.actionLocked;
  }

  function canHumanPlay(card) {
    if (!humanTurnActive()) return false;
    if (state.turnHasDrawn) return card.id === state.drawnCardId && isPlayable(card, state.players[0]);
    return isPlayable(card, state.players[0]);
  }

  function renderHand() {
    const human = state.players[0];
    if (!human) { ui.playerHand.innerHTML = ""; return; }
    ui.handCount.textContent = `${human.hand.length} carta${human.hand.length === 1 ? "" : "s"}`;
    ui.playerHand.innerHTML = human.hand.map((card,index) => {
      const playable = canHumanPlay(card);
      const classes = ["hand-card", playable ? "is-playable" : "", card.id === state.drawnCardId ? "is-drawn" : ""].filter(Boolean).join(" ");
      return `<button class="${classes}" type="button" data-card-id="${card.id}" ${playable ? "" : "disabled"} aria-label="Jugar ${cardLabel(card)}">${renderCard(card,{entering:state.dealAnimation,delay:index*45})}</button>`;
    }).join("");
    ui.playerHand.querySelectorAll("[data-card-id]").forEach(button => button.addEventListener("click", () => handleHumanPlay(button.dataset.cardId)));

    ui.drawButton.disabled = !(humanTurnActive() && !state.turnHasDrawn);
    ui.endTurn.hidden = !(humanTurnActive() && state.turnHasDrawn);
    ui.unoButton.hidden = state.phase !== "awaiting-uno";
  }

  function renderTurnData() {
    const current = state.players[state.currentIndex];
    ui.turnOwner.textContent = current?.name || "—";
    ui.activeColor.textContent = state.activeColor ? COLOR_LABELS[state.activeColor] : "—";
    ui.activeColorDot.dataset.color = state.activeColor || "none";
    ui.direction.textContent = state.direction === 1 ? "→" : "←";
    ui.drawCount.textContent = String(state.deck.length);
  }

  function renderAll() {
    if (!state.players.length) return;
    renderScoreboard();
    renderOpponents();
    renderRoster();
    renderLog();
    renderDiscard();
    renderHand();
    renderTurnData();
    updatePackCounter();
  }

  function beginCurrentTurn(delay = 0) {
    window.clearTimeout(state.npcTimer);
    state.turnHasDrawn = false;
    state.drawnCardId = null;
    state.actionLocked = true;
    renderAll();
    state.npcTimer = window.setTimeout(() => {
      if (state.phase !== "playing") return;
      const current = state.players[state.currentIndex];
      state.actionLocked = false;
      if (current.type === "human") {
        const legal = playableCards(current).length;
        setMessage("Tu turno.", legal ? "Juega una carta válida o roba voluntariamente." : "No tienes una carta válida. Debes robar.");
        renderAll();
      } else {
        setMessage(`Turno de ${current.name}.`, current.profile.copy);
        renderAll();
        state.npcTimer = window.setTimeout(() => runNpcTurn(state.currentIndex), 760);
      }
    }, delay);
  }

  function advanceTo(index, delay = 450) {
    state.currentIndex = index;
    state.phase = "playing";
    beginCurrentTurn(delay);
  }

  function chooseNpcCard(player) {
    const legal = player.hand.filter(card => isPlayable(card, player));
    const illegalWildFour = player.hand.find(card => card.type === "wild4" && hasColor(player,state.activeColor,card.id));
    const nextPlayer = state.players[nextIndex(state.currentIndex)];
    const shouldBluff = illegalWildFour && Math.random() < player.profile.bluff && (nextPlayer.hand.length <= 3 || legal.length === 0);
    const candidates = shouldBluff ? [...legal, illegalWildFour] : legal;
    if (!candidates.length) return null;
    const counts = colorCounts(player.hand);
    return candidates.map(card => {
      let score = Math.random() * player.profile.chaos;
      if (card.color) score += counts[card.color] * 1.35 + player.profile.preference[card.color];
      if (card.type === "number") score += 2 + (9-card.value)*.08;
      else score += 2.2 + (player.profile.action[card.type] || 0);
      if (["wild","wild4"].includes(card.type)) score -= player.profile.conserve;
      if (nextPlayer.hand.length <= 3 && ["draw2","skip","wild4"].includes(card.type)) score += player.profile.punish;
      if (card === illegalWildFour) score += 2.5;
      return { card, score };
    }).sort((a,b) => b.score-a.score)[0].card;
  }

  function runNpcTurn(index) {
    if (state.phase !== "playing" || state.currentIndex !== index || state.actionLocked) return;
    state.actionLocked = true;
    const player = state.players[index];
    const chosen = chooseNpcCard(player);
    if (!chosen) {
      const [drawn] = drawCards(player,1);
      logEvent(`${player.name} roba una carta.`);
      if (drawn && isPlayable(drawn,player) && Math.random() > .16) {
        executePlay(index,drawn.id,["wild","wild4"].includes(drawn.type) ? chooseNpcColor(player) : null);
      } else {
        setMessage(`${player.name} pasa.`, "No ha podido o no ha querido jugar la carta robada.");
        advanceTo(nextIndex(index),520);
      }
      return;
    }
    executePlay(index,chosen.id,["wild","wild4"].includes(chosen.type) ? chooseNpcColor(player) : null);
  }

  function handleHumanDraw() {
    if (!humanTurnActive() || state.turnHasDrawn) return;
    const human = state.players[0];
    const [card] = drawCards(human,1);
    state.turnHasDrawn = true;
    state.drawnCardId = card?.id || null;
    logEvent(`Robas ${cardLabel(card)}.`);
    if (card && isPlayable(card,human)) {
      setMessage("Carta robada jugable.", "Solo puedes jugar esa carta o terminar tu turno.");
      showToast("Puedes jugar la carta robada");
      renderAll();
    } else {
      state.actionLocked = true;
      setMessage("No hay jugada.", "La carta robada no coincide. El turno termina.");
      renderAll();
      window.setTimeout(() => advanceTo(nextIndex(0),250),650);
    }
  }

  function handleHumanPlay(cardId) {
    if (!humanTurnActive()) return;
    const human = state.players[0];
    const card = human.hand.find(item => item.id === cardId);
    if (!card || !canHumanPlay(card)) return;
    state.actionLocked = true;
    if (["wild","wild4"].includes(card.type)) {
      state.pendingColor = { kind:"play", playerIndex:0, cardId };
      state.phase = "awaiting-color";
      ui.colorModal.hidden = false;
      setMessage("Elige el color.", "El comodín continuará con el color seleccionado.");
      renderAll();
      return;
    }
    executePlay(0,cardId,null);
  }

  function executePlay(playerIndex, cardId, chosenColor) {
    const player = state.players[playerIndex];
    const cardIndex = player.hand.findIndex(card => card.id === cardId);
    if (cardIndex < 0) return;
    const card = player.hand[cardIndex];
    const previousColor = state.activeColor;
    const illegalWildFour = card.type === "wild4" && hasColor(player,previousColor,card.id);
    player.hand.splice(cardIndex,1);
    player.saidUno = false;
    state.discard.push(card);
    state.activeColor = card.color || chosenColor || state.activeColor;
    logEvent(`${player.name} juega ${cardLabel(card)}${chosenColor ? ` y elige ${COLOR_LABELS[chosenColor]}` : ""}.`);
    renderAll();

    const targetIndex = nextIndex(playerIndex);
    let nextTurn = targetIndex;

    if (card.type === "reverse") {
      state.direction *= -1;
      nextTurn = state.players.length === 2 ? playerIndex : nextIndex(playerIndex);
      logEvent("El sentido de la ronda cambia.");
    } else if (card.type === "skip") {
      logEvent(`${state.players[targetIndex].name} pierde el turno.`);
      nextTurn = nextIndex(targetIndex);
    } else if (card.type === "draw2") {
      drawCards(state.players[targetIndex],2);
      logEvent(`${state.players[targetIndex].name} roba 2 y pierde el turno.`);
      nextTurn = nextIndex(targetIndex);
    } else if (card.type === "wild4") {
      state.pendingChallenge = { offenderIndex:playerIndex, targetIndex, illegal:illegalWildFour, nextTurn:nextIndex(targetIndex), winnerPending:player.hand.length === 0 };
      if (state.players[targetIndex].type === "human") {
        state.phase = "awaiting-challenge";
        ui.challengeCopy.textContent = `${player.name} ha jugado un +4. Puedes aceptar el robo o desafiar si crees que tenía una carta ${COLOR_LABELS[previousColor]}.`;
        ui.challengeModal.hidden = false;
        setMessage("Decide sobre el +4.", "Un desafío incorrecto provoca que robes 6 cartas.");
        renderAll();
        return;
      }
      resolveNpcChallenge();
      return;
    }

    if (player.hand.length === 0) {
      finishRound(playerIndex);
      return;
    }

    resolveUnoThenAdvance(playerIndex,nextTurn);
  }

  function resolveUnoThenAdvance(playerIndex,nextTurn) {
    const player = state.players[playerIndex];
    if (player.hand.length !== 1) {
      advanceTo(nextTurn);
      return;
    }

    if (player.type === "human") {
      state.phase = "awaiting-uno";
      state.pendingNextIndex = nextTurn;
      setMessage("¡Te queda una carta!", "Pulsa UNO antes de que termine el aviso.");
      renderAll();
      window.clearTimeout(state.unoTimer);
      state.unoTimer = window.setTimeout(() => {
        if (state.phase !== "awaiting-uno") return;
        drawCards(player,2);
        logEvent("No dijiste UNO a tiempo. Robas 2 cartas.");
        showToast("Penalización: +2 cartas");
        state.phase = "playing";
        advanceTo(state.pendingNextIndex,350);
      },2600);
      return;
    }

    if (Math.random() < player.profile.forget) {
      drawCards(player,2);
      logEvent(`${player.name} olvida decir UNO y roba 2.`);
    } else {
      player.saidUno = true;
      logEvent(`${player.name} declara UNO.`);
    }
    advanceTo(nextTurn);
  }

  function resolveNpcChallenge() {
    const pending = state.pendingChallenge;
    const target = state.players[pending.targetIndex];
    const chance = target.profile?.challenge ?? .4;
    const challenges = Math.random() < chance;
    if (challenges) {
      resolveChallenge(true);
    } else {
      resolveChallenge(false);
    }
  }

  function resolveChallenge(challenge) {
    const pending = state.pendingChallenge;
    if (!pending) return;
    const offender = state.players[pending.offenderIndex];
    const target = state.players[pending.targetIndex];

    if (!challenge) {
      drawCards(target,4);
      logEvent(`${target.name} acepta el +4 y pierde su turno.`);
    } else if (pending.illegal) {
      drawCards(offender,4);
      logEvent(`${target.name} desafía correctamente: ${offender.name} roba 4.`);
      showToast("Desafío correcto");
    } else {
      drawCards(target,6);
      logEvent(`${target.name} desafía sin razón y roba 6.`);
      showToast("Desafío fallido: +6");
    }

    ui.challengeModal.hidden = true;
    state.pendingChallenge = null;
    if (pending.winnerPending && !(challenge && pending.illegal)) {
      finishRound(pending.offenderIndex);
      return;
    }
    if (pending.winnerPending && challenge && pending.illegal) {
      resolveUnoThenAdvance(pending.offenderIndex,pending.targetIndex);
      return;
    }
    const nextTurn = challenge && pending.illegal ? pending.targetIndex : pending.nextTurn;
    resolveUnoThenAdvance(pending.offenderIndex,nextTurn);
  }

  function declareUno() {
    if (state.phase !== "awaiting-uno") return;
    window.clearTimeout(state.unoTimer);
    const human = state.players[0];
    human.saidUno = true;
    state.phase = "playing";
    logEvent("Declaras UNO.");
    showToast("UNO declarado");
    advanceTo(state.pendingNextIndex,250);
  }

  function endHumanTurn() {
    if (!humanTurnActive() || !state.turnHasDrawn) return;
    logEvent("Terminas el turno después de robar.");
    advanceTo(nextIndex(0),250);
  }

  function finishRound(winnerIndex) {
    clearTimers();
    state.phase = "round-end";
    const winner = state.players[winnerIndex];
    const points = state.players.reduce((total,player,index) => index === winnerIndex ? total : total + player.hand.reduce((sum,card) => sum + cardPoints(card),0),0);
    winner.score += points;
    const humanWon = winner.type === "human";
    const matchWon = state.mode === "quick" || winner.score >= 500;

    ui.resultKicker.textContent = matchWon ? "Fin de partida" : `Fin de ronda ${state.round}`;
    ui.resultTitle.textContent = humanWon ? "Victoria" : `${winner.name} gana`;
    ui.resultScore.textContent = `${points} puntos`;

    if (matchWon) {
      state.phase = "match-end";
      state.resultAction = "new-match";
      ui.continueGame.textContent = "Nueva partida";
      if (humanWon) {
        awardPack();
        ui.resultCopy.textContent = `Has ganado ${state.mode === "classic" ? "la partida clásica" : "la ronda"} y recibes +1 sobre para CARTAS.`;
      } else {
        ui.resultCopy.textContent = `${winner.name} cierra la partida. El sobre solo se entrega cuando tú ganas.`;
      }
    } else {
      state.resultAction = "next-round";
      ui.continueGame.textContent = "Siguiente ronda";
      ui.resultCopy.textContent = `${winner.name} suma ${points} puntos y alcanza ${winner.score}. El objetivo sigue siendo 500.`;
    }
    logEvent(`${winner.name} gana la ronda con ${points} puntos.`);
    renderAll();
    ui.resultModal.hidden = false;
  }

  function continueFromResult() {
    ui.resultModal.hidden = true;
    if (state.resultAction === "next-round") {
      state.round += 1;
      startRound(true);
    } else {
      showLobby();
    }
  }

  function chooseColor(color) {
    const pending = state.pendingColor;
    if (!pending) return;
    state.activeColor = color;
    state.pendingColor = null;
    ui.colorModal.hidden = true;
    if (pending.kind === "initial") {
      state.phase = "playing";
      logEvent(`El color inicial será ${COLOR_LABELS[color]}.`);
      renderAll();
      beginCurrentTurn(350);
    } else {
      state.phase = "playing";
      executePlay(pending.playerIndex,pending.cardId,color);
    }
  }

  function bindEvents() {
    ui.npcCount.addEventListener("input", chooseOpponents);
    ui.gameMode.addEventListener("change", saveSettings);
    ui.reroll.addEventListener("click", chooseOpponents);
    ui.start.addEventListener("click", startMatch);
    ui.leave.addEventListener("click", showLobby);
    ui.drawButton.addEventListener("click", handleHumanDraw);
    ui.endTurn.addEventListener("click", endHumanTurn);
    ui.unoButton.addEventListener("click", declareUno);
    ui.colorChoices.forEach(button => button.addEventListener("click", () => chooseColor(button.dataset.colorChoice)));
    ui.acceptDrawFour.addEventListener("click", () => resolveChallenge(false));
    ui.challengeDrawFour.addEventListener("click", () => resolveChallenge(true));
    ui.showRules.addEventListener("click", () => { ui.rulesModal.hidden = false; });
    ui.closeRules.addEventListener("click", () => { ui.rulesModal.hidden = true; });
    ui.rulesModal.addEventListener("click", event => { if (event.target === ui.rulesModal) ui.rulesModal.hidden = true; });
    ui.continueGame.addEventListener("click", continueFromResult);
    ui.clearLog.addEventListener("click", () => { state.log = []; renderLog(); });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        if (!ui.rulesModal.hidden) ui.rulesModal.hidden = true;
      }
    });
  }

  function init() {
    const settings = loadSettings();
    ui.npcCount.value = String(settings.npcCount);
    ui.gameMode.value = settings.mode;
    state.mode = settings.mode;
    chooseOpponents();
    updatePackCounter();
    bindEvents();
    ui.resultModal.hidden = true;
    ui.colorModal.hidden = true;
    ui.challengeModal.hidden = true;
    ui.rulesModal.hidden = true;
  }

  init();
})();
