(() => {
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

  const updateScrollProgress = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const progress = max > 0 ? clamp(window.scrollY / max, 0, 1) : 0;
    document.documentElement.style.setProperty("--scroll-progress", progress.toFixed(4));
  };
  updateScrollProgress();
  window.addEventListener("scroll", updateScrollProgress, { passive: true });
  window.addEventListener("resize", updateScrollProgress, { passive: true });

  const updateBalance = () => {
    const balance = window.JGS_ECONOMY?.getBalance?.() ?? 1000;
    document.querySelectorAll("[data-jcoin-balance]").forEach(node => {
      node.textContent = new Intl.NumberFormat("es-ES").format(balance);
    });
  };
  updateBalance();
  window.addEventListener("storage", updateBalance);
  window.addEventListener("pageshow", updateBalance);

  const core = document.querySelector("[data-command-core]");
  if (core && window.matchMedia("(pointer: fine)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    core.addEventListener("pointermove", event => {
      const rect = core.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - .5;
      const y = (event.clientY - rect.top) / rect.height - .5;
      core.style.setProperty("--core-rx", `${(x * 5).toFixed(2)}deg`);
      core.style.setProperty("--core-ry", `${(-y * 5).toFixed(2)}deg`);
    });
    core.addEventListener("pointerleave", () => {
      core.style.setProperty("--core-rx", "0deg");
      core.style.setProperty("--core-ry", "0deg");
    });
  }

  const projectToolbar = document.querySelector("[data-project-filters]");
  const projectList = document.querySelector("[data-project-list]");
  const projectStatus = document.querySelector("[data-filter-status]");
  const projectEmpty = document.querySelector("[data-project-empty]");

  const applyProjectFilter = group => {
    if (!projectList) return;
    const cards = [...projectList.querySelectorAll("[data-project-group]")];
    let visible = 0;
    cards.forEach(card => {
      const show = group === "all" || card.dataset.projectGroup === group;
      card.hidden = !show;
      if (show) visible += 1;
    });
    if (projectStatus) projectStatus.textContent = String(visible).padStart(2, "0");
    if (projectEmpty) projectEmpty.hidden = visible > 0;
  };

  if (projectToolbar) {
    projectToolbar.addEventListener("click", event => {
      const button = event.target.closest("[data-filter]");
      if (!button) return;
      projectToolbar.querySelectorAll("[data-filter]").forEach(item => {
        const active = item === button;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-pressed", String(active));
      });
      applyProjectFilter(button.dataset.filter || "all");
    });
    document.addEventListener("jgs:projects-rendered", () => applyProjectFilter("all"));
    applyProjectFilter("all");
  }

  const devlogToolbar = document.querySelector("[data-devlog-filters]");
  const entries = [...document.querySelectorAll(".timeline-entry")];
  const devlogStatus = document.querySelector("[data-devlog-status]");

  entries.forEach((entry, index) => {
    const projectText = entry.querySelector(".timeline-entry__meta strong")?.textContent || "";
    const match = projectText.match(/(?:PROYECTO|PUBLICACIÓN)\s+0*(\d+)/i);
    entry.dataset.devlogProject = match ? match[1].padStart(3, "0") : "other";
    const sequence = document.createElement("span");
    sequence.className = "timeline-entry__sequence";
    sequence.setAttribute("aria-hidden", "true");
    sequence.textContent = String(entries.length - index).padStart(2, "0");
    entry.append(sequence);
  });

  const applyDevlogFilter = project => {
    let visible = 0;
    entries.forEach(entry => {
      const show = project === "all" || entry.dataset.devlogProject === project;
      entry.hidden = !show;
      if (show) visible += 1;
    });
    if (devlogStatus) devlogStatus.textContent = String(visible).padStart(2, "0");
  };

  if (devlogToolbar) {
    devlogToolbar.addEventListener("click", event => {
      const button = event.target.closest("[data-devlog-filter]");
      if (!button) return;
      devlogToolbar.querySelectorAll("[data-devlog-filter]").forEach(item => {
        const active = item === button;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-pressed", String(active));
      });
      applyDevlogFilter(button.dataset.devlogFilter || "all");
    });
    applyDevlogFilter("all");
  }

  document.querySelectorAll("[data-local-time]").forEach(node => {
    const render = () => {
      node.textContent = new Intl.DateTimeFormat("es-ES", {
        hour: "2-digit", minute: "2-digit", hour12: false
      }).format(new Date());
    };
    render();
    window.setInterval(render, 30_000);
  });
})();
