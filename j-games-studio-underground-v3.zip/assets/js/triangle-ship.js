(() => {
  "use strict";

  const canvas = document.getElementById("avion-canvas");
  if (!canvas) return;

  const ctx = canvas.getContext("2d", { alpha: false });
  const W = canvas.width;
  const H = canvas.height;
  const TAU = Math.PI * 2;
  const STORAGE_KEY = "jgs-triangle-ship-progress-v2";
  const LEGACY_STORAGE_KEY = "jgs-nave-progress-v2";
  const SETTINGS_KEY = "jgs-triangle-ship-settings-v1";
  const PROFILE_KEY = "jgs-triangle-ship-profile-v1";
  const CAMPAIGN_KEY = "jgs-triangle-ship-campaign-v2";
  const RESULT_KEY = "jgs-triangle-ship-pending-result-v2";
  const HIGHSCORES_KEY = "jgs-triangle-ship-highscores-v1";
  const CREDIT_COST = 100;
  const BALANCE_VERSION = "FINAL-1.0";
  const DEATH_PENALTY = 650;
  const CELL_SCORE = 1250;
  const ALL_CELLS_BONUS = 4500;

  const ui = {
    screen: document.getElementById("avion-screen"),
    overlay: document.getElementById("avion-overlay"),
    overlayKicker: document.getElementById("avion-overlay-kicker"),
    overlayTitle: document.getElementById("avion-overlay-title"),
    overlayCopy: document.getElementById("avion-overlay-copy"),
    overlayHint: document.getElementById("avion-overlay-hint"),
    startButton: document.getElementById("avion-start-button"),
    levelButton: document.getElementById("avion-level-button"),
    levelLabel: document.getElementById("avion-level-label"),
    attempts: document.getElementById("avion-attempts"),
    time: document.getElementById("avion-time"),
    speed: document.getElementById("avion-speed"),
    fuel: document.getElementById("avion-fuel"),
    best: document.getElementById("avion-best"),
    restart: document.getElementById("avion-restart-button"),
    pause: document.getElementById("avion-pause-button"),
    pauseLabel: document.getElementById("avion-pause-label"),
    sound: document.getElementById("avion-sound-button"),
    soundLabel: document.getElementById("avion-sound-label"),
    status: document.getElementById("avion-status-message"),
    thrustBar: document.getElementById("avion-thrust-bar"),
    fuelBar: document.getElementById("avion-fuel-bar"),
    cells: document.getElementById("avion-cells"),
    toast: document.getElementById("avion-toast"),
    levelPanel: document.getElementById("avion-level-panel"),
    levelGrid: document.getElementById("avion-level-grid"),
    levelClose: document.getElementById("avion-level-close"),
    touchThrust: document.getElementById("avion-touch-thrust"),
    touchDirections: [...document.querySelectorAll("[data-touch-direction]")],
    arcadeLayer: document.getElementById("triangle-arcade-layer"),
    attractScreen: document.getElementById("triangle-attract-screen"),
    mainMenu: document.getElementById("triangle-main-menu"),
    introScreen: document.getElementById("triangle-intro-screen"),
    hangarScreen: document.getElementById("triangle-hangar-screen"),
    settingsScreen: document.getElementById("triangle-settings-screen"),
    nameScreen: document.getElementById("triangle-name-screen"),
    highscoresScreen: document.getElementById("triangle-highscores-screen"),
    cargoScreen: document.getElementById("triangle-cargo-screen"),
    insertCoin: document.getElementById("triangle-insert-coin"),
    balance: document.getElementById("triangle-balance"),
    creditMessage: document.getElementById("triangle-credit-message"),
    newGame: document.getElementById("triangle-new-game"),
    continueGame: document.getElementById("triangle-continue"),
    continueNote: document.getElementById("triangle-continue-note"),
    hangarButton: document.getElementById("triangle-hangar"),
    settingsButton: document.getElementById("triangle-settings"),
    highscoresButton: document.getElementById("triangle-highscores"),
    pendingCargoButton: document.getElementById("triangle-pending-cargo"),
    pendingNote: document.getElementById("triangle-pending-note"),
    exitCredit: document.getElementById("triangle-exit-credit"),
    menuButton: document.getElementById("triangle-menu-button"),
    menuMode: document.getElementById("triangle-menu-mode"),
    menuColor: document.getElementById("triangle-menu-color"),
    terminalLines: document.getElementById("triangle-terminal-lines"),
    skipIntro: document.getElementById("triangle-skip-intro"),
    hangarGrid: document.getElementById("triangle-hangar-grid"),
    hangarShip: document.getElementById("triangle-hangar-ship"),
    equippedLabel: document.getElementById("triangle-equipped-label"),
    collectionCount: document.getElementById("triangle-collection-count"),
    commonCount: document.getElementById("triangle-common-count"),
    rareCount: document.getElementById("triangle-rare-count"),
    legendaryCount: document.getElementById("triangle-legendary-count"),
    cargoHistory: document.getElementById("triangle-cargo-history"),
    hangarBack: document.getElementById("triangle-hangar-back"),
    settingsBack: document.getElementById("triangle-settings-back"),
    settingMute: document.getElementById("triangle-setting-mute"),
    settingMusic: document.getElementById("triangle-setting-music"),
    settingShake: document.getElementById("triangle-setting-shake"),
    settingTimer: document.getElementById("triangle-setting-timer"),
    settingCrt: document.getElementById("triangle-setting-crt"),
    controlHelp: document.getElementById("triangle-control-help"),
    activeControl: document.getElementById("triangle-active-control"),
    activeControlCopy: document.getElementById("triangle-active-control-copy"),
    score: document.getElementById("triangle-score"),
    fuelWarning: document.getElementById("triangle-fuel-warning"),
    heat: document.getElementById("triangle-heat"),
    heatBar: document.getElementById("triangle-heat-bar"),
    overchargeWarning: document.getElementById("triangle-overcharge-warning"),
    rechargePanel: document.getElementById("triangle-recharge-panel"),
    rechargeBar: document.getElementById("triangle-recharge-bar"),
    rechargeValue: document.getElementById("triangle-recharge-value"),
    rechargeStatus: document.getElementById("triangle-recharge-status"),
    touchFire: document.getElementById("triangle-touch-fire"),
    saveIndicator: document.getElementById("triangle-save-indicator"),
    timerField: document.querySelector(".timer-field"),
    hull: document.getElementById("triangle-hull"),
    reentryWarning: document.getElementById("triangle-reentry-warning"),
    reentryValue: document.getElementById("triangle-reentry-value"),
    reentryBar: document.getElementById("triangle-reentry-bar"),
    resultScreen: document.getElementById("triangle-result-screen"),
    resultScore: document.getElementById("triangle-result-score"),
    resultTime: document.getElementById("triangle-result-time"),
    resultDeaths: document.getElementById("triangle-result-deaths"),
    resultCells: document.getElementById("triangle-result-cells"),
    resultLandings: document.getElementById("triangle-result-landings"),
    resultRegister: document.getElementById("triangle-result-register"),
    resultBack: document.getElementById("triangle-result-back"),
    nameScore: document.getElementById("triangle-name-score"),
    nameTime: document.getElementById("triangle-name-time"),
    nameDeaths: document.getElementById("triangle-name-deaths"),
    nameSlots: document.getElementById("triangle-name-slots"),
    nameUp: document.getElementById("triangle-name-up"),
    nameDown: document.getElementById("triangle-name-down"),
    nameLeft: document.getElementById("triangle-name-left"),
    nameRight: document.getElementById("triangle-name-right"),
    nameConfirm: document.getElementById("triangle-name-confirm"),
    highscoresStatus: document.getElementById("triangle-highscores-status"),
    highscoresList: document.getElementById("triangle-highscores-list"),
    highscoresNext: document.getElementById("triangle-highscores-next"),
    highscoresBack: document.getElementById("triangle-highscores-back"),
    cargoStage: document.getElementById("triangle-cargo-stage"),
    cargoCapsule: document.getElementById("triangle-cargo-capsule"),
    cargoReveal: document.getElementById("triangle-cargo-reveal"),
    cargoRarity: document.getElementById("triangle-cargo-rarity"),
    cargoShip: document.getElementById("triangle-cargo-ship"),
    cargoColor: document.getElementById("triangle-cargo-color"),
    cargoCopy: document.getElementById("triangle-cargo-copy"),
    cargoOpen: document.getElementById("triangle-cargo-open"),
    cargoEquip: document.getElementById("triangle-cargo-equip"),
    cargoBack: document.getElementById("triangle-cargo-back")
  };

  const levels = [
    {
      id: 1,
      block: "BLOQUE I / APRENDIZAJE",
      name: "Señal de emergencia",
      difficulty: "Iniciación",
      description: "Primera ruta real. Cruza cuatro cámaras de roca, administra el combustible y localiza la baliza de salida.",
      world: { w: 2600, h: 1200 },
      gravity: 198,
      thrust: 426,
      fuelBurn: 4.8,
      parTime: 72,
      start: { x: 110, y: 1050, w: 220, h: 18 },
      goal: { x: 2250, y: 950, w: 220, h: 18 },
      walls: [
        { x: 0, y: 0, w: 620, h: 220 },
        { x: 0, y: 1080, w: 720, h: 120 },
        { x: 540, y: 620, w: 170, h: 460 },
        { x: 820, y: 0, w: 480, h: 300 },
        { x: 1070, y: 720, w: 210, h: 480 },
        { x: 1420, y: 0, w: 190, h: 470 },
        { x: 1660, y: 790, w: 310, h: 410 },
        { x: 1940, y: 0, w: 660, h: 250 },
        { x: 2050, y: 990, w: 550, h: 210 },
        { x: 760, y: 510, w: 150, h: 105 },
        { x: 1325, y: 540, w: 135, h: 110 },
        { x: 1800, y: 460, w: 165, h: 120 }
      ],
      spikes: [],
      movingWalls: [],
      zones: [],
      meteors: [],
      cells: [{ x: 790, y: 455 }, { x: 1385, y: 700 }, { x: 1900, y: 690 }]
    },
    {
      id: 2,
      block: "BLOQUE I / APRENDIZAJE",
      name: "Galería quebrada",
      difficulty: "Precisión",
      description: "Una ascensión larga entre salientes de meteorito. Cada corrección innecesaria se paga con combustible.",
      world: { w: 2920, h: 1800 },
      gravity: 204,
      thrust: 434,
      fuelBurn: 5.05,
      parTime: 104,
      start: { x: 130, y: 1690, w: 220, h: 18 },
      goal: { x: 2580, y: 520, w: 210, h: 18 },
      walls: [
        { x: 0, y: 0, w: 620, h: 340 },
        { x: 0, y: 1740, w: 980, h: 60 },
        { x: 760, y: 1250, w: 210, h: 490 },
        { x: 980, y: 0, w: 280, h: 850 },
        { x: 1250, y: 1120, w: 230, h: 680 },
        { x: 1490, y: 0, w: 260, h: 650 },
        { x: 1760, y: 900, w: 230, h: 900 },
        { x: 2010, y: 0, w: 250, h: 440 },
        { x: 2270, y: 720, w: 230, h: 1080 },
        { x: 2500, y: 538, w: 420, h: 1262 },
        { x: 520, y: 1120, w: 170, h: 120 },
        { x: 1040, y: 950, w: 150, h: 95 },
        { x: 1510, y: 735, w: 150, h: 90 },
        { x: 2050, y: 535, w: 145, h: 85 }
      ],
      spikes: [
        { x: 775, y: 1250, count: 5, size: 25, dir: "up" },
        { x: 1510, y: 650, count: 5, size: 25, dir: "down" },
        { x: 2270, y: 775, count: 4, size: 25, dir: "left" }
      ],
      movingWalls: [],
      zones: [{ x: 1320, y: 760, w: 360, h: 250, fx: 10, fy: -24, label: "ASCENSO TÉRMICO" }],
      meteors: [],
      cells: [{ x: 650, y: 1470 }, { x: 1600, y: 980 }, { x: 2380, y: 370 }]
    },
    {
      id: 3,
      block: "BLOQUE I / APRENDIZAJE",
      name: "Deriva",
      difficulty: "Adaptación",
      description: "El espacio se abre, pero las corrientes y los primeros fragmentos móviles obligan a aprender cuándo disparar y cuándo esperar.",
      world: { w: 3400, h: 1450 },
      gravity: 207,
      thrust: 440,
      fuelBurn: 5.2,
      parTime: 118,
      start: { x: 120, y: 1330, w: 220, h: 18 },
      goal: { x: 3090, y: 970, w: 220, h: 18 },
      walls: [
        { x: 0, y: 0, w: 500, h: 260 },
        { x: 0, y: 1380, w: 600, h: 70 },
        { x: 620, y: 850, w: 190, h: 600 },
        { x: 900, y: 0, w: 500, h: 350 },
        { x: 1090, y: 690, w: 310, h: 185 },
        { x: 1460, y: 980, w: 270, h: 470 },
        { x: 1760, y: 0, w: 270, h: 500 },
        { x: 2050, y: 640, w: 230, h: 250 },
        { x: 2380, y: 1080, w: 310, h: 370 },
        { x: 2700, y: 0, w: 320, h: 330 },
        { x: 3060, y: 1000, w: 340, h: 450 },
        { x: 780, y: 520, w: 140, h: 100 },
        { x: 1570, y: 580, w: 160, h: 110 },
        { x: 2440, y: 540, w: 170, h: 110 }
      ],
      spikes: [
        { x: 620, y: 850, count: 6, size: 25, dir: "up" },
        { x: 1400, y: 700, count: 7, size: 25, dir: "right" },
        { x: 2050, y: 640, count: 7, size: 25, dir: "up" },
        { x: 2690, y: 1080, count: 7, size: 25, dir: "left" }
      ],
      movingWalls: [],
      zones: [
        { x: 790, y: 390, w: 500, h: 420, fx: 18, fy: -20, label: "DERIVA NORTE" },
        { x: 1710, y: 510, w: 500, h: 420, fx: -24, fy: 5, label: "CONTRAFLUJO" },
        { x: 2740, y: 390, w: 300, h: 430, fx: 18, fy: 18, label: "VECTOR TIERRA" }
      ],
      meteors: [
        { id: "03-A", x: 960, y: 930, r: 23, axis: "y", amplitude: 170, speed: .74, phase: .2, hp: 2, score: 180, destructible: true },
        { id: "03-B", x: 1510, y: 510, r: 29, axis: "circle", amplitude: 145, speed: .62, phase: 1.6, hp: 3, score: 260, destructible: true },
        { id: "03-C", x: 2310, y: 750, r: 42, axis: "x", amplitude: 210, speed: .46, phase: 2.1, hp: 99, score: 0, destructible: false },
        { id: "03-D", x: 2860, y: 690, r: 25, axis: "y", amplitude: 160, speed: .86, phase: .8, hp: 3, score: 300, destructible: true }
      ],
      cells: [{ x: 850, y: 730 }, { x: 1890, y: 930 }, { x: 2860, y: 520 }]
    },
    {
      id: 4,
      block: "BLOQUE II / DOMINIO",
      name: "Cinturón muerto",
      difficulty: "Patrones",
      description: "Un cinturón de fragmentos atraviesa la ruta en ciclos sincronizados. Observa, espera el hueco y decide qué puedes destruir.",
      world: { w: 4300, h: 1800 },
      gravity: 209,
      thrust: 443,
      fuelBurn: 5.25,
      parTime: 154,
      baseScore: 9000,
      timeBonusMax: 2200,
      survivalBonus: 3000,
      start: { x: 110, y: 1660, w: 230, h: 18 },
      goal: { x: 3940, y: 1280, w: 220, h: 18 },
      walls: [
        { x: 0, y: 0, w: 620, h: 300 }, { x: 0, y: 1740, w: 760, h: 60 },
        { x: 680, y: 1040, w: 210, h: 700 }, { x: 930, y: 0, w: 420, h: 420 },
        { x: 1200, y: 760, w: 220, h: 360 }, { x: 1450, y: 1280, w: 270, h: 460 },
        { x: 1760, y: 0, w: 300, h: 520 }, { x: 2070, y: 830, w: 250, h: 910 },
        { x: 2380, y: 0, w: 330, h: 430 }, { x: 2730, y: 1150, w: 270, h: 590 },
        { x: 3040, y: 0, w: 300, h: 650 }, { x: 3370, y: 870, w: 230, h: 870 },
        { x: 3650, y: 0, w: 650, h: 330 }, { x: 3830, y: 1310, w: 470, h: 430 },
        { x: 510, y: 820, w: 135, h: 105 }, { x: 1020, y: 590, w: 150, h: 95 },
        { x: 1540, y: 650, w: 150, h: 100 }, { x: 2410, y: 650, w: 150, h: 105 },
        { x: 3150, y: 760, w: 145, h: 100 }
      ],
      spikes: [
        { x: 680, y: 1040, count: 6, size: 25, dir: "up" },
        { x: 1420, y: 900, count: 7, size: 25, dir: "right" },
        { x: 2070, y: 830, count: 7, size: 25, dir: "up" },
        { x: 3000, y: 1160, count: 7, size: 25, dir: "left" },
        { x: 3370, y: 870, count: 6, size: 25, dir: "up" }
      ],
      movingWalls: [],
      zones: [
        { x: 860, y: 430, w: 560, h: 480, fx: 13, fy: -10, label: "POLVO ORBITAL" },
        { x: 2700, y: 520, w: 560, h: 500, fx: -13, fy: 8, label: "DERIVA DE CINTURÓN" }
      ],
      meteors: [
        { id: "04-A1", x: 1030, y: 820, r: 25, axis: "y", amplitude: 290, speed: .72, phase: 0, hp: 2, score: 180, destructible: true, group: "A" },
        { id: "04-A2", x: 1110, y: 820, r: 28, axis: "y", amplitude: 290, speed: .72, phase: 2.1, hp: 3, score: 240, destructible: true, group: "A" },
        { id: "04-A3", x: 1195, y: 820, r: 23, axis: "y", amplitude: 290, speed: .72, phase: 4.2, hp: 2, score: 180, destructible: true, group: "A" },
        { id: "04-B1", x: 1860, y: 815, r: 48, axis: "x", amplitude: 245, speed: .44, phase: .4, hp: 99, score: 0, destructible: false, group: "B" },
        { id: "04-B2", x: 1860, y: 1005, r: 24, axis: "x", amplitude: 245, speed: .44, phase: 3.54, hp: 2, score: 220, destructible: true, group: "B" },
        { id: "04-C1", x: 2520, y: 780, r: 27, path: [{x:2390,y:610},{x:2630,y:610},{x:2630,y:1030},{x:2390,y:1030}], period: 8.8, phase: 0, hp: 3, score: 300, destructible: true, group: "C" },
        { id: "04-C2", x: 2520, y: 780, r: 31, path: [{x:2630,y:1030},{x:2390,y:1030},{x:2390,y:610},{x:2630,y:610}], period: 8.8, phase: .5, hp: 4, score: 380, destructible: true, group: "C" },
        { id: "04-D1", x: 3230, y: 830, r: 54, axis: "y", amplitude: 250, speed: .38, phase: 0, hp: 99, score: 0, destructible: false, group: "D" },
        { id: "04-D2", x: 3480, y: 650, r: 25, axis: "circle", amplitude: 170, speed: .64, phase: 1.1, hp: 3, score: 320, destructible: true, group: "D" }
      ],
      rockfalls: [],
      anomalies: [],
      cells: [{ x: 820, y: 880 }, { x: 2190, y: 690 }, { x: 3480, y: 540 }]
    },
    {
      id: 5,
      block: "BLOQUE II / DOMINIO",
      name: "Cantera 9",
      difficulty: "Riesgo",
      description: "La cantera se derrumba por sectores. El camino bajo es largo; la ruta alta ofrece fuel y score, pero activa desprendimientos.",
      world: { w: 4800, h: 2100 },
      gravity: 212,
      thrust: 447,
      fuelBurn: 5.45,
      parTime: 188,
      baseScore: 10500,
      timeBonusMax: 2400,
      survivalBonus: 3500,
      start: { x: 120, y: 1970, w: 230, h: 18 },
      goal: { x: 4420, y: 660, w: 230, h: 18 },
      walls: [
        { x: 0, y: 0, w: 720, h: 330 }, { x: 0, y: 2040, w: 900, h: 60 },
        { x: 760, y: 1280, w: 220, h: 760 }, { x: 980, y: 0, w: 420, h: 560 },
        { x: 1260, y: 820, w: 620, h: 420 }, { x: 1450, y: 1650, w: 330, h: 390 },
        { x: 1940, y: 0, w: 320, h: 760 }, { x: 2100, y: 1120, w: 520, h: 380 },
        { x: 2350, y: 1750, w: 420, h: 290 }, { x: 2810, y: 0, w: 310, h: 650 },
        { x: 3020, y: 930, w: 520, h: 360 }, { x: 3300, y: 1640, w: 300, h: 400 },
        { x: 3650, y: 0, w: 280, h: 760 }, { x: 3880, y: 1050, w: 300, h: 990 },
        { x: 4210, y: 0, w: 590, h: 480 }, { x: 4360, y: 690, w: 440, h: 1350 },
        { x: 550, y: 1060, w: 150, h: 105 }, { x: 1120, y: 1380, w: 160, h: 105 },
        { x: 1890, y: 900, w: 150, h: 105 }, { x: 2680, y: 820, w: 150, h: 105 },
        { x: 3540, y: 870, w: 145, h: 100 }
      ],
      spikes: [
        { x: 760, y: 1280, count: 7, size: 25, dir: "up" },
        { x: 1260, y: 1240, count: 9, size: 25, dir: "down" },
        { x: 1880, y: 900, count: 7, size: 25, dir: "right" },
        { x: 2620, y: 1120, count: 9, size: 25, dir: "left" },
        { x: 3540, y: 1290, count: 8, size: 25, dir: "down" },
        { x: 3880, y: 1050, count: 7, size: 25, dir: "up" }
      ],
      movingWalls: [
        { x: 1775, y: 1280, w: 54, h: 260, axis: "y", amplitude: 180, speed: .72, phase: 0 },
        { x: 3600, y: 930, w: 52, h: 250, axis: "y", amplitude: 175, speed: .66, phase: 2.2 }
      ],
      zones: [
        { x: 820, y: 700, w: 520, h: 420, fx: 12, fy: -14, label: "POLVO DE EXTRACCIÓN" },
        { x: 2690, y: 660, w: 560, h: 420, fx: -18, fy: 3, label: "VENTEO DE MINA" }
      ],
      meteors: [
        { id: "05-M1", x: 1120, y: 1570, r: 28, axis: "x", amplitude: 190, speed: .62, phase: .3, hp: 3, score: 260, destructible: true },
        { id: "05-M2", x: 2310, y: 920, r: 36, axis: "circle", amplitude: 145, speed: .54, phase: 1.5, hp: 4, score: 380, destructible: true },
        { id: "05-M3", x: 3270, y: 760, r: 50, axis: "y", amplitude: 205, speed: .42, phase: .9, hp: 99, score: 0, destructible: false },
        { id: "05-M4", x: 4010, y: 810, r: 26, axis: "x", amplitude: 155, speed: .78, phase: 2.3, hp: 3, score: 300, destructible: true }
      ],
      rockfalls: [
        { id: "05-R1", trigger: { x: 1030, y: 620, w: 620, h: 620 }, origin: { x: 1440, y: 610 }, count: 6, interval: .46, delay: .35, spread: 230, rMin: 17, rMax: 29, vxMin: -55, vxMax: 35, vyMin: 75, vyMax: 130, score: 130 },
        { id: "05-R2", trigger: { x: 2360, y: 520, w: 760, h: 600 }, origin: { x: 2850, y: 430 }, count: 7, interval: .42, delay: .25, spread: 290, rMin: 18, rMax: 31, vxMin: -45, vxMax: 50, vyMin: 85, vyMax: 145, score: 150 },
        { id: "05-R3", trigger: { x: 3450, y: 650, w: 650, h: 610 }, origin: { x: 3830, y: 510 }, count: 8, interval: .38, delay: .2, spread: 260, rMin: 18, rMax: 30, vxMin: -60, vxMax: 35, vyMin: 90, vyMax: 155, score: 160 }
      ],
      anomalies: [],
      cells: [{ x: 1140, y: 720 }, { x: 2750, y: 760 }, { x: 3990, y: 920 }]
    },
    {
      id: 6,
      block: "BLOQUE II / DOMINIO",
      name: "Campo inverso",
      difficulty: "Gravedad",
      description: "Núcleos de atracción y repulsión deforman cada maniobra. Usa las fuerzas a tu favor y atraviesa las compuertas sin perder el control.",
      world: { w: 5100, h: 2200 },
      gravity: 185,
      thrust: 450,
      fuelBurn: 5.55,
      parTime: 214,
      baseScore: 12000,
      timeBonusMax: 2700,
      survivalBonus: 4000,
      start: { x: 120, y: 2070, w: 230, h: 18 },
      goal: { x: 4680, y: 520, w: 230, h: 18 },
      walls: [
        { x: 0, y: 0, w: 700, h: 360 }, { x: 0, y: 2140, w: 800, h: 60 },
        { x: 720, y: 1360, w: 230, h: 780 }, { x: 980, y: 0, w: 430, h: 620 },
        { x: 1290, y: 980, w: 220, h: 520 }, { x: 1530, y: 1660, w: 280, h: 480 },
        { x: 1830, y: 0, w: 330, h: 590 }, { x: 2160, y: 950, w: 260, h: 1190 },
        { x: 2470, y: 0, w: 300, h: 760 }, { x: 2810, y: 1250, w: 300, h: 890 },
        { x: 3160, y: 0, w: 300, h: 590 }, { x: 3490, y: 920, w: 260, h: 1220 },
        { x: 3790, y: 0, w: 310, h: 700 }, { x: 4140, y: 1180, w: 260, h: 960 },
        { x: 4440, y: 0, w: 660, h: 330 }, { x: 4610, y: 550, w: 490, h: 1590 },
        { x: 530, y: 1120, w: 145, h: 100 }, { x: 1120, y: 790, w: 150, h: 100 },
        { x: 1740, y: 780, w: 145, h: 100 }, { x: 2660, y: 920, w: 150, h: 105 },
        { x: 3370, y: 720, w: 145, h: 100 }, { x: 4070, y: 820, w: 145, h: 100 }
      ],
      spikes: [
        { x: 720, y: 1360, count: 7, size: 25, dir: "up" },
        { x: 1510, y: 1110, count: 8, size: 25, dir: "right" },
        { x: 2160, y: 950, count: 8, size: 25, dir: "up" },
        { x: 2770, y: 1250, count: 9, size: 25, dir: "left" },
        { x: 3490, y: 920, count: 8, size: 25, dir: "up" },
        { x: 4400, y: 1180, count: 8, size: 25, dir: "left" }
      ],
      movingWalls: [
        { x: 1450, y: 700, w: 54, h: 320, axis: "y", amplitude: 210, speed: .58, phase: .2 },
        { x: 2760, y: 760, w: 56, h: 340, axis: "y", amplitude: 245, speed: .54, phase: 2.1 },
        { x: 4050, y: 700, w: 56, h: 330, axis: "y", amplitude: 220, speed: .61, phase: 4.0 }
      ],
      zones: [],
      meteors: [
        { id: "06-M1", x: 1130, y: 1070, r: 25, axis: "circle", amplitude: 190, speed: .55, phase: .4, hp: 3, score: 300, destructible: true },
        { id: "06-M2", x: 2330, y: 790, r: 47, axis: "x", amplitude: 210, speed: .38, phase: 1.5, hp: 99, score: 0, destructible: false },
        { id: "06-M3", x: 3290, y: 880, r: 29, axis: "y", amplitude: 200, speed: .64, phase: 2.1, hp: 4, score: 400, destructible: true },
        { id: "06-M4", x: 4250, y: 870, r: 27, axis: "circle", amplitude: 170, speed: .72, phase: 3.3, hp: 3, score: 340, destructible: true }
      ],
      rockfalls: [],
      anomalies: [
        { id: "06-G1", x: 1050, y: 1050, radius: 390, core: 45, strength: 340, type: "attract", label: "GRAV-A" },
        { id: "06-G2", x: 1980, y: 920, radius: 420, core: 52, strength: 375, type: "repel", label: "GRAV-R" },
        { id: "06-G3", x: 2950, y: 900, radius: 430, core: 48, strength: 395, type: "attract", label: "GRAV-A" },
        { id: "06-G4", x: 3920, y: 900, radius: 420, core: 54, strength: 410, type: "repel", label: "GRAV-R" }
      ],
      cells: [{ x: 1240, y: 760 }, { x: 2860, y: 1060 }, { x: 4170, y: 720 }]
    },
    {
      id: 7,
      block: "BLOQUE III / SUPERVIVENCIA",
      name: "Aguanta",
      difficulty: "Ascenso extremo",
      description: "Un conducto vertical excavado en un meteorito. Asciende por el zigzag, sobrevive a los desprendimientos y alcanza STATION 07-B antes del tramo final.",
      verticalAscent: true,
      world: { w: 1800, h: 7600 },
      gravity: 192,
      thrust: 462,
      fuelBurn: 5.35,
      parTime: 390,
      baseScore: 15000,
      timeBonusMax: 3500,
      survivalBonus: 6000,
      start: { x: 690, y: 7440, w: 420, h: 18 },
      goal: { x: 650, y: 240, w: 500, h: 18 },
      walls: [
        { x: 0, y: 0, w: 250, h: 7600 }, { x: 1550, y: 0, w: 250, h: 7600 },
        { x: 0, y: 7520, w: 1800, h: 80 }, { x: 0, y: 0, w: 1800, h: 105 },
        { x: 250, y: 6560, w: 650, h: 520 }, { x: 900, y: 5740, w: 650, h: 520 },
        { x: 250, y: 4920, w: 730, h: 510 }, { x: 820, y: 4110, w: 730, h: 500 },
        { x: 250, y: 3370, w: 520, h: 400 }, { x: 1030, y: 3370, w: 520, h: 400 },
        { x: 250, y: 2510, w: 460, h: 500 }, { x: 900, y: 1740, w: 650, h: 500 },
        { x: 250, y: 960, w: 720, h: 500 }, { x: 850, y: 380, w: 700, h: 360 },
        { x: 250, y: 6200, w: 170, h: 110 }, { x: 1380, y: 5420, w: 170, h: 105 },
        { x: 250, y: 4620, w: 170, h: 105 }, { x: 1380, y: 3830, w: 170, h: 105 },
        { x: 250, y: 2240, w: 170, h: 105 }, { x: 1380, y: 1490, w: 170, h: 105 },
        { x: 250, y: 700, w: 170, h: 105 }
      ],
      spikes: [
        { x: 900, y: 6560, count: 8, size: 28, dir: "right" },
        { x: 900, y: 6260, count: 8, size: 28, dir: "left" },
        { x: 900, y: 5740, count: 8, size: 28, dir: "left" },
        { x: 980, y: 5200, count: 7, size: 28, dir: "right" },
        { x: 980, y: 4920, count: 8, size: 28, dir: "right" },
        { x: 820, y: 4380, count: 7, size: 28, dir: "left" },
        { x: 820, y: 4110, count: 8, size: 28, dir: "left" },
        { x: 770, y: 3500, count: 6, size: 28, dir: "right" },
        { x: 1030, y: 3500, count: 6, size: 28, dir: "left" },
        { x: 900, y: 2510, count: 8, size: 28, dir: "right" },
        { x: 900, y: 2240, count: 8, size: 28, dir: "left" },
        { x: 900, y: 1740, count: 8, size: 28, dir: "left" },
        { x: 970, y: 1220, count: 7, size: 28, dir: "right" },
        { x: 970, y: 960, count: 8, size: 28, dir: "right" },
        { x: 850, y: 650, count: 7, size: 28, dir: "left" }
      ],
      movingWalls: [
        { x: 1180, y: 6030, w: 58, h: 270, axis: "x", amplitude: 180, speed: .52, phase: .4 },
        { x: 550, y: 4460, w: 58, h: 255, axis: "x", amplitude: 170, speed: .58, phase: 2.2 },
        { x: 1120, y: 2020, w: 58, h: 265, axis: "x", amplitude: 190, speed: .54, phase: 4.1 }
      ],
      zones: [
        { x: 930, y: 6040, w: 500, h: 390, fx: -30, fy: -42, label: "UPDRAFT 07-A" },
        { x: 360, y: 5210, w: 500, h: 390, fx: 34, fy: -28, label: "CROSSWIND 07-B" },
        { x: 900, y: 4380, w: 500, h: 390, fx: -38, fy: -20, label: "WALL PUSH" },
        { x: 350, y: 2610, w: 540, h: 440, fx: 22, fy: -58, label: "ASCENT COLUMN" },
        { x: 930, y: 1810, w: 470, h: 400, fx: -34, fy: -34, label: "CROSSWIND 07-C" },
        { x: 360, y: 1030, w: 520, h: 420, fx: 30, fy: -44, label: "FINAL LIFT" }
      ],
      meteors: [
        { id: "07-M1", x: 1200, y: 6300, r: 25, axis: "x", amplitude: 170, speed: .62, phase: .4, hp: 3, score: 320, destructible: true },
        { id: "07-M2", x: 610, y: 5480, r: 44, axis: "x", amplitude: 150, speed: .42, phase: 1.8, hp: 99, score: 0, destructible: false },
        { id: "07-M3", x: 1230, y: 4690, r: 27, axis: "circle", amplitude: 115, speed: .68, phase: 2.4, hp: 3, score: 360, destructible: true },
        { id: "07-M4", x: 570, y: 2380, r: 28, axis: "x", amplitude: 165, speed: .7, phase: 3.1, hp: 4, score: 440, destructible: true },
        { id: "07-M5", x: 1190, y: 1570, r: 46, axis: "x", amplitude: 155, speed: .4, phase: 1.2, hp: 99, score: 0, destructible: false },
        { id: "07-M6", x: 610, y: 820, r: 26, axis: "circle", amplitude: 125, speed: .74, phase: 4.4, hp: 3, score: 390, destructible: true }
      ],
      rockfalls: [
        { id: "07-R1", trigger: { x: 350, y: 6100, w: 500, h: 470 }, origin: { x: 620, y: 5940 }, count: 7, interval: .38, delay: .2, spread: 300, rMin: 16, rMax: 29, vxMin: -70, vxMax: 45, vyMin: 95, vyMax: 165, score: 150 },
        { id: "07-R2", trigger: { x: 1000, y: 5200, w: 430, h: 470 }, origin: { x: 1210, y: 5030 }, count: 8, interval: .36, delay: .15, spread: 310, rMin: 17, rMax: 31, vxMin: -35, vxMax: 75, vyMin: 100, vyMax: 175, score: 160 },
        { id: "07-R3", trigger: { x: 330, y: 4350, w: 430, h: 460 }, origin: { x: 590, y: 4170 }, count: 8, interval: .34, delay: .15, spread: 320, rMin: 17, rMax: 31, vxMin: -75, vxMax: 35, vyMin: 105, vyMax: 180, score: 170 },
        { id: "07-R4", trigger: { x: 820, y: 2500, w: 600, h: 470 }, origin: { x: 1120, y: 2320 }, count: 9, interval: .32, delay: .12, spread: 340, rMin: 17, rMax: 32, vxMin: -35, vxMax: 80, vyMin: 110, vyMax: 190, score: 180 },
        { id: "07-R5", trigger: { x: 340, y: 1650, w: 500, h: 470 }, origin: { x: 610, y: 1470 }, count: 9, interval: .3, delay: .1, spread: 330, rMin: 18, rMax: 32, vxMin: -80, vxMax: 30, vyMin: 115, vyMax: 195, score: 190 },
        { id: "07-R6", trigger: { x: 1000, y: 850, w: 430, h: 450 }, origin: { x: 1210, y: 670 }, count: 10, interval: .28, delay: .08, spread: 350, rMin: 18, rMax: 33, vxMin: -35, vxMax: 85, vyMin: 120, vyMax: 205, score: 200 }
      ],
      anomalies: [],
      checkpoints: [
        { id: "STATION 07-B", x: 690, y: 3020, w: 420, h: 18, ascent: 61, refuel: true }
      ],
      variants: [
        {
          meteors: [{ id: "07-V1", x: 1110, y: 3560, r: 24, axis: "x", amplitude: 150, speed: .78, phase: .5, hp: 3, score: 360, destructible: true }],
          zones: [{ x: 370, y: 3750, w: 460, h: 340, fx: 28, fy: -24, label: "VARIANT / EAST WIND" }]
        },
        {
          spikes: [{ x: 250, y: 3180, count: 7, size: 27, dir: "right" }],
          meteors: [{ id: "07-V2", x: 680, y: 3900, r: 25, axis: "circle", amplitude: 115, speed: .72, phase: 2.8, hp: 3, score: 380, destructible: true }]
        },
        {
          movingWalls: [{ x: 870, y: 1260, w: 56, h: 240, axis: "x", amplitude: 170, speed: .6, phase: 1.4 }],
          zones: [{ x: 930, y: 3320, w: 470, h: 330, fx: -31, fy: -18, label: "VARIANT / WEST WIND" }]
        }
      ],
      cells: [{ x: 1180, y: 6150 }, { x: 610, y: 4470 }, { x: 1180, y: 1330 }]
    },
{
      "id": 8,
      "block": "BLOQUE III / SUPERVIVENCIA",
      "name": "Ruinas orbitales",
      "difficulty": "Combate técnico",
      "description": "Restos de estaciones y meteorito forman una ruta hostil. Neutraliza defensas antiguas, rompe compuertas y atraviesa zonas de navegación interferida.",
      "world": {
            "w": 5700,
            "h": 2400
      },
      "gravity": 214,
      "thrust": 470,
      "fuelBurn": 5.55,
      "parTime": 445,
      "baseScore": 17000,
      "timeBonusMax": 3900,
      "survivalBonus": 6800,
      "start": {
            "x": 120,
            "y": 2260,
            "w": 260,
            "h": 18
      },
      "goal": {
            "x": 5280,
            "y": 500,
            "w": 260,
            "h": 18
      },
      "walls": [
            {
                  "x": 0,
                  "y": 0,
                  "w": 690,
                  "h": 260
            },
            {
                  "x": 0,
                  "y": 2320,
                  "w": 860,
                  "h": 80
            },
            {
                  "x": 720,
                  "y": 1520,
                  "w": 260,
                  "h": 880
            },
            {
                  "x": 980,
                  "y": 0,
                  "w": 520,
                  "h": 470,
                  "material": "metal"
            },
            {
                  "x": 1060,
                  "y": 870,
                  "w": 360,
                  "h": 260,
                  "material": "metal"
            },
            {
                  "x": 1510,
                  "y": 1760,
                  "w": 390,
                  "h": 640
            },
            {
                  "x": 1780,
                  "y": 0,
                  "w": 340,
                  "h": 790,
                  "material": "metal"
            },
            {
                  "x": 2180,
                  "y": 1010,
                  "w": 330,
                  "h": 1390
            },
            {
                  "x": 2520,
                  "y": 0,
                  "w": 570,
                  "h": 430,
                  "material": "metal"
            },
            {
                  "x": 2780,
                  "y": 700,
                  "w": 330,
                  "h": 520,
                  "material": "metal"
            },
            {
                  "x": 3220,
                  "y": 1560,
                  "w": 390,
                  "h": 840
            },
            {
                  "x": 3480,
                  "y": 0,
                  "w": 360,
                  "h": 690,
                  "material": "metal"
            },
            {
                  "x": 3890,
                  "y": 830,
                  "w": 360,
                  "h": 250,
                  "material": "metal"
            },
            {
                  "x": 4240,
                  "y": 1460,
                  "w": 340,
                  "h": 940
            },
            {
                  "x": 4580,
                  "y": 0,
                  "w": 330,
                  "h": 500,
                  "material": "metal"
            },
            {
                  "x": 4860,
                  "y": 840,
                  "w": 270,
                  "h": 720,
                  "material": "metal"
            },
            {
                  "x": 5140,
                  "y": 518,
                  "w": 560,
                  "h": 1882
            },
            {
                  "x": 760,
                  "y": 1160,
                  "w": 180,
                  "h": 120
            },
            {
                  "x": 1600,
                  "y": 1180,
                  "w": 190,
                  "h": 110,
                  "material": "metal"
            },
            {
                  "x": 2650,
                  "y": 1390,
                  "w": 180,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 3650,
                  "y": 1080,
                  "w": 190,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 4630,
                  "y": 690,
                  "w": 190,
                  "h": 110,
                  "material": "metal"
            }
      ],
      "spikes": [
            {
                  "x": 720,
                  "y": 1520,
                  "count": 7,
                  "size": 28,
                  "dir": "up"
            },
            {
                  "x": 1420,
                  "y": 930,
                  "count": 7,
                  "size": 27,
                  "dir": "right"
            },
            {
                  "x": 2180,
                  "y": 1010,
                  "count": 8,
                  "size": 28,
                  "dir": "up"
            },
            {
                  "x": 3110,
                  "y": 820,
                  "count": 8,
                  "size": 28,
                  "dir": "right"
            },
            {
                  "x": 4240,
                  "y": 1460,
                  "count": 8,
                  "size": 28,
                  "dir": "up"
            },
            {
                  "x": 4860,
                  "y": 840,
                  "count": 7,
                  "size": 27,
                  "dir": "up"
            }
      ],
      "movingWalls": [
            {
                  "x": 1960,
                  "y": 790,
                  "w": 58,
                  "h": 260,
                  "axis": "y",
                  "amplitude": 190,
                  "speed": 0.5,
                  "phase": 0.4
            },
            {
                  "x": 3730,
                  "y": 1160,
                  "w": 60,
                  "h": 290,
                  "axis": "y",
                  "amplitude": 220,
                  "speed": 0.56,
                  "phase": 2.2
            }
      ],
      "zones": [
            {
                  "x": 620,
                  "y": 980,
                  "w": 530,
                  "h": 430,
                  "fx": 22,
                  "fy": -18,
                  "label": "VENT 08-A"
            },
            {
                  "x": 2860,
                  "y": 1230,
                  "w": 520,
                  "h": 360,
                  "fx": -26,
                  "fy": 8,
                  "label": "BREACH CURRENT"
            },
            {
                  "x": 4420,
                  "y": 520,
                  "w": 520,
                  "h": 360,
                  "fx": 20,
                  "fy": -22,
                  "label": "ORBITAL DRAFT"
            }
      ],
      "meteors": [
            {
                  "id": "08-M1",
                  "x": 760,
                  "y": 980,
                  "r": 25,
                  "axis": "y",
                  "amplitude": 170,
                  "speed": 0.72,
                  "phase": 0.4,
                  "hp": 3,
                  "score": 340,
                  "destructible": true
            },
            {
                  "id": "08-M2",
                  "x": 2380,
                  "y": 720,
                  "r": 45,
                  "axis": "x",
                  "amplitude": 190,
                  "speed": 0.42,
                  "phase": 1.7,
                  "hp": 99,
                  "score": 0,
                  "destructible": false
            },
            {
                  "id": "08-M3",
                  "x": 4140,
                  "y": 1180,
                  "r": 29,
                  "axis": "circle",
                  "amplitude": 150,
                  "speed": 0.68,
                  "phase": 2.6,
                  "hp": 4,
                  "score": 420,
                  "destructible": true
            },
            {
                  "id": "08-M4",
                  "x": 5000,
                  "y": 600,
                  "r": 25,
                  "axis": "x",
                  "amplitude": 130,
                  "speed": 0.82,
                  "phase": 3.5,
                  "hp": 3,
                  "score": 380,
                  "destructible": true
            }
      ],
      "rockfalls": [],
      "anomalies": [],
      "checkpoints": [],
      "turrets": [
            {
                  "id": "08-T1",
                  "x": 1160,
                  "y": 830,
                  "range": 850,
                  "fireRate": 2.25,
                  "projectileSpeed": 190,
                  "hp": 4,
                  "score": 650,
                  "phase": 0.3
            },
            {
                  "id": "08-T2",
                  "x": 1860,
                  "y": 880,
                  "range": 900,
                  "fireRate": 2.05,
                  "projectileSpeed": 205,
                  "hp": 5,
                  "score": 750,
                  "phase": 1.1
            },
            {
                  "id": "08-T3",
                  "x": 2940,
                  "y": 650,
                  "range": 920,
                  "fireRate": 1.95,
                  "projectileSpeed": 210,
                  "hp": 5,
                  "score": 800,
                  "phase": 2.2
            },
            {
                  "id": "08-T4",
                  "x": 3970,
                  "y": 780,
                  "range": 960,
                  "fireRate": 1.82,
                  "projectileSpeed": 220,
                  "hp": 6,
                  "score": 900,
                  "phase": 3.4
            },
            {
                  "id": "08-T5",
                  "x": 4720,
                  "y": 630,
                  "range": 980,
                  "fireRate": 1.72,
                  "projectileSpeed": 230,
                  "hp": 6,
                  "score": 950,
                  "phase": 4.1
            }
      ],
      "mines": [
            {
                  "id": "08-N1",
                  "x": 920,
                  "y": 1430,
                  "trigger": 145,
                  "blast": 118,
                  "score": 280
            },
            {
                  "id": "08-N2",
                  "x": 1560,
                  "y": 1040,
                  "trigger": 145,
                  "blast": 120,
                  "score": 300
            },
            {
                  "id": "08-N3",
                  "x": 2550,
                  "y": 940,
                  "trigger": 150,
                  "blast": 124,
                  "score": 320
            },
            {
                  "id": "08-N4",
                  "x": 3380,
                  "y": 1160,
                  "trigger": 155,
                  "blast": 128,
                  "score": 340
            },
            {
                  "id": "08-N5",
                  "x": 4320,
                  "y": 910,
                  "trigger": 155,
                  "blast": 128,
                  "score": 360
            },
            {
                  "id": "08-N6",
                  "x": 5040,
                  "y": 430,
                  "trigger": 160,
                  "blast": 132,
                  "score": 380
            }
      ],
      "doors": [
            {
                  "id": "08-D1",
                  "x": 1450,
                  "y": 760,
                  "w": 58,
                  "h": 360,
                  "hp": 7,
                  "score": 900,
                  "required": true
            },
            {
                  "id": "08-D2",
                  "x": 3110,
                  "y": 720,
                  "w": 58,
                  "h": 390,
                  "hp": 8,
                  "score": 1050,
                  "required": true
            },
            {
                  "id": "08-D3",
                  "x": 4550,
                  "y": 510,
                  "w": 58,
                  "h": 360,
                  "hp": 9,
                  "score": 1200,
                  "required": true
            }
      ],
      "jammers": [
            {
                  "id": "JAM-08-A",
                  "x": 1700,
                  "y": 640,
                  "w": 760,
                  "h": 720,
                  "strength": 0.9
            },
            {
                  "id": "JAM-08-B",
                  "x": 3820,
                  "y": 520,
                  "w": 820,
                  "h": 760,
                  "strength": 1
            }
      ],
      "satellites": [
            {
                  "x": 1280,
                  "y": 620,
                  "scale": 1.05,
                  "rotation": -0.18
            },
            {
                  "x": 3340,
                  "y": 780,
                  "scale": 0.9,
                  "rotation": 0.28
            },
            {
                  "x": 4700,
                  "y": 360,
                  "scale": 1.2,
                  "rotation": -0.08
            }
      ],
      "orbitalPlatforms": [],
      "cells": [
            {
                  "x": 1320,
                  "y": 1360
            },
            {
                  "x": 3560,
                  "y": 1280
            },
            {
                  "x": 4940,
                  "y": 350
            }
      ]
},
{
      "id": 9,
      "block": "BLOQUE III / SUPERVIVENCIA",
      "name": "Última órbita",
      "difficulty": "Aproximación terrestre",
      "description": "La Tierra llena el horizonte. La gravedad crece, los escombros aceleran y las últimas estructuras orbitales convierten cada corrección en una decisión de combustible.",
      "earthBackdrop": true,
      "world": {
            "w": 6600,
            "h": 2800
      },
      "gravity": 205,
      "earthGravity": {
            "start": 0,
            "end": 145,
            "curve": 1.7
      },
      "thrust": 480,
      "fuelBurn": 5.8,
      "parTime": 535,
      "baseScore": 19500,
      "timeBonusMax": 4300,
      "survivalBonus": 7600,
      "start": {
            "x": 120,
            "y": 2660,
            "w": 280,
            "h": 18
      },
      "goal": {
            "x": 6150,
            "y": 520,
            "w": 280,
            "h": 18
      },
      "walls": [
            {
                  "x": 0,
                  "y": 0,
                  "w": 620,
                  "h": 290
            },
            {
                  "x": 0,
                  "y": 2720,
                  "w": 850,
                  "h": 80
            },
            {
                  "x": 780,
                  "y": 1770,
                  "w": 300,
                  "h": 1030
            },
            {
                  "x": 1120,
                  "y": 0,
                  "w": 520,
                  "h": 520,
                  "material": "metal"
            },
            {
                  "x": 1420,
                  "y": 1040,
                  "w": 300,
                  "h": 400,
                  "material": "metal"
            },
            {
                  "x": 1830,
                  "y": 1950,
                  "w": 380,
                  "h": 850
            },
            {
                  "x": 2140,
                  "y": 0,
                  "w": 340,
                  "h": 820,
                  "material": "metal"
            },
            {
                  "x": 2580,
                  "y": 960,
                  "w": 340,
                  "h": 650
            },
            {
                  "x": 3000,
                  "y": 2050,
                  "w": 410,
                  "h": 750
            },
            {
                  "x": 3350,
                  "y": 0,
                  "w": 380,
                  "h": 700,
                  "material": "metal"
            },
            {
                  "x": 3810,
                  "y": 980,
                  "w": 360,
                  "h": 560,
                  "material": "metal"
            },
            {
                  "x": 4260,
                  "y": 1840,
                  "w": 400,
                  "h": 960
            },
            {
                  "x": 4680,
                  "y": 0,
                  "w": 380,
                  "h": 620,
                  "material": "metal"
            },
            {
                  "x": 5120,
                  "y": 900,
                  "w": 330,
                  "h": 540
            },
            {
                  "x": 5520,
                  "y": 1640,
                  "w": 360,
                  "h": 1160
            },
            {
                  "x": 5980,
                  "y": 538,
                  "w": 620,
                  "h": 2262
            },
            {
                  "x": 900,
                  "y": 1420,
                  "w": 170,
                  "h": 110
            },
            {
                  "x": 1780,
                  "y": 1120,
                  "w": 180,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 2870,
                  "y": 1650,
                  "w": 180,
                  "h": 110
            },
            {
                  "x": 4020,
                  "y": 720,
                  "w": 190,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 5200,
                  "y": 600,
                  "w": 180,
                  "h": 110
            }
      ],
      "spikes": [
            {
                  "x": 780,
                  "y": 1770,
                  "count": 8,
                  "size": 29,
                  "dir": "up"
            },
            {
                  "x": 1720,
                  "y": 1120,
                  "count": 7,
                  "size": 28,
                  "dir": "right"
            },
            {
                  "x": 2580,
                  "y": 960,
                  "count": 8,
                  "size": 29,
                  "dir": "up"
            },
            {
                  "x": 3730,
                  "y": 980,
                  "count": 8,
                  "size": 29,
                  "dir": "right"
            },
            {
                  "x": 4260,
                  "y": 1840,
                  "count": 8,
                  "size": 29,
                  "dir": "up"
            },
            {
                  "x": 5450,
                  "y": 960,
                  "count": 8,
                  "size": 29,
                  "dir": "right"
            }
      ],
      "movingWalls": [
            {
                  "x": 2360,
                  "y": 920,
                  "w": 60,
                  "h": 310,
                  "axis": "y",
                  "amplitude": 230,
                  "speed": 0.54,
                  "phase": 0.8
            },
            {
                  "x": 4920,
                  "y": 850,
                  "w": 60,
                  "h": 320,
                  "axis": "y",
                  "amplitude": 240,
                  "speed": 0.61,
                  "phase": 2.7
            }
      ],
      "orbitalPlatforms": [
            {
                  "id": "09-P1",
                  "x": 1240,
                  "y": 1550,
                  "w": 250,
                  "h": 20,
                  "axis": "y",
                  "amplitude": 180,
                  "speed": 0.48,
                  "phase": 0.2,
                  "style": "platform"
            },
            {
                  "id": "09-P2",
                  "x": 2480,
                  "y": 1730,
                  "w": 230,
                  "h": 20,
                  "axis": "x",
                  "amplitude": 220,
                  "speed": 0.55,
                  "phase": 1.6,
                  "style": "platform"
            },
            {
                  "id": "09-P3",
                  "x": 3600,
                  "y": 840,
                  "w": 250,
                  "h": 20,
                  "axis": "y",
                  "amplitude": 190,
                  "speed": 0.58,
                  "phase": 2.8,
                  "style": "platform"
            },
            {
                  "id": "09-P4",
                  "x": 4740,
                  "y": 1280,
                  "w": 230,
                  "h": 20,
                  "axis": "x",
                  "amplitude": 250,
                  "speed": 0.63,
                  "phase": 4,
                  "style": "platform"
            },
            {
                  "id": "09-P5",
                  "x": 5660,
                  "y": 720,
                  "w": 240,
                  "h": 20,
                  "axis": "y",
                  "amplitude": 170,
                  "speed": 0.68,
                  "phase": 5.1,
                  "style": "platform"
            }
      ],
      "zones": [
            {
                  "x": 560,
                  "y": 1360,
                  "w": 620,
                  "h": 430,
                  "fx": 26,
                  "fy": -22,
                  "label": "ORBITAL WAKE"
            },
            {
                  "x": 2740,
                  "y": 1120,
                  "w": 560,
                  "h": 430,
                  "fx": -30,
                  "fy": 10,
                  "label": "DEBRIS CURRENT"
            },
            {
                  "x": 4800,
                  "y": 660,
                  "w": 560,
                  "h": 440,
                  "fx": 22,
                  "fy": 30,
                  "label": "EARTH PULL"
            }
      ],
      "meteors": [
            {
                  "id": "09-M1",
                  "x": 930,
                  "y": 1160,
                  "r": 27,
                  "path": [
                        {
                              "x": 760,
                              "y": 900
                        },
                        {
                              "x": 1180,
                              "y": 900
                        },
                        {
                              "x": 1180,
                              "y": 1460
                        },
                        {
                              "x": 760,
                              "y": 1460
                        }
                  ],
                  "period": 5.8,
                  "phase": 0,
                  "hp": 3,
                  "score": 380,
                  "destructible": true
            },
            {
                  "id": "09-M2",
                  "x": 1850,
                  "y": 980,
                  "r": 48,
                  "axis": "x",
                  "amplitude": 260,
                  "speed": 0.72,
                  "phase": 1.2,
                  "hp": 99,
                  "score": 0,
                  "destructible": false
            },
            {
                  "id": "09-M3",
                  "x": 3060,
                  "y": 1080,
                  "r": 29,
                  "path": [
                        {
                              "x": 2860,
                              "y": 760
                        },
                        {
                              "x": 3260,
                              "y": 760
                        },
                        {
                              "x": 3260,
                              "y": 1420
                        },
                        {
                              "x": 2860,
                              "y": 1420
                        }
                  ],
                  "period": 5.2,
                  "phase": 0.35,
                  "hp": 4,
                  "score": 460,
                  "destructible": true
            },
            {
                  "id": "09-M4",
                  "x": 4200,
                  "y": 900,
                  "r": 51,
                  "axis": "circle",
                  "amplitude": 220,
                  "speed": 0.7,
                  "phase": 2.6,
                  "hp": 99,
                  "score": 0,
                  "destructible": false
            },
            {
                  "id": "09-M5",
                  "x": 5300,
                  "y": 720,
                  "r": 28,
                  "path": [
                        {
                              "x": 5080,
                              "y": 520
                        },
                        {
                              "x": 5480,
                              "y": 520
                        },
                        {
                              "x": 5480,
                              "y": 1060
                        },
                        {
                              "x": 5080,
                              "y": 1060
                        }
                  ],
                  "period": 4.8,
                  "phase": 0.65,
                  "hp": 4,
                  "score": 520,
                  "destructible": true
            },
            {
                  "id": "09-M6",
                  "x": 5900,
                  "y": 470,
                  "r": 26,
                  "axis": "x",
                  "amplitude": 150,
                  "speed": 1.02,
                  "phase": 4.1,
                  "hp": 3,
                  "score": 480,
                  "destructible": true
            }
      ],
      "rockfalls": [],
      "anomalies": [
            {
                  "id": "09-G1",
                  "x": 2300,
                  "y": 1450,
                  "radius": 520,
                  "core": 34,
                  "strength": 190,
                  "type": "attract",
                  "label": "EARTH LENS A"
            },
            {
                  "id": "09-G2",
                  "x": 4010,
                  "y": 1120,
                  "radius": 500,
                  "core": 32,
                  "strength": 175,
                  "type": "repel",
                  "label": "DEBRIS SHIELD"
            },
            {
                  "id": "09-G3",
                  "x": 5480,
                  "y": 880,
                  "radius": 560,
                  "core": 36,
                  "strength": 215,
                  "type": "attract",
                  "label": "EARTH LENS B"
            }
      ],
      "checkpoints": [],
      "turrets": [
            {
                  "id": "09-T1",
                  "x": 1530,
                  "y": 990,
                  "range": 940,
                  "fireRate": 1.82,
                  "projectileSpeed": 225,
                  "hp": 5,
                  "score": 850,
                  "phase": 0.7
            },
            {
                  "id": "09-T2",
                  "x": 3920,
                  "y": 930,
                  "range": 1020,
                  "fireRate": 1.65,
                  "projectileSpeed": 240,
                  "hp": 6,
                  "score": 980,
                  "phase": 2.4
            },
            {
                  "id": "09-T3",
                  "x": 5230,
                  "y": 850,
                  "range": 1080,
                  "fireRate": 1.55,
                  "projectileSpeed": 250,
                  "hp": 7,
                  "score": 1100,
                  "phase": 4.2
            }
      ],
      "mines": [
            {
                  "id": "09-N1",
                  "x": 1280,
                  "y": 1260,
                  "trigger": 150,
                  "blast": 124,
                  "score": 320
            },
            {
                  "id": "09-N2",
                  "x": 2750,
                  "y": 940,
                  "trigger": 155,
                  "blast": 128,
                  "score": 350
            },
            {
                  "id": "09-N3",
                  "x": 4460,
                  "y": 1080,
                  "trigger": 160,
                  "blast": 132,
                  "score": 390
            },
            {
                  "id": "09-N4",
                  "x": 5720,
                  "y": 560,
                  "trigger": 165,
                  "blast": 136,
                  "score": 420
            }
      ],
      "doors": [
            {
                  "id": "09-D1",
                  "x": 2070,
                  "y": 820,
                  "w": 60,
                  "h": 390,
                  "hp": 9,
                  "score": 1200,
                  "required": true
            },
            {
                  "id": "09-D2",
                  "x": 5010,
                  "y": 620,
                  "w": 60,
                  "h": 390,
                  "hp": 10,
                  "score": 1400,
                  "required": true
            }
      ],
      "jammers": [
            {
                  "id": "JAM-09-A",
                  "x": 3300,
                  "y": 520,
                  "w": 920,
                  "h": 920,
                  "strength": 0.85
            }
      ],
      "satellites": [
            {
                  "x": 1340,
                  "y": 760,
                  "scale": 1.25,
                  "rotation": -0.24
            },
            {
                  "x": 3550,
                  "y": 620,
                  "scale": 1.05,
                  "rotation": 0.18
            },
            {
                  "x": 5120,
                  "y": 460,
                  "scale": 1.35,
                  "rotation": -0.12
            }
      ],
      "cells": [
            {
                  "x": 1460,
                  "y": 1500
            },
            {
                  "x": 3710,
                  "y": 760
            },
            {
                  "x": 5680,
                  "y": 440
            }
      ]
},
{
      "id": 10,
      "block": "FINAL / REGRESO A LA TIERRA",
      "name": "Regreso a la Tierra",
      "difficulty": "Misión final",
      "description": "Cruza el campo de escombros, sobrevive a la entrada atmosférica y aterriza la TAS-01 en la última plataforma terrestre.",
      "finalMission": true,
      "earthBackdrop": true,
      "earthLanding": true,
      "world": {
            "w": 9800,
            "h": 3600
      },
      "gravity": 190,
      "earthGravity": {
            "start": 20,
            "end": 285,
            "curve": 1.65
      },
      "atmosphere": {
            "startX": 3350,
            "peakX": 6150,
            "endX": 8350,
            "turbulence": 54,
            "thrustLoss": 0.29,
            "criticalHeat": 98
      },
      "thrust": 498,
      "fuelBurn": 5.95,
      "parTime": 780,
      "baseScore": 30000,
      "timeBonusMax": 6500,
      "survivalBonus": 12000,
      "start": {
            "x": 130,
            "y": 3420,
            "w": 300,
            "h": 18
      },
      "goal": {
            "x": 9250,
            "y": 3360,
            "w": 360,
            "h": 18
      },
      "walls": [
            {
                  "x": 0,
                  "y": 0,
                  "w": 720,
                  "h": 450
            },
            {
                  "x": 0,
                  "y": 3480,
                  "w": 920,
                  "h": 120
            },
            {
                  "x": 760,
                  "y": 2260,
                  "w": 310,
                  "h": 1220
            },
            {
                  "x": 1120,
                  "y": 0,
                  "w": 620,
                  "h": 720,
                  "material": "metal"
            },
            {
                  "x": 1480,
                  "y": 1300,
                  "w": 300,
                  "h": 470,
                  "material": "metal"
            },
            {
                  "x": 1840,
                  "y": 2800,
                  "w": 430,
                  "h": 680
            },
            {
                  "x": 2230,
                  "y": 0,
                  "w": 360,
                  "h": 1040,
                  "material": "metal"
            },
            {
                  "x": 2700,
                  "y": 1680,
                  "w": 350,
                  "h": 620
            },
            {
                  "x": 3130,
                  "y": 2920,
                  "w": 420,
                  "h": 680
            },
            {
                  "x": 3520,
                  "y": 0,
                  "w": 430,
                  "h": 850,
                  "material": "metal"
            },
            {
                  "x": 4020,
                  "y": 1640,
                  "w": 420,
                  "h": 720
            },
            {
                  "x": 4480,
                  "y": 3020,
                  "w": 500,
                  "h": 580
            },
            {
                  "x": 4930,
                  "y": 0,
                  "w": 420,
                  "h": 720,
                  "material": "metal"
            },
            {
                  "x": 5480,
                  "y": 1280,
                  "w": 370,
                  "h": 600
            },
            {
                  "x": 6020,
                  "y": 2700,
                  "w": 450,
                  "h": 900
            },
            {
                  "x": 6460,
                  "y": 0,
                  "w": 390,
                  "h": 930,
                  "material": "metal"
            },
            {
                  "x": 6960,
                  "y": 1260,
                  "w": 380,
                  "h": 540
            },
            {
                  "x": 7410,
                  "y": 3000,
                  "w": 450,
                  "h": 600
            },
            {
                  "x": 7870,
                  "y": 0,
                  "w": 430,
                  "h": 1160
            },
            {
                  "x": 8360,
                  "y": 1500,
                  "w": 340,
                  "h": 600
            },
            {
                  "x": 8750,
                  "y": 0,
                  "w": 1050,
                  "h": 520
            },
            {
                  "x": 8860,
                  "y": 3420,
                  "w": 940,
                  "h": 180
            },
            {
                  "x": 930,
                  "y": 1820,
                  "w": 180,
                  "h": 120
            },
            {
                  "x": 1760,
                  "y": 2060,
                  "w": 190,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 2640,
                  "y": 1260,
                  "w": 190,
                  "h": 115
            },
            {
                  "x": 3650,
                  "y": 1190,
                  "w": 210,
                  "h": 115,
                  "material": "metal"
            },
            {
                  "x": 4720,
                  "y": 2250,
                  "w": 200,
                  "h": 115
            },
            {
                  "x": 5740,
                  "y": 900,
                  "w": 200,
                  "h": 110,
                  "material": "metal"
            },
            {
                  "x": 6760,
                  "y": 2070,
                  "w": 200,
                  "h": 115
            },
            {
                  "x": 8020,
                  "y": 1980,
                  "w": 200,
                  "h": 110
            },
            {
                  "x": 8580,
                  "y": 2740,
                  "w": 180,
                  "h": 115
            }
      ],
      "spikes": [
            {
                  "x": 760,
                  "y": 2260,
                  "count": 9,
                  "size": 30,
                  "dir": "up"
            },
            {
                  "x": 1780,
                  "y": 1510,
                  "count": 8,
                  "size": 29,
                  "dir": "right"
            },
            {
                  "x": 2700,
                  "y": 1680,
                  "count": 9,
                  "size": 30,
                  "dir": "up"
            },
            {
                  "x": 3950,
                  "y": 1650,
                  "count": 9,
                  "size": 30,
                  "dir": "right"
            },
            {
                  "x": 5480,
                  "y": 1280,
                  "count": 9,
                  "size": 30,
                  "dir": "up"
            },
            {
                  "x": 6850,
                  "y": 1270,
                  "count": 8,
                  "size": 29,
                  "dir": "right"
            },
            {
                  "x": 7410,
                  "y": 3000,
                  "count": 9,
                  "size": 30,
                  "dir": "up"
            },
            {
                  "x": 8300,
                  "y": 1540,
                  "count": 8,
                  "size": 28,
                  "dir": "right"
            }
      ],
      "movingWalls": [
            {
                  "x": 2380,
                  "y": 1160,
                  "w": 62,
                  "h": 340,
                  "axis": "y",
                  "amplitude": 250,
                  "speed": 0.64,
                  "phase": 0.7
            },
            {
                  "x": 5220,
                  "y": 900,
                  "w": 62,
                  "h": 350,
                  "axis": "y",
                  "amplitude": 260,
                  "speed": 0.58,
                  "phase": 2.1
            }
      ],
      "orbitalPlatforms": [
            {
                  "id": "10-P1",
                  "x": 1320,
                  "y": 2380,
                  "w": 260,
                  "h": 20,
                  "axis": "y",
                  "amplitude": 210,
                  "speed": 0.62,
                  "phase": 0.3,
                  "style": "platform"
            },
            {
                  "id": "10-P2",
                  "x": 2120,
                  "y": 1900,
                  "w": 250,
                  "h": 20,
                  "axis": "x",
                  "amplitude": 250,
                  "speed": 0.7,
                  "phase": 1.7,
                  "style": "platform"
            },
            {
                  "id": "10-P3",
                  "x": 3900,
                  "y": 1330,
                  "w": 250,
                  "h": 20,
                  "axis": "y",
                  "amplitude": 190,
                  "speed": 0.61,
                  "phase": 3.1,
                  "style": "platform"
            }
      ],
      "zones": [
            {
                  "x": 520,
                  "y": 1940,
                  "w": 650,
                  "h": 500,
                  "fx": 28,
                  "fy": -20,
                  "label": "DEBRIS WAKE"
            },
            {
                  "x": 2300,
                  "y": 1170,
                  "w": 650,
                  "h": 540,
                  "fx": -34,
                  "fy": 16,
                  "label": "SATELLITE CURRENT"
            },
            {
                  "x": 3660,
                  "y": 920,
                  "w": 730,
                  "h": 620,
                  "fx": 26,
                  "fy": 42,
                  "label": "UPPER ATMOSPHERE"
            },
            {
                  "x": 4700,
                  "y": 1280,
                  "w": 760,
                  "h": 680,
                  "fx": -42,
                  "fy": 30,
                  "label": "ION TURBULENCE"
            },
            {
                  "x": 5800,
                  "y": 900,
                  "w": 800,
                  "h": 760,
                  "fx": 44,
                  "fy": 54,
                  "label": "THERMAL SHEAR"
            },
            {
                  "x": 7000,
                  "y": 1500,
                  "w": 700,
                  "h": 850,
                  "fx": -48,
                  "fy": 72,
                  "label": "DESCENT WIND A"
            },
            {
                  "x": 7800,
                  "y": 1850,
                  "w": 700,
                  "h": 850,
                  "fx": 55,
                  "fy": 88,
                  "label": "DESCENT WIND B"
            },
            {
                  "x": 8500,
                  "y": 2400,
                  "w": 650,
                  "h": 720,
                  "fx": -38,
                  "fy": 72,
                  "label": "FINAL CROSSWIND"
            }
      ],
      "meteors": [
            {
                  "id": "10-M1",
                  "x": 980,
                  "y": 1600,
                  "r": 29,
                  "path": [
                        {
                              "x": 760,
                              "y": 1350
                        },
                        {
                              "x": 1240,
                              "y": 1350
                        },
                        {
                              "x": 1240,
                              "y": 2100
                        },
                        {
                              "x": 760,
                              "y": 2100
                        }
                  ],
                  "period": 4.9,
                  "phase": 0,
                  "hp": 3,
                  "score": 450,
                  "destructible": true
            },
            {
                  "id": "10-M2",
                  "x": 1700,
                  "y": 1450,
                  "r": 55,
                  "axis": "x",
                  "amplitude": 290,
                  "speed": 0.82,
                  "phase": 1.1,
                  "hp": 99,
                  "score": 0,
                  "destructible": false
            },
            {
                  "id": "10-M3",
                  "x": 2560,
                  "y": 1240,
                  "r": 31,
                  "path": [
                        {
                              "x": 2300,
                              "y": 900
                        },
                        {
                              "x": 2800,
                              "y": 900
                        },
                        {
                              "x": 2800,
                              "y": 1650
                        },
                        {
                              "x": 2300,
                              "y": 1650
                        }
                  ],
                  "period": 4.6,
                  "phase": 0.42,
                  "hp": 4,
                  "score": 540,
                  "destructible": true
            },
            {
                  "id": "10-M4",
                  "x": 3180,
                  "y": 1040,
                  "r": 58,
                  "axis": "circle",
                  "amplitude": 230,
                  "speed": 0.8,
                  "phase": 2.5,
                  "hp": 99,
                  "score": 0,
                  "destructible": false
            },
            {
                  "id": "10-M5",
                  "x": 3980,
                  "y": 1050,
                  "r": 30,
                  "axis": "x",
                  "amplitude": 260,
                  "speed": 1.0,
                  "phase": 3.1,
                  "hp": 4,
                  "score": 580,
                  "destructible": true
            },
            {
                  "id": "10-M6",
                  "x": 4720,
                  "y": 1200,
                  "r": 27,
                  "axis": "circle",
                  "amplitude": 180,
                  "speed": 0.88,
                  "phase": 4.2,
                  "hp": 3,
                  "score": 520,
                  "destructible": true
            }
      ],
      "rockfalls": [],
      "anomalies": [
            {
                  "id": "10-G1",
                  "x": 2050,
                  "y": 1770,
                  "radius": 560,
                  "core": 35,
                  "strength": 220,
                  "type": "repel",
                  "label": "DEBRIS SHOCK"
            },
            {
                  "id": "10-G2",
                  "x": 4450,
                  "y": 1250,
                  "radius": 620,
                  "core": 38,
                  "strength": 245,
                  "type": "attract",
                  "label": "ATMOSPHERIC LENS"
            }
      ],
      "checkpoints": [
            {
                  "id": "STATION 10-A",
                  "phase": "CAMPO DE ESCOMBROS",
                  "x": 3020,
                  "y": 2440,
                  "w": 390,
                  "h": 18,
                  "ascent": 32,
                  "refuel": true,
                  "fuelTarget": 100
            },
            {
                  "id": "STATION 10-B",
                  "phase": "ENTRADA ATMOSFÉRICA",
                  "x": 6170,
                  "y": 1900,
                  "w": 390,
                  "h": 18,
                  "ascent": 65,
                  "refuel": true,
                  "fuelTarget": 82
            },
            {
                  "id": "STATION 10-C",
                  "phase": "DESCENSO FINAL",
                  "x": 7800,
                  "y": 2520,
                  "w": 360,
                  "h": 18,
                  "ascent": 82,
                  "refuel": true,
                  "fuelTarget": 48
            }
      ],
      "turrets": [
            {
                  "id": "10-T1",
                  "x": 1180,
                  "y": 1740,
                  "range": 1050,
                  "fireRate": 1.45,
                  "projectileSpeed": 270,
                  "hp": 7,
                  "score": 1100,
                  "phase": 0.4
            },
            {
                  "id": "10-T2",
                  "x": 2220,
                  "y": 1320,
                  "range": 1120,
                  "fireRate": 1.32,
                  "projectileSpeed": 285,
                  "hp": 8,
                  "score": 1300,
                  "phase": 1.9
            },
            {
                  "id": "10-T3",
                  "x": 3460,
                  "y": 1120,
                  "range": 1180,
                  "fireRate": 1.25,
                  "projectileSpeed": 295,
                  "hp": 9,
                  "score": 1500,
                  "phase": 3.5
            }
      ],
      "mines": [
            {
                  "id": "10-N1",
                  "x": 1450,
                  "y": 2050,
                  "trigger": 165,
                  "blast": 138,
                  "score": 400
            },
            {
                  "id": "10-N2",
                  "x": 2760,
                  "y": 1320,
                  "trigger": 170,
                  "blast": 142,
                  "score": 440
            },
            {
                  "id": "10-N3",
                  "x": 3710,
                  "y": 980,
                  "trigger": 175,
                  "blast": 146,
                  "score": 480
            }
      ],
      "doors": [
            {
                  "id": "10-D1",
                  "x": 1980,
                  "y": 1060,
                  "w": 64,
                  "h": 430,
                  "hp": 10,
                  "score": 1500,
                  "required": true
            },
            {
                  "id": "10-D2",
                  "x": 3350,
                  "y": 850,
                  "w": 64,
                  "h": 450,
                  "hp": 11,
                  "score": 1700,
                  "required": true
            }
      ],
      "jammers": [
            {
                  "id": "JAM-10-A",
                  "x": 900,
                  "y": 1000,
                  "w": 1600,
                  "h": 1450,
                  "strength": 0.82
            }
      ],
      "satellites": [
            {
                  "x": 920,
                  "y": 760,
                  "scale": 1.35,
                  "rotation": -0.28
            },
            {
                  "x": 2150,
                  "y": 720,
                  "scale": 1.15,
                  "rotation": 0.24
            },
            {
                  "x": 3300,
                  "y": 620,
                  "scale": 1.45,
                  "rotation": -0.12
            },
            {
                  "x": 4380,
                  "y": 640,
                  "scale": 1.05,
                  "rotation": 0.18
            }
      ],
      "cells": [
            {
                  "x": 1740,
                  "y": 2240
            },
            {
                  "x": 5140,
                  "y": 1120
            },
            {
                  "x": 8360,
                  "y": 2380
            }
      ]
}
  ];

  const FINAL_BALANCE = Object.freeze({
    1: { fuelBurn: 4.55, thrust: 438, parTime: 88, baseScore: 5500, timeBonusMax: 1100, survivalBonus: 1800, goalWidth: 250, cellFuel: 10, landingSpeed: 132, landingAngle: .58 },
    2: { fuelBurn: 4.68, thrust: 450, parTime: 128, baseScore: 7000, timeBonusMax: 1500, survivalBonus: 2300, goalWidth: 270, cellFuel: 11, landingSpeed: 130, landingAngle: .56 },
    3: { fuelBurn: 4.9, thrust: 452, parTime: 145, baseScore: 8500, timeBonusMax: 1800, survivalBonus: 2700, goalWidth: 250, cellFuel: 10, landingSpeed: 128, landingAngle: .55 },
    4: { fuelBurn: 5.02, thrust: 458, parTime: 178, baseScore: 9500, timeBonusMax: 2200, survivalBonus: 3200, goalWidth: 245, cellFuel: 10, landingSpeed: 126, landingAngle: .54 },
    5: { fuelBurn: 5.14, thrust: 466, parTime: 220, baseScore: 11000, timeBonusMax: 2500, survivalBonus: 3700, goalWidth: 255, cellFuel: 10, landingSpeed: 124, landingAngle: .53 },
    6: { fuelBurn: 5.18, thrust: 474, parTime: 255, baseScore: 12500, timeBonusMax: 2850, survivalBonus: 4300, goalWidth: 260, cellFuel: 10, landingSpeed: 122, landingAngle: .52 },
    7: { fuelBurn: 4.92, thrust: 486, parTime: 475, baseScore: 16000, timeBonusMax: 3600, survivalBonus: 6200, goalWidth: 560, cellFuel: 12, landingSpeed: 120, landingAngle: .51 },
    8: { fuelBurn: 5.12, thrust: 492, parTime: 510, baseScore: 18000, timeBonusMax: 3950, survivalBonus: 7000, goalWidth: 285, cellFuel: 11, landingSpeed: 118, landingAngle: .50 },
    9: { fuelBurn: 5.24, thrust: 502, parTime: 625, baseScore: 20500, timeBonusMax: 4400, survivalBonus: 7900, goalWidth: 320, cellFuel: 12, landingSpeed: 116, landingAngle: .48 },
    10: { fuelBurn: 5.38, thrust: 515, parTime: 850, baseScore: 31500, timeBonusMax: 6500, survivalBonus: 12500, goalWidth: 440, cellFuel: 12, landingSpeed: 108, landingAngle: .44 }
  });

  function applyFinalBalanceProfile() {
    levels.forEach(level => {
      const tuning = FINAL_BALANCE[level.id];
      if (!tuning) return;
      Object.assign(level, { fuelBurn:tuning.fuelBurn, thrust:tuning.thrust, parTime:tuning.parTime, baseScore:tuning.baseScore, timeBonusMax:tuning.timeBonusMax, survivalBonus:tuning.survivalBonus, cellFuel:tuning.cellFuel, landingSpeed:tuning.landingSpeed, landingAngle:tuning.landingAngle });
      if (level.goal) level.goal.w = Math.max(level.goal.w || 0, tuning.goalWidth);
    });
    const phase2=levels[1];
    phase2.zones=(phase2.zones||[]).map(z=>({...z,fx:z.fx*.84,fy:z.fy*.84}));
    phase2.spikes=(phase2.spikes||[]).map(x=>({...x,count:Math.max(3,x.count-1),size:Math.max(21,x.size-2)}));
    const phase7=levels[6];
    phase7.zones=(phase7.zones||[]).map(z=>({...z,fx:z.fx*.86,fy:z.fy*.9}));
    phase7.rockfalls=(phase7.rockfalls||[]).map(f=>({...f,count:Math.max(5,f.count-1),interval:f.interval*1.14,vyMin:f.vyMin*.92,vyMax:f.vyMax*.92}));
    phase7.checkpoints=(phase7.checkpoints||[]).map(cp=>({...cp,w:Math.max(cp.w||0,430),fuelTarget:100}));
    const phase8=levels[7];
    phase8.turrets=(phase8.turrets||[]).map(t=>({...t,fireRate:t.fireRate*1.12,projectileSpeed:t.projectileSpeed*.94}));
    phase8.mines=(phase8.mines||[]).map(m=>({...m,trigger:Math.max(145,m.trigger-10),blast:Math.max(118,m.blast-8)}));
    const phase9=levels[8];
    if(phase9.earthGravity)phase9.earthGravity={...phase9.earthGravity,end:Math.min(265,phase9.earthGravity.end||265)};
    phase9.turrets=(phase9.turrets||[]).map(t=>({...t,fireRate:t.fireRate*1.16,projectileSpeed:t.projectileSpeed*.92}));
    phase9.mines=(phase9.mines||[]).map(m=>({...m,trigger:Math.max(148,m.trigger-12),blast:Math.max(120,m.blast-10)}));
    const phase10=levels[9];
    if(phase10.earthGravity)phase10.earthGravity={...phase10.earthGravity,end:262};
    if(phase10.atmosphere)phase10.atmosphere={...phase10.atmosphere,turbulence:46,thrustLoss:.24,criticalHeat:100};
    phase10.turrets=(phase10.turrets||[]).map(t=>({...t,fireRate:t.fireRate*1.18,projectileSpeed:t.projectileSpeed*.9}));
    phase10.mines=(phase10.mines||[]).map(m=>({...m,trigger:Math.max(150,m.trigger-12),blast:Math.max(122,m.blast-10)}));
    phase10.checkpoints=(phase10.checkpoints||[]).map(cp=>({...cp,w:Math.max(cp.w||0,cp.id==="STATION 10-C"?400:420),fuelTarget:cp.id==="STATION 10-A"?100:cp.id==="STATION 10-B"?88:58}));
  }
  applyFinalBalanceProfile();

  const RARITY_META = Object.freeze({
    common: Object.freeze({ label: "COMÚN", plural: "NAVES COMUNES", className: "rarity-common", weight: 72 }),
    rare: Object.freeze({ label: "RARA", plural: "NAVES RARAS", className: "rarity-rare", weight: 23 }),
    legendary: Object.freeze({ label: "LEGENDARIA", plural: "NAVES LEGENDARIAS", className: "rarity-legendary", weight: 5 })
  });

  const SHIP_COLORS = Object.freeze([
    { id: "gray", label: "GRIS", rarity: "common", base: "#798486", light: "#eef3f1", dark: "#262d2f" },
    { id: "white", label: "BLANCO", rarity: "common", base: "#d9dfdc", light: "#ffffff", dark: "#69706f" },
    { id: "black", label: "NEGRO", rarity: "common", base: "#171a1b", light: "#727878", dark: "#020303" },
    { id: "blue", label: "AZUL", rarity: "common", base: "#316eb8", light: "#91bdff", dark: "#112c56" },
    { id: "brown", label: "MARRÓN", rarity: "common", base: "#79513d", light: "#c69a78", dark: "#352219" },
    { id: "green", label: "VERDE", rarity: "common", base: "#278c57", light: "#7bf1aa", dark: "#0d3e25" },
    { id: "orange", label: "NARANJA", rarity: "common", base: "#d46c24", light: "#ffb36a", dark: "#632b0d" },
    { id: "pink", label: "ROSA", rarity: "common", base: "#d8669a", light: "#ffb7d7", dark: "#71304e" },
    { id: "purple", label: "MORADO", rarity: "common", base: "#754bb2", light: "#bc9aef", dark: "#321b58" },
    { id: "red", label: "ROJO", rarity: "common", base: "#bd2b3f", light: "#ff7181", dark: "#5b101c" },
    { id: "yellow", label: "AMARILLO", rarity: "common", base: "#d7b12b", light: "#ffe87a", dark: "#67510b" },
    { id: "turquoise", label: "TURQUESA", rarity: "rare", base: "#2cb9a9", light: "#8ff9eb", dark: "#0d5950" },
    { id: "lavender", label: "LAVANDA", rarity: "rare", base: "#9b87d0", light: "#d8cbff", dark: "#4c3a78" },
    { id: "magenta", label: "MAGENTA", rarity: "rare", base: "#c72b9a", light: "#ff82d8", dark: "#641047" },
    { id: "salmon", label: "SALMÓN", rarity: "rare", base: "#db7768", light: "#ffc0b4", dark: "#78352d" },
    { id: "cyan", label: "CYAN", rarity: "rare", base: "#25bde0", light: "#91ecff", dark: "#0b6075" },
    { id: "beige", label: "BEIGE", rarity: "rare", base: "#c6b58f", light: "#fff0cb", dark: "#6a5d40" },
    { id: "gold", label: "DORADO", rarity: "legendary", rewardWeight: 4, base: "#c99b24", light: "#fff1a0", dark: "#664709" },
    { id: "rainbow", label: "RAINBOW FOIL", rarity: "legendary", rewardWeight: 1, base: "#6fe4d4", light: "#fff5a8", dark: "#8754c9" }
  ]);

  const DEFAULT_SETTINGS = Object.freeze({ controlMode: "classic", muted: false, music: true, shake: true, showTimer: true, crt: 62 });
  const DEFAULT_PROFILE = Object.freeze({ unlockedColors: ["gray"], equippedColor: "gray", campaignsCompleted: 0, rewardHistory: [], claimedResults: [], lastPilotName: "" });

  function safeRead(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) { return fallback; }
  }

  function safeWrite(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (_) { return false; }
  }

  function safeRemove(key) {
    try { localStorage.removeItem(key); return true; }
    catch (_) { return false; }
  }

  function loadSettings() {
    const raw = safeRead(SETTINGS_KEY, {});
    return {
      controlMode: raw?.controlMode === "arcade" ? "arcade" : "classic",
      muted: Boolean(raw?.muted),
      music: raw?.music !== false,
      shake: raw?.shake !== false,
      showTimer: raw?.showTimer !== false,
      crt: Math.min(100, Math.max(0, Number(raw?.crt ?? DEFAULT_SETTINGS.crt) || DEFAULT_SETTINGS.crt))
    };
  }

  function loadProfile() {
    const raw = safeRead(PROFILE_KEY, {});
    const unlockedColors = Array.isArray(raw?.unlockedColors) ? raw.unlockedColors.filter(id => SHIP_COLORS.some(color => color.id === id)) : ["gray"];
    if (!unlockedColors.includes("gray")) unlockedColors.unshift("gray");
    const equippedColor = unlockedColors.includes(raw?.equippedColor) ? raw.equippedColor : "gray";
    const rewardHistory = Array.isArray(raw?.rewardHistory) ? raw.rewardHistory.slice(0, 40).filter(entry => entry && SHIP_COLORS.some(color => color.id === entry.colorId)) : [];
    const claimedResults = Array.isArray(raw?.claimedResults) ? raw.claimedResults.map(String).slice(-200) : [];
    const lastPilotName = String(raw?.lastPilotName || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    return {
      unlockedColors,
      equippedColor,
      campaignsCompleted: Math.max(0, Number(raw?.campaignsCompleted) || 0),
      rewardHistory,
      claimedResults,
      lastPilotName
    };
  }

  const MACHINE_HIGH_SCORES = Object.freeze([
    { id:"machine-ace", resultId:"machine", name:"ACE", score:314500, time:2800, deaths:8, shipColor:"gold", completedAt:"2189-01-01T00:00:01.000Z" },
    { id:"machine-kite", resultId:"machine", name:"KITE", score:286200, time:3040, deaths:12, shipColor:"gray", completedAt:"2189-01-01T00:00:02.000Z" },
    { id:"machine-nova", resultId:"machine", name:"NOVA", score:262800, time:3285, deaths:16, shipColor:"blue", completedAt:"2189-01-01T00:00:03.000Z" },
    { id:"machine-madmax", resultId:"machine", name:"MADMAX", score:241900, time:3520, deaths:21, shipColor:"magenta", completedAt:"2189-01-01T00:00:04.000Z" },
    { id:"machine-orbit", resultId:"machine", name:"ORBIT", score:219400, time:3870, deaths:28, shipColor:"turquoise", completedAt:"2189-01-01T00:00:05.000Z" },
    { id:"machine-vector", resultId:"machine", name:"VECTOR", score:198600, time:4140, deaths:34, shipColor:"black", completedAt:"2189-01-01T00:00:06.000Z" },
    { id:"machine-home", resultId:"machine", name:"HOME", score:177300, time:4520, deaths:43, shipColor:"white", completedAt:"2189-01-01T00:00:07.000Z" },
    { id:"machine-jgs", resultId:"machine", name:"JGS", score:154800, time:5010, deaths:57, shipColor:"red", completedAt:"2189-01-01T00:00:08.000Z" }
  ]);

  function loadHighScores() {
    const stored = safeRead(HIGHSCORES_KEY, []);
    const raw = Array.isArray(stored) ? stored : [];
    const byId = new Map(MACHINE_HIGH_SCORES.map(entry => [entry.id, entry]));
    raw.forEach(entry => { if (entry?.id) byId.set(String(entry.id), entry); });
    return [...byId.values()].map(entry => ({
      id: String(entry?.id || ""),
      resultId: String(entry?.resultId || ""),
      name: String(entry?.name || "PILOT").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "PILOT",
      score: Math.max(0, Math.floor(Number(entry?.score) || 0)),
      time: Math.max(0, Number(entry?.time) || 0),
      deaths: Math.max(0, Math.floor(Number(entry?.deaths) || 0)),
      shipColor: SHIP_COLORS.some(color => color.id === entry?.shipColor) ? entry.shipColor : "gray",
      completedAt: String(entry?.completedAt || new Date(0).toISOString())
    })).sort(compareHighScores).slice(0, 100);
  }

  function loadCampaign() {
    const raw = safeRead(CAMPAIGN_KEY, null);
    if (!raw || raw.active !== true) return null;
    return {
      active: true,
      levelIndex: Math.min(levels.length - 1, Math.max(0, Number(raw.levelIndex) || 0)),
      score: Math.max(0, Math.floor(Number(raw.score) || 0)),
      deaths: Math.max(0, Math.floor(Number(raw.deaths) || 0)),
      totalTime: Math.max(0, Number(raw.totalTime) || 0),
      attempts: Math.max(1, Math.floor(Number(raw.attempts) || 1)),
      meteorAwards: Array.isArray(raw.meteorAwards) ? [...new Set(raw.meteorAwards.filter(value => typeof value === "string"))].slice(-1200) : [],
      variants: raw.variants && typeof raw.variants === "object" ? { ...raw.variants } : {},
      levelCells: levels.map((level, index) => Math.min(level.cells.length, Math.max(0, Math.floor(Number(raw.levelCells?.[index]) || 0)))),
      levelGrades: levels.map((_, index) => ["S", "A", "B", "C"].includes(raw.levelGrades?.[index]) ? raw.levelGrades[index] : null),
      phaseScores: levels.map((_, index) => {
        const entry = raw.phaseScores?.[index];
        if (!entry || typeof entry !== "object") return null;
        return {
          base: Math.max(0, Math.floor(Number(entry.base) || 0)),
          grade: Math.max(0, Math.floor(Number(entry.grade) || 0)),
          fuel: Math.max(0, Math.floor(Number(entry.fuel) || 0)),
          cells: Math.max(0, Math.floor(Number(entry.cells) || 0)),
          time: Math.max(0, Math.floor(Number(entry.time) || 0)),
          survival: Math.max(0, Math.floor(Number(entry.survival) || 0)),
          total: Math.max(0, Math.floor(Number(entry.total) || 0))
        };
      }),
      checkpoint: raw.checkpoint && Number(raw.checkpoint.levelIndex) === Math.min(levels.length - 1, Math.max(0, Number(raw.levelIndex) || 0)) ? {
        levelIndex: Number(raw.checkpoint.levelIndex),
        id: String(raw.checkpoint.id || "CHECKPOINT"),
        x: Number(raw.checkpoint.x) || 0,
        y: Number(raw.checkpoint.y) || 0,
        elapsed: Math.max(0, Number(raw.checkpoint.elapsed) || 0),
        cells: Array.isArray(raw.checkpoint.cells) ? raw.checkpoint.cells.map(Number).filter(Number.isFinite) : [],
        fuel: Math.min(100, Math.max(0, Number(raw.checkpoint.fuel) || 100)),
        ascent: Math.min(100, Math.max(0, Number(raw.checkpoint.ascent) || 0)),
        phase: String(raw.checkpoint.phase || ""),
        fuelTarget: Math.min(100, Math.max(1, Number(raw.checkpoint.fuelTarget) || 100))
      } : null,
      lastSaved: Number(raw.lastSaved) || Date.now()
    };
  }

  const stars = Array.from({ length: 240 }, (_, index) => ({
    x: (index * 353 + 71) % 4200,
    y: (index * 197 + 43) % 2200,
    r: index % 13 === 0 ? 1.8 : index % 5 === 0 ? 1.1 : .65,
    a: .18 + ((index * 37) % 70) / 100,
    depth: .08 + (index % 5) * .035
  }));

  const state = {
    mode: "intro",
    levelIndex: 0,
    attempts: 1,
    elapsed: 0,
    started: false,
    thrusting: false,
    pointer: { x: 300, y: 220, screenX: 300, screenY: 220 },
    camera: { x: 0, y: 0, targetX: 0, targetY: 0 },
    routeProgress: 0,
    lastTime: performance.now(),
    launchGrace: 0,
    worldTime: 0,
    overlayAction: "start",
    previousMode: "ready",
    particles: [],
    particleClock: 0,
    screenShake: 0,
    flash: 0,
    fuel: 100,
    collectedCells: new Set(),
    cellPulse: 0,
    lastLanding: null,
    message: "INSERT COIN para activar la máquina.",
    progress: loadProgress(),
    settings: loadSettings(),
    profile: loadProfile(),
    campaign: loadCampaign(),
    creditActive: false,
    score: 0,
    deaths: 0,
    campaignTime: 0,
    campaignCells: levels.map(() => 0),
    campaignGrades: levels.map(() => null),
    arcadeKeys: new Set(),
    recharge: null,
    weaponHeat: 0,
    firing: false,
    overheated: false,
    fireCooldown: 0,
    projectiles: [],
    enemyProjectiles: [],
    meteors: [],
    fallingRocks: [],
    turrets: [],
    mines: [],
    destructibleDoors: [],
    radarInterference: 0,
    rockfallControllers: [],
    scoredMeteors: new Set(),
    sectorDeathsStart: 0,
    hazardNotice: null,
    hazardNoticeTimer: 0,
    weaponNotice: null,
    weaponNoticeTimer: 0,
    menuReturnMode: "ready",
    introTimer: null,
    introFast: false,
    activeLevel: null,
    levelVariants: {},
    levelVariant: 0,
    checkpoint: null,
    atmosphericHeat: 0,
    thrustEfficiency: 1,
    thermalMarks: new Set(),
    missionPhase: "",
    finalResult: null,
    highScores: loadHighScores(),
    highlightedScoreId: "",
    highScoreReturn: "menu",
    nameEntry: { chars: ["-", "-", "-", "-", "-", "-"], position: 0 },
    cargoOpening: false,
    cargoReward: null,
    phaseBanner: null,
    phaseBannerTimer: 0,
    lastMissionPhase: "",
    scoreBreakdown: []
  };

  const ship = {
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    angle: -Math.PI / 2,
    targetAngle: -Math.PI / 2,
    size: 21
  };

  class AudioSystem {
    constructor() {
      this.enabled = true;
      this.context = null;
      this.thrustOsc = null;
      this.thrustGain = null;
      this.overchargeTimer = 0;
      this.fuelPumpNodes = [];
      this.ambientNodes = null;
      this.ambientEnabled = true;
    }

    ensure() {
      if (!this.enabled) return null;
      if (!this.context) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return null;
        this.context = new AudioContextClass();
      }
      if (this.context.state === "suspended") this.context.resume().catch(() => {});
      return this.context;
    }

    tone(frequency, duration = .08, type = "square", volume = .035, slide = 0) {
      const audio = this.ensure();
      if (!audio) return;
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      const now = audio.currentTime;
      osc.type = type;
      osc.frequency.setValueAtTime(frequency, now);
      if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(30, frequency + slide), now + duration);
      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      osc.connect(gain).connect(audio.destination);
      osc.start(now);
      osc.stop(now + duration + .02);
    }

    startThrust() {
      const audio = this.ensure();
      if (!audio || this.thrustOsc) return;
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.type = "sawtooth";
      osc.frequency.value = 72;
      gain.gain.value = .0001;
      osc.connect(gain).connect(audio.destination);
      osc.start();
      gain.gain.exponentialRampToValueAtTime(.025, audio.currentTime + .05);
      this.thrustOsc = osc;
      this.thrustGain = gain;
    }

    stopThrust() {
      if (!this.thrustOsc || !this.context) return;
      const osc = this.thrustOsc;
      const gain = this.thrustGain;
      const now = this.context.currentTime;
      gain.gain.cancelScheduledValues(now);
      gain.gain.setValueAtTime(Math.max(.0001, gain.gain.value), now);
      gain.gain.exponentialRampToValueAtTime(.0001, now + .06);
      osc.stop(now + .08);
      this.thrustOsc = null;
      this.thrustGain = null;
    }

    explosion() {
      this.stopThrust();
      this.tone(150, .26, "sawtooth", .06, -105);
      setTimeout(() => this.tone(64, .3, "square", .025, -20), 45);
    }

    landing() {
      this.stopThrust();
      this.tone(440, .11, "sine", .045, 180);
      setTimeout(() => this.tone(660, .18, "sine", .038, 260), 95);
    }

    cell() {
      this.tone(760, .08, "sine", .03, 220);
      setTimeout(() => this.tone(1040, .09, "sine", .022, 180), 55);
    }

    coin() {
      this.tone(1180, .055, "square", .035, -80);
      setTimeout(() => this.tone(720, .09, "triangle", .04, 210), 75);
      setTimeout(() => this.tone(1320, .12, "sine", .026, 280), 165);
    }

    menuMove() {
      this.tone(420, .035, "square", .014, 80);
    }

    shot() {
      this.tone(1320, .045, "square", .018, -420);
      setTimeout(() => this.tone(510, .035, "triangle", .009, -90), 18);
    }

    meteorHit() {
      this.tone(210, .055, "square", .018, 70);
    }

    meteorBreak() {
      this.tone(170, .12, "sawtooth", .032, -115);
      setTimeout(() => this.tone(420, .06, "square", .018, -160), 38);
    }

    rockfall() {
      this.tone(54, .42, "sawtooth", .028, -18);
      setTimeout(() => this.tone(72, .22, "triangle", .018, -28), 90);
    }

    overchargeAlarm() {
      const sequence = [980, 980, 1120, 980, 1220, 1220];
      sequence.forEach((frequency, index) => {
        setTimeout(() => this.tone(frequency, .055, "square", .038, 55), index * 72);
      });
      setTimeout(() => this.tone(180, .18, "sawtooth", .028, -90), 430);
    }

    weaponRecovered() {
      const audio = this.ensure();
      if (!audio) return;
      const now = audio.currentTime;
      const osc = audio.createOscillator();
      const overtone = audio.createOscillator();
      const gain = audio.createGain();
      const filter = audio.createBiquadFilter();
      osc.type = "sine";
      overtone.type = "triangle";
      osc.frequency.setValueAtTime(92, now);
      osc.frequency.exponentialRampToValueAtTime(780, now + .88);
      overtone.frequency.setValueAtTime(184, now);
      overtone.frequency.exponentialRampToValueAtTime(1240, now + .88);
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(420, now);
      filter.frequency.exponentialRampToValueAtTime(3200, now + .88);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.035, now + .13);
      gain.gain.setValueAtTime(.035, now + .66);
      gain.gain.exponentialRampToValueAtTime(.0001, now + .92);
      osc.connect(filter); overtone.connect(filter); filter.connect(gain).connect(audio.destination);
      osc.start(now); overtone.start(now);
      osc.stop(now + .95); overtone.stop(now + .95);
      setTimeout(() => this.tone(1040, .08, "sine", .018, 190), 790);
    }

    fuelPump(duration = 2.1) {
      const audio = this.ensure();
      if (!audio) return;
      const now = audio.currentTime;
      const master = audio.createGain();
      const filter = audio.createBiquadFilter();
      const hum = audio.createOscillator();
      const motor = audio.createOscillator();
      filter.type = "lowpass";
      filter.frequency.value = 520;
      hum.type = "triangle";
      motor.type = "sine";
      hum.frequency.value = 54;
      motor.frequency.value = 108;
      master.gain.setValueAtTime(.0001, now);
      master.gain.exponentialRampToValueAtTime(.018, now + .15);
      master.gain.setValueAtTime(.018, now + Math.max(.2, duration - .2));
      master.gain.exponentialRampToValueAtTime(.0001, now + duration);
      hum.connect(filter); motor.connect(filter); filter.connect(master).connect(audio.destination);
      hum.start(now); motor.start(now); hum.stop(now + duration + .02); motor.stop(now + duration + .02);
      const pumps = Math.max(3, Math.floor(duration / .28));
      for (let index = 0; index < pumps; index += 1) {
        setTimeout(() => this.tone(148 + (index % 2) * 24, .035, "triangle", .008, -18), index * 280 + 120);
      }
      setTimeout(() => this.tone(360, .07, "sine", .012, 90), duration * 1000 - 85);
    }

    enemyShot() {
      this.tone(340, .08, "sawtooth", .018, 150);
      setTimeout(() => this.tone(680, .04, "square", .01, -160), 28);
    }

    mineArm() {
      this.tone(760, .055, "square", .026, 45);
      setTimeout(() => this.tone(920, .055, "square", .024, 35), 120);
      setTimeout(() => this.tone(1110, .065, "square", .026, 20), 240);
    }

    mineExplosion() {
      this.tone(115, .28, "sawtooth", .055, -72);
      setTimeout(() => this.tone(58, .34, "square", .025, -18), 55);
    }

    structureBreak() {
      this.tone(195, .18, "square", .034, -120);
      setTimeout(() => this.tone(82, .26, "sawtooth", .025, -35), 65);
    }

    checkpoint() {
      this.tone(260, .14, "triangle", .018, 140);
      setTimeout(() => this.tone(520, .18, "sine", .022, 240), 110);
      setTimeout(() => this.tone(840, .12, "sine", .014, 110), 260);
    }

    phaseShift() {
      this.tone(92, .36, "sine", .018, 250);
      setTimeout(() => this.tone(420, .16, "triangle", .014, 180), 210);
    }

    startAmbient() {
      const audio = this.ensure();
      if (!audio || !this.ambientEnabled || this.ambientNodes) return;
      const master = audio.createGain();
      const low = audio.createOscillator();
      const high = audio.createOscillator();
      const filter = audio.createBiquadFilter();
      low.type = "sine"; high.type = "triangle";
      low.frequency.value = 43; high.frequency.value = 86;
      filter.type = "lowpass"; filter.frequency.value = 460;
      master.gain.setValueAtTime(.0001, audio.currentTime);
      master.gain.exponentialRampToValueAtTime(.009, audio.currentTime + .8);
      low.connect(filter); high.connect(filter); filter.connect(master).connect(audio.destination);
      low.start(); high.start();
      this.ambientNodes = { master, low, high, filter };
    }

    updateAmbient(level, phase = "") {
      if (!this.ambientEnabled || !this.enabled) { this.stopAmbient(); return; }
      // Web Audio must only be created after a real player interaction.
      // INSERT COIN calls ensure() and starts the ambience from that gesture.
      if (!this.context) return;
      this.startAmbient();
      const audio = this.context;
      const nodes = this.ambientNodes;
      if (!audio || !nodes) return;
      const id = Number(level?.id) || 1;
      const final = Boolean(level?.finalMission);
      const targetLow = 40 + id * 1.7 + (final ? 8 : 0);
      const targetHigh = targetLow * (phase === "ENTRADA ATMOSFÉRICA" ? 2.5 : 2);
      nodes.low.frequency.setTargetAtTime(targetLow, audio.currentTime, .8);
      nodes.high.frequency.setTargetAtTime(targetHigh, audio.currentTime, .8);
      nodes.filter.frequency.setTargetAtTime(final ? 720 : 420 + id * 24, audio.currentTime, .7);
      nodes.master.gain.setTargetAtTime(final ? .012 : .0085, audio.currentTime, .7);
    }

    stopAmbient() {
      if (!this.ambientNodes || !this.context) return;
      const { master, low, high } = this.ambientNodes;
      const now = this.context.currentTime;
      master.gain.cancelScheduledValues(now);
      master.gain.setTargetAtTime(.0001, now, .08);
      try { low.stop(now + .35); high.stop(now + .35); } catch (_) {}
      this.ambientNodes = null;
    }

    toggle() {
      this.enabled = !this.enabled;
      if (!this.enabled) { this.stopThrust(); this.stopAmbient(); }
      return this.enabled;
    }
  }

  const audio = new AudioSystem();
  audio.enabled = !state.settings.muted;


  function getShipColor() {
    return SHIP_COLORS.find(color => color.id === state.profile.equippedColor) || SHIP_COLORS[0];
  }

  function getBalance() {
    return window.JGS_ECONOMY?.getBalance?.() ?? 0;
  }

  function updateBalance() {
    if (ui.balance) ui.balance.textContent = String(getBalance()).padStart(4, "0");
  }

  function showSaveIndicator(label = "SAVING...") {
    if (!ui.saveIndicator) return;
    ui.saveIndicator.textContent = label;
    ui.saveIndicator.hidden = false;
    clearTimeout(showSaveIndicator.timer);
    showSaveIndicator.timer = setTimeout(() => { ui.saveIndicator.hidden = true; }, 820);
  }

  function saveSettings() {
    safeWrite(SETTINGS_KEY, state.settings);
    applySettings();
    showSaveIndicator("SETTINGS SAVED");
  }

  function saveProfile() {
    safeWrite(PROFILE_KEY, state.profile);
    showSaveIndicator("HANGAR SAVED");
  }

  function saveCampaign({ silent = false, levelIndex = state.levelIndex, attempts = state.attempts } = {}) {
    if (!state.creditActive || !state.campaign?.active) return;
    state.campaign = {
      active: true,
      levelIndex: Math.min(levels.length - 1, Math.max(0, Number(levelIndex) || 0)),
      score: Math.max(0, Math.floor(state.score)),
      deaths: Math.max(0, Math.floor(state.deaths)),
      totalTime: Math.max(0, state.campaignTime),
      attempts: Math.max(1, Number(attempts) || 1),
      meteorAwards: [...state.scoredMeteors].slice(-1200),
      variants: { ...state.levelVariants },
      levelCells: levels.map((level, index) => Math.min(level.cells.length, Math.max(0, Math.floor(Number(state.campaignCells[index]) || 0)))),
      levelGrades: levels.map((_, index) => ["S", "A", "B", "C"].includes(state.campaignGrades[index]) ? state.campaignGrades[index] : null),
      phaseScores: levels.map((_, index) => state.scoreBreakdown[index] ? { ...state.scoreBreakdown[index] } : null),
      checkpoint: state.checkpoint ? { ...state.checkpoint, cells: [...state.checkpoint.cells] } : null,
      lastSaved: Date.now()
    };
    safeWrite(CAMPAIGN_KEY, state.campaign);
    updateMenuUI();
    if (!silent) showSaveIndicator("MISSION SAVED");
  }

  function applySettings() {
    audio.enabled = !state.settings.muted;
    audio.ambientEnabled = state.settings.music !== false;
    if (!audio.enabled || !audio.ambientEnabled) audio.stopAmbient();
    else if (state.creditActive) audio.updateAmbient(currentLevel(), state.missionPhase || state.mode);
    if (!audio.enabled) audio.stopThrust();
    document.body.classList.toggle("no-shake", !state.settings.shake);
    document.documentElement.style.setProperty("--crt-strength", String(state.settings.crt / 100));
    if (ui.timerField) ui.timerField.classList.toggle("is-hidden", !state.settings.showTimer);
    if (ui.soundLabel) ui.soundLabel.textContent = audio.enabled ? "Sonido ON" : "Sonido OFF";
    const arcade = state.settings.controlMode === "arcade";
    document.body.classList.toggle("triangle-control-arcade", arcade);
    document.body.classList.toggle("triangle-control-classic", !arcade);
    if (ui.activeControl) ui.activeControl.textContent = arcade ? "MODO ARCADE" : "MODO CLÁSICO";
    if (ui.activeControlCopy) ui.activeControlCopy.textContent = arcade ? "WASD o flechas: impulso · Espacio: disparar." : "Ratón: orientar · clic izquierdo: impulsar · clic derecho o Espacio: disparar.";
    if (ui.menuMode) ui.menuMode.textContent = `CONTROL / ${arcade ? "ARCADE" : "CLÁSICO"}`;
    if (ui.controlHelp) ui.controlHelp.textContent = arcade ? "WASD o flechas: impulso · Espacio: disparar · R: reiniciar · P: pausa" : "Ratón: orientar · clic izquierdo: impulsar · clic derecho/Espacio: disparar · R: reiniciar";
    document.querySelectorAll('input[name="triangle-control"]').forEach(input => { input.checked = input.value === state.settings.controlMode; });
    if (ui.settingMute) ui.settingMute.checked = state.settings.muted;
    if (ui.settingMusic) ui.settingMusic.checked = state.settings.music !== false;
    if (ui.settingShake) ui.settingShake.checked = state.settings.shake;
    if (ui.settingTimer) ui.settingTimer.checked = state.settings.showTimer;
    if (ui.settingCrt) ui.settingCrt.value = String(state.settings.crt);
  }

  function showArcadeScreen(target) {
    [ui.attractScreen, ui.mainMenu, ui.introScreen, ui.hangarScreen, ui.settingsScreen, ui.resultScreen, ui.nameScreen, ui.highscoresScreen, ui.cargoScreen].forEach(screen => {
      if (!screen) return;
      const active = screen === target;
      screen.hidden = !active;
      screen.classList.toggle("is-active", active);
    });
    ui.arcadeLayer?.classList.add("is-visible");
  }

  function hideArcadeLayer() {
    ui.arcadeLayer?.classList.remove("is-visible");
  }

  function updateMenuUI() {
    const campaign = loadCampaign();
    state.campaign = campaign;
    const canContinue = Boolean(campaign?.active);
    if (ui.continueGame) ui.continueGame.disabled = !canContinue;
    if (ui.continueNote) ui.continueNote.textContent = canContinue ? `FASE ${String(campaign.levelIndex + 1).padStart(2, "0")} · ${String(campaign.score).padStart(6, "0")}` : "SIN PARTIDA";
    const color = getShipColor();
    if (ui.menuColor) ui.menuColor.textContent = `HULL / ${color.label}`;
    const pending = safeRead(RESULT_KEY, null);
    const needsScore = Boolean(pending?.id && !pending.scoreRegistered);
    const needsCargo = Boolean(pending?.id && pending.scoreRegistered && !pending.rewardClaimed);
    if (ui.pendingCargoButton) {
      ui.pendingCargoButton.hidden = !(needsScore || needsCargo);
      const label = ui.pendingCargoButton.querySelector("b");
      if (label) label.textContent = needsScore ? "REGISTRAR MISIÓN" : "CARGO RECOVERY";
    }
    if (ui.pendingNote) ui.pendingNote.textContent = needsScore ? "SCORE PENDIENTE" : "CONTENEDOR PENDIENTE";
    updateBalance();
  }

  function openMainMenu() {
    if (!state.creditActive) {
      showArcadeScreen(ui.attractScreen);
      return;
    }
    setThrust(false);
    setFiring(false);
    state.arcadeKeys.clear();
    if (["playing", "ready", "paused", "crashed", "landed", "recharging"].includes(state.mode)) saveCampaign({ silent: true });
    state.mode = "menu";
    audio.updateAmbient(currentLevel(), "MENU");
    hideOverlay();
    updateMenuUI();
    showArcadeScreen(ui.mainMenu);
    audio.menuMove();
  }

  function insertCredit() {
    audio.ensure();
    updateBalance();
    if (state.creditActive) {
      openMainMenu();
      return;
    }
    const economy = window.JGS_ECONOMY;
    if (!economy?.spend || !economy.spend(CREDIT_COST)) {
      if (ui.creditMessage) {
        ui.creditMessage.textContent = "SALDO INSUFICIENTE / NECESITAS 100 JCOIN";
        ui.creditMessage.classList.add("is-error");
      }
      audio.tone(150, .18, "square", .035, -45);
      return;
    }
    state.creditActive = true;
    audio.coin();
    audio.startAmbient();
    updateBalance();
    if (ui.creditMessage) {
      ui.creditMessage.textContent = "CREDIT 01 / SYSTEM BOOT";
      ui.creditMessage.classList.remove("is-error");
    }
    ui.arcadeLayer?.classList.add("coin-flash");
    setTimeout(() => {
      ui.arcadeLayer?.classList.remove("coin-flash");
      openMainMenu();
    }, 520);
  }

  function exitCredit() {
    setThrust(false);
    setFiring(false);
    state.arcadeKeys.clear();
    saveCampaign({ silent: true });
    state.creditActive = false;
    audio.stopAmbient();
    state.mode = "attract";
    if (ui.creditMessage) {
      ui.creditMessage.textContent = "PULSA PARA INSERTAR CRÉDITO";
      ui.creditMessage.classList.remove("is-error");
    }
    updateBalance();
    showArcadeScreen(ui.attractScreen);
  }

  function createCampaign() {
    state.score = 0;
    state.deaths = 0;
    state.campaignTime = 0;
    state.levelVariants = {};
    state.checkpoint = null;
    state.campaignCells = levels.map(() => 0);
    state.campaignGrades = levels.map(() => null);
    state.scoreBreakdown = levels.map(() => null);
    state.campaign = { active: true, levelIndex: 0, score: 0, deaths: 0, totalTime: 0, attempts: 1, meteorAwards: [], variants: {}, levelCells: [...state.campaignCells], levelGrades: [...state.campaignGrades], phaseScores: [...state.scoreBreakdown], checkpoint: null, lastSaved: Date.now() };
    state.levelIndex = 0;
    state.attempts = 1;
    safeWrite(CAMPAIGN_KEY, state.campaign);
  }

  const INTRO_LINES = [
    { text: "AÑO 2189" },
    { text: "" },
    { text: "SISTEMA: PROXIMA CENTAURI" },
    { text: "SECTOR: K-47" },
    { text: "DISTANCIA A LA TIERRA: 4.23 AÑOS LUZ" },
    { text: "" },
    { text: "NAVE: TAS-01 / KITE", alert: true },
    { text: "CASCO: ESTADO CRÍTICO" },
    { text: "PROPULSIÓN: INESTABLE" },
    { text: "COMBUSTIBLE: 11%" },
    { text: "NAVEGACIÓN: FUERA DE SERVICIO" },
    { text: "" },
    { text: "TRIPULACIÓN ACTIVA: 1" },
    { text: "ÚLTIMA SEÑAL: PLANETA TIERRA" },
    { text: "" },
    { text: "OBJETIVO PRIORITARIO: REGRESAR A CASA", objective: true }
  ];

  function launchCampaign() {
    clearTimeout(state.introTimer);
    state.introFast = false;
    const campaign = state.campaign || { levelIndex: 0, attempts: 1, score: 0, deaths: 0, totalTime: 0 };
    state.score = campaign.score || 0;
    state.deaths = campaign.deaths || 0;
    state.campaignTime = campaign.totalTime || 0;
    state.levelVariants = { ...(campaign.variants || {}) };
    state.campaignCells = levels.map((level, index) => Math.min(level.cells.length, Math.max(0, Number(campaign.levelCells?.[index]) || 0)));
    state.campaignGrades = levels.map((_, index) => ["S", "A", "B", "C"].includes(campaign.levelGrades?.[index]) ? campaign.levelGrades[index] : null);
    state.scoreBreakdown = levels.map((_, index) => campaign.phaseScores?.[index] ? { ...campaign.phaseScores[index] } : null);
    state.checkpoint = campaign.checkpoint ? { ...campaign.checkpoint, cells: [...campaign.checkpoint.cells] } : null;
    hideArcadeLayer();
    audio.updateAmbient(levels[campaign.levelIndex || 0], "MISSION");
    loadLevel(campaign.levelIndex || 0, { showIntro: true });
    state.attempts = campaign.attempts || 1;
    saveCampaign({ silent: true });
    updateHud();
  }

  function runIntro() {
    showArcadeScreen(ui.introScreen);
    ui.terminalLines.replaceChildren();
    ui.skipIntro.textContent = "MANTENER PARA ACELERAR";
    ui.skipIntro.dataset.ready = "false";
    let index = 0;
    const next = () => {
      if (index >= INTRO_LINES.length) {
        ui.skipIntro.textContent = "INICIAR MISIÓN";
        ui.skipIntro.dataset.ready = "true";
        audio.tone(620, .08, "sine", .02, 160);
        return;
      }
      const line = INTRO_LINES[index++];
      const element = document.createElement("p");
      element.textContent = line.text || " ";
      if (line.alert) element.classList.add("is-alert");
      if (line.objective) element.classList.add("is-objective");
      ui.terminalLines.append(element);
      audio.tone(310 + (index % 4) * 34, .018, "square", .008, 20);
      const delay = state.introFast ? 55 : (line.text ? 360 : 180);
      state.introTimer = setTimeout(next, delay);
    };
    next();
  }

  function startNewGame() {
    if (loadCampaign()?.active && !window.confirm("Hay una partida guardada. ¿Sustituirla por una campaña nueva?")) return;
    createCampaign();
    runIntro();
  }

  function continueSavedGame() {
    const campaign = loadCampaign();
    if (!campaign) return;
    state.campaign = campaign;
    state.levelIndex = campaign.levelIndex;
    state.score = campaign.score;
    state.deaths = campaign.deaths;
    state.campaignTime = campaign.totalTime;
    state.attempts = campaign.attempts;
    state.levelVariants = { ...(campaign.variants || {}) };
    state.campaignCells = levels.map((level, index) => Math.min(level.cells.length, Math.max(0, Number(campaign.levelCells?.[index]) || 0)));
    state.campaignGrades = levels.map((_, index) => ["S", "A", "B", "C"].includes(campaign.levelGrades?.[index]) ? campaign.levelGrades[index] : null);
    state.scoreBreakdown = levels.map((_, index) => campaign.phaseScores?.[index] ? { ...campaign.phaseScores[index] } : null);
    state.checkpoint = campaign.checkpoint ? { ...campaign.checkpoint, cells: [...campaign.checkpoint.cells] } : null;
    launchCampaign();
  }

  function rarityMeta(rarity) {
    return RARITY_META[rarity] || RARITY_META.common;
  }

  function colorSwatch(color) {
    return color.id === "rainbow" ? "linear-gradient(90deg,#ff4f70,#ffca55,#6df3a4,#63c7ff,#ae75ff,#ff4f70)" : color.base;
  }

  function compareHighScores(a, b) {
    return (b.score - a.score) || (a.time - b.time) || (a.deaths - b.deaths) || String(a.completedAt).localeCompare(String(b.completedAt));
  }

  function formatArchiveDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "--/--/----";
    return new Intl.DateTimeFormat("es-ES", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
  }

  function pendingResult() {
    const result = safeRead(RESULT_KEY, null);
    return result?.id ? result : null;
  }

  function renderHangar() {
    state.profile = loadProfile();
    const color = getShipColor();
    const meta = rarityMeta(color.rarity);
    ui.hangarShip?.style.setProperty("--ship-base", color.base);
    ui.hangarShip?.style.setProperty("--ship-light", color.light);
    ui.hangarShip?.style.setProperty("--ship-dark", color.dark);
    ui.hangarShip?.classList.toggle("is-rainbow", color.id === "rainbow");
    ui.hangarShip?.classList.toggle("is-gold", color.id === "gold");
    if (ui.equippedLabel) {
      ui.equippedLabel.textContent = `${color.label} / ${meta.label}`;
      ui.equippedLabel.className = meta.className;
    }

    const countRarity = rarity => SHIP_COLORS.filter(option => option.rarity === rarity && state.profile.unlockedColors.includes(option.id)).length;
    if (ui.collectionCount) ui.collectionCount.textContent = `${state.profile.unlockedColors.length} / ${SHIP_COLORS.length}`;
    if (ui.commonCount) ui.commonCount.textContent = `${countRarity("common")} / ${SHIP_COLORS.filter(option => option.rarity === "common").length}`;
    if (ui.rareCount) ui.rareCount.textContent = `${countRarity("rare")} / ${SHIP_COLORS.filter(option => option.rarity === "rare").length}`;
    if (ui.legendaryCount) ui.legendaryCount.textContent = `${countRarity("legendary")} / ${SHIP_COLORS.filter(option => option.rarity === "legendary").length}`;

    if (ui.hangarGrid) {
      ui.hangarGrid.replaceChildren(...SHIP_COLORS.map(option => {
        const button = document.createElement("button");
        const unlocked = state.profile.unlockedColors.includes(option.id);
        const rarity = rarityMeta(option.rarity);
        button.type = "button";
        button.className = `hangar-color ${rarity.className}${unlocked ? "" : " is-locked"}${state.profile.equippedColor === option.id ? " is-equipped" : ""}${option.id === "rainbow" ? " is-rainbow" : ""}`;
        button.style.setProperty("--swatch", colorSwatch(option));
        button.innerHTML = `<i></i><strong>${option.label}</strong><small>${rarity.label}${unlocked ? "" : " / BLOQUEADA"}</small>`;
        button.disabled = !unlocked;
        button.addEventListener("click", () => {
          state.profile.equippedColor = option.id;
          saveProfile();
          renderHangar();
          updateMenuUI();
          audio.menuMove();
        });
        return button;
      }));
    }

    if (ui.cargoHistory) {
      const history = state.profile.rewardHistory.slice(0, 8);
      if (!history.length) {
        const empty = document.createElement("p");
        empty.className = "cargo-history-empty";
        empty.textContent = "SIN CONTENEDORES RECUPERADOS";
        ui.cargoHistory.replaceChildren(empty);
      } else {
        ui.cargoHistory.replaceChildren(...history.map((entry, index) => {
          const rewardColor = SHIP_COLORS.find(option => option.id === entry.colorId) || SHIP_COLORS[0];
          const rarity = rarityMeta(rewardColor.rarity);
          const row = document.createElement("div");
          row.className = `cargo-history-row ${rarity.className}`;
          const swatch = document.createElement("i");
          swatch.style.setProperty("--history-swatch", colorSwatch(rewardColor));
          const copy = document.createElement("p");
          const title = document.createElement("strong");
          title.textContent = rewardColor.label;
          const detail = document.createElement("small");
          detail.textContent = `${rarity.label} · ${formatArchiveDate(entry.at)} · SCORE ${String(entry.score || 0).padStart(6, "0")}`;
          copy.append(title, detail);
          const number = document.createElement("span");
          number.textContent = String(index + 1).padStart(2, "0");
          row.append(number, swatch, copy);
          return row;
        }));
      }
    }
  }

  function openHangar() {
    renderHangar();
    showArcadeScreen(ui.hangarScreen);
    audio.menuMove();
  }

  function openSettings() {
    applySettings();
    showArcadeScreen(ui.settingsScreen);
    audio.menuMove();
  }

  function resetNameEntry(result) {
    const remembered = state.profile.lastPilotName || "";
    state.nameEntry.chars = Array.from({ length: 6 }, (_, index) => remembered[index] || "-");
    state.nameEntry.position = Math.min(5, remembered.length);
    if (remembered.length >= 6) state.nameEntry.position = 5;
    if (ui.nameScore) ui.nameScore.textContent = String(result.score).padStart(6, "0");
    if (ui.nameTime) ui.nameTime.textContent = formatTime(result.time);
    if (ui.nameDeaths) ui.nameDeaths.textContent = String(result.deaths).padStart(2, "0");
    renderNameEntry();
  }

  function renderNameEntry() {
    if (!ui.nameSlots) return;
    ui.nameSlots.replaceChildren(...state.nameEntry.chars.map((char, index) => {
      const slot = document.createElement("button");
      slot.type = "button";
      slot.textContent = char;
      slot.className = index === state.nameEntry.position ? "is-active" : "";
      slot.setAttribute("aria-label", `Carácter ${index + 1}: ${char === "-" ? "vacío" : char}`);
      slot.addEventListener("click", () => {
        state.nameEntry.position = index;
        renderNameEntry();
        audio.menuMove();
      });
      return slot;
    }));
  }

  const NAME_ALPHABET = "-ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  function moveNamePosition(delta) {
    state.nameEntry.position = (state.nameEntry.position + delta + 6) % 6;
    renderNameEntry();
    audio.menuMove();
  }

  function cycleNameCharacter(delta) {
    const current = state.nameEntry.chars[state.nameEntry.position];
    const index = Math.max(0, NAME_ALPHABET.indexOf(current));
    state.nameEntry.chars[state.nameEntry.position] = NAME_ALPHABET[(index + delta + NAME_ALPHABET.length) % NAME_ALPHABET.length];
    renderNameEntry();
    audio.tone(420 + state.nameEntry.position * 30, .035, "square", .014, 60);
  }

  function typeNameCharacter(character) {
    const clean = String(character).toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (!clean) return;
    state.nameEntry.chars[state.nameEntry.position] = clean[0];
    if (state.nameEntry.position < 5) state.nameEntry.position += 1;
    renderNameEntry();
    audio.tone(520, .035, "square", .014, 100);
  }

  function eraseNameCharacter() {
    if (state.nameEntry.chars[state.nameEntry.position] === "-" && state.nameEntry.position > 0) state.nameEntry.position -= 1;
    state.nameEntry.chars[state.nameEntry.position] = "-";
    renderNameEntry();
    audio.tone(220, .04, "square", .012, -40);
  }

  function openNameEntry() {
    const result = state.finalResult || pendingResult();
    if (!result) return openMainMenu();
    state.finalResult = result;
    if (result.scoreRegistered) {
      state.highlightedScoreId = result.scoreEntryId || "";
      openHighScores("postscore");
      return;
    }
    resetNameEntry(result);
    showArcadeScreen(ui.nameScreen);
    state.mode = "name-entry";
    audio.menuMove();
  }

  function registerHighScore() {
    const result = state.finalResult || pendingResult();
    if (!result) return;
    let name = state.nameEntry.chars.join("").replace(/-/g, "").trim().slice(0, 6);
    if (!name) name = "PILOT";
    const existing = state.highScores.find(entry => entry.resultId === result.id);
    let entry = existing;
    if (!entry) {
      entry = {
        id: `score-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        resultId: result.id,
        name,
        score: result.score,
        time: result.time,
        deaths: result.deaths,
        shipColor: result.shipColor,
        completedAt: result.completedAt
      };
      const completeList = [...state.highScores, entry].sort(compareHighScores);
      const rank = completeList.findIndex(item => item.id === entry.id) + 1;
      state.highScores = completeList.slice(0, 100);
      result.rank = rank;
      result.madeTop100 = rank <= 100;
      if (result.madeTop100) safeWrite(HIGHSCORES_KEY, state.highScores);
    } else {
      result.rank = state.highScores.findIndex(item => item.id === existing.id) + 1;
      result.madeTop100 = result.rank > 0;
    }
    result.scoreRegistered = true;
    result.scoreEntryId = entry.id;
    safeWrite(RESULT_KEY, result);
    state.finalResult = result;
    state.highlightedScoreId = entry.id;
    state.profile.lastPilotName = name;
    saveProfile();
    audio.tone(680, .08, "square", .025, 180);
    setTimeout(() => audio.tone(940, .13, "sine", .022, 180), 95);
    openHighScores("postscore");
  }

  function renderHighScores() {
    state.highScores = loadHighScores();
    const highlightId = state.highlightedScoreId;
    if (ui.highscoresList) {
      if (!state.highScores.length) {
        const empty = document.createElement("p");
        empty.className = "highscores-empty";
        empty.textContent = "NO RECORDS / COMPLETE THE MISSION";
        ui.highscoresList.replaceChildren(empty);
      } else {
        ui.highscoresList.replaceChildren(...state.highScores.map((entry, index) => {
          const color = SHIP_COLORS.find(option => option.id === entry.shipColor) || SHIP_COLORS[0];
          const row = document.createElement("div");
          row.className = `highscore-row${entry.id === highlightId ? " is-new-record" : ""}${entry.id.startsWith("machine-") ? " is-machine-record" : ""}`;
          const rank = document.createElement("strong"); rank.textContent = String(index + 1).padStart(2, "0");
          const pilot = document.createElement("b"); pilot.textContent = entry.name;
          const score = document.createElement("span"); score.textContent = String(entry.score).padStart(6, "0");
          const time = document.createElement("span"); time.textContent = formatTime(entry.time);
          const deaths = document.createElement("span"); deaths.textContent = String(entry.deaths).padStart(2, "0");
          const hull = document.createElement("span"); hull.className = "highscore-hull"; hull.style.setProperty("--score-swatch", colorSwatch(color)); hull.textContent = color.label;
          row.append(rank, pilot, score, time, deaths, hull);
          return row;
        }));
      }
    }
    const result = pendingResult();
    if (ui.highscoresStatus) {
      if (highlightId && result?.madeTop100) ui.highscoresStatus.textContent = `NEW RECORD / POSITION ${String(result.rank).padStart(2, "0")}`;
      else if (highlightId) ui.highscoresStatus.textContent = "SCORE REGISTRADO / FUERA DEL TOP 100";
      else ui.highscoresStatus.textContent = `TOP 100 LOCAL · ${state.highScores.length} RECORDS`;
    }
  }

  function openHighScores(source = "menu") {
    state.highScoreReturn = source;
    renderHighScores();
    const result = pendingResult();
    const canRecover = source === "postscore" && result?.scoreRegistered && !result.rewardClaimed;
    if (ui.highscoresNext) ui.highscoresNext.hidden = !canRecover;
    if (ui.highscoresBack) ui.highscoresBack.textContent = source === "postscore" ? "VOLVER AL MENÚ" : "← VOLVER";
    showArcadeScreen(ui.highscoresScreen);
    state.mode = "highscores";
    audio.menuMove();
  }

  function weightedChoice(items, weightFor) {
    const total = items.reduce((sum, item) => sum + Math.max(0, weightFor(item)), 0);
    if (!items.length) return null;
    if (total <= 0) return items[Math.floor(Math.random() * items.length)];
    let roll = Math.random() * total;
    for (const item of items) {
      roll -= Math.max(0, weightFor(item));
      if (roll <= 0) return item;
    }
    return items[items.length - 1];
  }

  function chooseCargoReward() {
    const locked = SHIP_COLORS.filter(color => !state.profile.unlockedColors.includes(color.id));
    const duplicate = locked.length === 0;
    const pool = duplicate ? SHIP_COLORS : locked;
    const rarities = Object.keys(RARITY_META).filter(rarity => pool.some(color => color.rarity === rarity));
    const selectedRarity = weightedChoice(rarities, rarity => RARITY_META[rarity].weight);
    const rarityPool = pool.filter(color => color.rarity === selectedRarity);
    const color = weightedChoice(rarityPool, option => option.rewardWeight || 1) || pool[0];
    return { color, duplicate };
  }

  function prepareCargoScreen() {
    state.cargoOpening = false;
    state.cargoReward = null;
    ui.cargoStage?.classList.remove("is-opening", "is-revealed", "rarity-common", "rarity-rare", "rarity-legendary", "is-rainbow", "is-gold");
    if (ui.cargoCapsule) ui.cargoCapsule.hidden = false;
    if (ui.cargoReveal) ui.cargoReveal.hidden = true;
    if (ui.cargoOpen) { ui.cargoOpen.hidden = false; ui.cargoOpen.disabled = false; ui.cargoOpen.textContent = "ABRIR CONTENEDOR"; }
    if (ui.cargoEquip) ui.cargoEquip.hidden = true;
    if (ui.cargoBack) ui.cargoBack.hidden = true;
  }

  function beginCargoRecovery() {
    const result = state.finalResult || pendingResult();
    if (!result) return openMainMenu();
    state.finalResult = result;
    if (!result.scoreRegistered) return openNameEntry();
    prepareCargoScreen();
    showArcadeScreen(ui.cargoScreen);
    state.mode = "cargo";
    if (result.rewardId) {
      const reward = SHIP_COLORS.find(color => color.id === result.rewardId);
      if (reward) state.cargoReward = { color: reward, duplicate: Boolean(result.rewardDuplicate) };
    }
    audio.tone(130, .18, "sine", .018, 45);
  }

  function revealCargoReward(reward, result) {
    const color = reward.color;
    const meta = rarityMeta(color.rarity);
    ui.cargoStage?.classList.remove("is-opening");
    ui.cargoStage?.classList.add("is-revealed", meta.className);
    ui.cargoStage?.classList.toggle("is-rainbow", color.id === "rainbow");
    ui.cargoStage?.classList.toggle("is-gold", color.id === "gold");
    if (ui.cargoCapsule) ui.cargoCapsule.hidden = true;
    if (ui.cargoReveal) ui.cargoReveal.hidden = false;
    if (ui.cargoRarity) { ui.cargoRarity.textContent = `NAVE ${meta.label}`; ui.cargoRarity.className = meta.className; }
    if (ui.cargoShip) {
      ui.cargoShip.style.setProperty("--ship-base", color.base);
      ui.cargoShip.style.setProperty("--ship-light", color.light);
      ui.cargoShip.style.setProperty("--ship-dark", color.dark);
      ui.cargoShip.classList.toggle("is-rainbow", color.id === "rainbow");
    }
    if (ui.cargoColor) ui.cargoColor.textContent = color.label;
    if (ui.cargoCopy) ui.cargoCopy.textContent = reward.duplicate ? "COLECCIÓN COMPLETA · ACABADO DUPLICADO ARCHIVADO" : "NUEVO ACABADO DESBLOQUEADO";
    if (ui.cargoOpen) ui.cargoOpen.hidden = true;
    if (ui.cargoEquip) ui.cargoEquip.hidden = reward.duplicate;
    if (ui.cargoBack) ui.cargoBack.hidden = false;

    if (!state.profile.claimedResults.includes(result.id)) {
      if (!reward.duplicate && !state.profile.unlockedColors.includes(color.id)) state.profile.unlockedColors.push(color.id);
      state.profile.claimedResults.push(result.id);
      state.profile.claimedResults = state.profile.claimedResults.slice(-200);
      state.profile.rewardHistory.unshift({ resultId: result.id, colorId: color.id, rarity: color.rarity, at: new Date().toISOString(), score: result.score, rank: result.rank || null, duplicate: reward.duplicate });
      state.profile.rewardHistory = state.profile.rewardHistory.slice(0, 40);
      saveProfile();
    }
    result.rewardClaimed = true;
    result.rewardId = color.id;
    result.rewardRarity = color.rarity;
    result.rewardDuplicate = reward.duplicate;
    safeWrite(RESULT_KEY, result);
    state.finalResult = result;
    updateMenuUI();

    if (color.rarity === "legendary") {
      audio.tone(190, .5, "sine", .035, 680);
      setTimeout(() => audio.tone(760, .55, "triangle", .03, 680), 220);
      setTimeout(() => audio.tone(1320, .7, "sine", .022, 520), 520);
    } else if (color.rarity === "rare") {
      audio.tone(300, .32, "triangle", .03, 420);
      setTimeout(() => audio.tone(760, .36, "sine", .024, 280), 250);
    } else {
      audio.tone(260, .2, "square", .024, 180);
      setTimeout(() => audio.tone(620, .28, "sine", .022, 220), 190);
    }
  }

  function openCargoContainer() {
    if (state.cargoOpening) return;
    const result = state.finalResult || pendingResult();
    if (!result) return;
    state.cargoOpening = true;
    let reward = state.cargoReward;
    if (!reward) {
      reward = chooseCargoReward();
      state.cargoReward = reward;
      result.rewardId = reward.color.id;
      result.rewardRarity = reward.color.rarity;
      result.rewardDuplicate = reward.duplicate;
      result.rewardClaimed = false;
      safeWrite(RESULT_KEY, result);
      state.finalResult = result;
    }
    if (ui.cargoOpen) { ui.cargoOpen.disabled = true; ui.cargoOpen.textContent = "DESCODIFICANDO..."; }
    ui.cargoStage?.classList.add("is-opening");
    audio.tone(95, .55, "sawtooth", .025, 150);
    setTimeout(() => audio.tone(180, .4, "square", .018, 320), 390);
    setTimeout(() => {
      state.cargoOpening = false;
      revealCargoReward(reward, result);
    }, 1450);
  }

  function equipCargoReward() {
    const result = state.finalResult || pendingResult();
    if (!result?.rewardId || !state.profile.unlockedColors.includes(result.rewardId)) return;
    state.profile.equippedColor = result.rewardId;
    saveProfile();
    if (ui.cargoEquip) { ui.cargoEquip.textContent = "NAVE EQUIPADA"; ui.cargoEquip.disabled = true; }
    updateMenuUI();
    audio.menuMove();
  }

  function closeCargoRecovery() {
    const result = state.finalResult || pendingResult();
    if (result?.rewardClaimed) safeRemove(RESULT_KEY);
    state.finalResult = null;
    state.highlightedScoreId = "";
    state.cargoReward = null;
    openMainMenu();
  }

  function openPendingMetagame() {
    const result = pendingResult();
    if (!result) return openMainMenu();
    state.finalResult = result;
    if (!result.scoreRegistered) showCampaignResult(result);
    else if (!result.rewardClaimed) beginCargoRecovery();
    else closeCargoRecovery();
  }

  function loadProgress() {
    const empty = {
      unlocked: 1,
      best: levels.map(() => null),
      grades: levels.map(() => null),
      cells: levels.map(() => 0)
    };
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY) || "null");
      if (raw && Number.isInteger(raw.unlocked) && Array.isArray(raw.best)) {
        return {
          unlocked: Math.min(levels.length, Math.max(1, raw.unlocked)),
          best: levels.map((_, index) => Number.isFinite(raw.best[index]) ? raw.best[index] : null),
          grades: levels.map((_, index) => typeof raw.grades?.[index] === "string" ? raw.grades[index] : null),
          cells: levels.map((level, index) => Math.min(level.cells.length, Math.max(0, Number(raw.cells?.[index]) || 0)))
        };
      }
    } catch (_) {}
    return empty;
  }

  function saveProgress() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress));
    } catch (_) {}
  }

  function gradeRank(grade) {
    return ({ C: 1, B: 2, A: 3, S: 4 })[grade] || 0;
  }

  function calculateLandingGrade({ speed, angle }) {
    const level = currentLevel();
    const cells = state.collectedCells.size;
    let score = 100;
    const safeSpeed = Number(level.landingSpeed) || 122;
    const safeAngle = Number(level.landingAngle) || .52;
    score -= Math.max(0, speed - 16) * .22;
    score -= angle * 36;
    score += Math.max(0, safeSpeed - speed) * .035;
    score += Math.max(0, safeAngle - angle) * 4;
    score -= Math.max(0, state.elapsed - level.parTime) * .75;
    score -= Math.max(0, state.attempts - 1) * 4;
    score += state.fuel * .08;
    score += cells * 4.5;
    if (score >= 94) return "S";
    if (score >= 80) return "A";
    if (score >= 65) return "B";
    return "C";
  }

  function buildActiveLevel(index) {
    const base = levels[index];
    if (!base) return levels[0];
    const variants = Array.isArray(base.variants) ? base.variants : [];
    if (!variants.length) return base;
    let variantIndex = Number(state.levelVariants?.[base.id]);
    if (!Number.isInteger(variantIndex) || variantIndex < 0 || variantIndex >= variants.length) {
      variantIndex = Math.floor(Math.random() * variants.length);
      state.levelVariants = { ...state.levelVariants, [base.id]: variantIndex };
      if (state.campaign) state.campaign.variants = { ...state.levelVariants };
    }
    state.levelVariant = variantIndex;
    const variant = variants[variantIndex] || {};
    return {
      ...base,
      walls: [...(base.walls || []), ...(variant.walls || [])],
      spikes: [...(base.spikes || []), ...(variant.spikes || [])],
      movingWalls: [...(base.movingWalls || []), ...(variant.movingWalls || [])],
      zones: [...(base.zones || []), ...(variant.zones || [])],
      meteors: [...(base.meteors || []), ...(variant.meteors || [])],
      rockfalls: [...(base.rockfalls || []), ...(variant.rockfalls || [])],
      anomalies: [...(base.anomalies || []), ...(variant.anomalies || [])],
      checkpoints: [...(base.checkpoints || []), ...(variant.checkpoints || [])],
      turrets: [...(base.turrets || []), ...(variant.turrets || [])],
      mines: [...(base.mines || []), ...(variant.mines || [])],
      doors: [...(base.doors || []), ...(variant.doors || [])],
      jammers: [...(base.jammers || []), ...(variant.jammers || [])],
      satellites: [...(base.satellites || []), ...(variant.satellites || [])],
      orbitalPlatforms: [...(base.orbitalPlatforms || []), ...(variant.orbitalPlatforms || [])]
    };
  }

  function currentLevel() {
    return state.activeLevel || levels[state.levelIndex];
  }

  function worldBounds(level = currentLevel()) {
    return level.world || { w: W, h: H };
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function updateRouteProgress() {
    const level = currentLevel();
    const startX = level.start.x + level.start.w / 2;
    const startY = level.start.y;
    const goalX = level.goal.x + level.goal.w / 2;
    const goalY = level.goal.y;
    if (level.verticalAscent) {
      const span = Math.max(1, level.start.y - level.goal.y);
      state.routeProgress = clamp((level.start.y - ship.y) / span, 0, 1);
      return;
    }
    const total = Math.hypot(goalX - startX, goalY - startY) || 1;
    const remaining = Math.hypot(goalX - ship.x, goalY - ship.y);
    state.routeProgress = clamp(1 - remaining / total, 0, 1);
  }

  function updateCamera(dt = 0, immediate = false) {
    const level = currentLevel();
    const world = worldBounds(level);
    const lookX = level.verticalAscent ? ship.vx * .2 : ship.vx * .34;
    const lookY = level.verticalAscent ? clamp(ship.vy * .52 - 105, -270, 70) : ship.vy * .24;
    const targetX = clamp(ship.x - W / 2 + lookX, 0, Math.max(0, world.w - W));
    const targetY = clamp(ship.y - H / 2 + lookY, 0, Math.max(0, world.h - H));
    state.camera.targetX = targetX;
    state.camera.targetY = targetY;
    if (immediate) {
      state.camera.x = targetX;
      state.camera.y = targetY;
    } else {
      const ease = 1 - Math.exp(-Math.max(0, dt) * 4.8);
      state.camera.x += (targetX - state.camera.x) * ease;
      state.camera.y += (targetY - state.camera.y) * ease;
    }
  }

  function formatTime(value) {
    if (!Number.isFinite(value)) return "--:--.---";
    const minutes = Math.floor(value / 60);
    const seconds = Math.floor(value % 60);
    const milliseconds = Math.floor((value % 1) * 1000);
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(milliseconds).padStart(3, "0")}`;
  }

  function showPhaseBanner(title, subtitle = "") {
    state.phaseBanner = { title: String(title || ""), subtitle: String(subtitle || "") };
    state.phaseBannerTimer = 2.8;
  }

  function updatePhaseBanner(dt) {
    state.phaseBannerTimer = Math.max(0, state.phaseBannerTimer - dt);
    if (state.phaseBannerTimer <= 0) state.phaseBanner = null;
  }

  function normalizeAngle(angle) {
    while (angle > Math.PI) angle -= TAU;
    while (angle < -Math.PI) angle += TAU;
    return angle;
  }

  function angleDifference(a, b) {
    return Math.abs(normalizeAngle(a - b));
  }

  function lerpAngle(a, b, amount) {
    return a + normalizeAngle(b - a) * amount;
  }

  function rectPolygon(rect) {
    return [
      { x: rect.x, y: rect.y },
      { x: rect.x + rect.w, y: rect.y },
      { x: rect.x + rect.w, y: rect.y + rect.h },
      { x: rect.x, y: rect.y + rect.h }
    ];
  }

  function shipPolygon() {
    const forward = { x: Math.cos(ship.angle), y: Math.sin(ship.angle) };
    const perpendicular = { x: -forward.y, y: forward.x };
    const nose = { x: ship.x + forward.x * 23, y: ship.y + forward.y * 23 };
    const rearX = ship.x - forward.x * 15;
    const rearY = ship.y - forward.y * 15;
    return [
      nose,
      { x: rearX + perpendicular.x * 13, y: rearY + perpendicular.y * 13 },
      { x: rearX - perpendicular.x * 13, y: rearY - perpendicular.y * 13 }
    ];
  }

  function axesForPolygon(polygon) {
    const axes = [];
    for (let index = 0; index < polygon.length; index += 1) {
      const current = polygon[index];
      const next = polygon[(index + 1) % polygon.length];
      const edgeX = next.x - current.x;
      const edgeY = next.y - current.y;
      const length = Math.hypot(edgeX, edgeY) || 1;
      axes.push({ x: -edgeY / length, y: edgeX / length });
    }
    return axes;
  }

  function projectPolygon(polygon, axis) {
    let min = Infinity;
    let max = -Infinity;
    polygon.forEach(point => {
      const value = point.x * axis.x + point.y * axis.y;
      min = Math.min(min, value);
      max = Math.max(max, value);
    });
    return { min, max };
  }

  function polygonsIntersect(a, b) {
    const axes = axesForPolygon(a).concat(axesForPolygon(b));
    return axes.every(axis => {
      const projectionA = projectPolygon(a, axis);
      const projectionB = projectPolygon(b, axis);
      return projectionA.max >= projectionB.min && projectionB.max >= projectionA.min;
    });
  }

  function spikePolygons(strip) {
    const polygons = [];
    for (let index = 0; index < strip.count; index += 1) {
      const offset = index * strip.size;
      if (strip.dir === "up") {
        polygons.push([
          { x: strip.x + offset, y: strip.y },
          { x: strip.x + offset + strip.size, y: strip.y },
          { x: strip.x + offset + strip.size / 2, y: strip.y - strip.size }
        ]);
      } else if (strip.dir === "down") {
        polygons.push([
          { x: strip.x + offset, y: strip.y },
          { x: strip.x + offset + strip.size, y: strip.y },
          { x: strip.x + offset + strip.size / 2, y: strip.y + strip.size }
        ]);
      } else if (strip.dir === "left") {
        polygons.push([
          { x: strip.x, y: strip.y + offset },
          { x: strip.x, y: strip.y + offset + strip.size },
          { x: strip.x - strip.size, y: strip.y + offset + strip.size / 2 }
        ]);
      } else {
        polygons.push([
          { x: strip.x, y: strip.y + offset },
          { x: strip.x, y: strip.y + offset + strip.size },
          { x: strip.x + strip.size, y: strip.y + offset + strip.size / 2 }
        ]);
      }
    }
    return polygons;
  }

  function movingRect(wall) {
    const displacement = Math.sin(state.worldTime * wall.speed + wall.phase) * wall.amplitude;
    return {
      ...wall,
      x: wall.x + (wall.axis === "x" ? displacement : 0),
      y: wall.y + (wall.axis === "y" ? displacement : 0),
      w: wall.w,
      h: wall.h
    };
  }

  function meteorPosition(meteor) {
    if (Array.isArray(meteor.path) && meteor.path.length >= 2) {
      const period = Math.max(1, meteor.period || 8);
      const phase = Number(meteor.phase) || 0;
      const progress = ((state.worldTime / period + phase) % 1 + 1) % 1;
      const scaled = progress * meteor.path.length;
      const index = Math.floor(scaled) % meteor.path.length;
      const next = (index + 1) % meteor.path.length;
      const local = scaled - Math.floor(scaled);
      const eased = local * local * (3 - 2 * local);
      return {
        x: meteor.path[index].x + (meteor.path[next].x - meteor.path[index].x) * eased,
        y: meteor.path[index].y + (meteor.path[next].y - meteor.path[index].y) * eased
      };
    }
    const wave = state.worldTime * meteor.speed + meteor.phase;
    if (meteor.axis === "x") return { x: meteor.baseX + Math.sin(wave) * meteor.amplitude, y: meteor.baseY };
    if (meteor.axis === "y") return { x: meteor.baseX, y: meteor.baseY + Math.sin(wave) * meteor.amplitude };
    return { x: meteor.baseX + Math.cos(wave) * meteor.amplitude, y: meteor.baseY + Math.sin(wave) * meteor.amplitude * .62 };
  }

  function applyAnomalies(dt, level) {
    for (const anomaly of level.anomalies || []) {
      const dx = anomaly.x - ship.x;
      const dy = anomaly.y - ship.y;
      const distance = Math.hypot(dx, dy) || 1;
      if (distance >= anomaly.radius) continue;
      const falloff = Math.pow(1 - distance / anomaly.radius, 1.35);
      const sign = anomaly.type === "repel" ? -1 : 1;
      const force = anomaly.strength * falloff * sign;
      ship.vx += dx / distance * force * dt;
      ship.vy += dy / distance * force * dt;
    }
  }

  function currentGravity(level) {
    const base = Number(level.gravity) || 0;
    if (!level.earthGravity) return base;
    const world = worldBounds(level);
    const progress = clamp(ship.x / Math.max(1, world.w), 0, 1);
    const curve = Math.pow(progress, Number(level.earthGravity.curve) || 1);
    const start = Number(level.earthGravity.start) || 0;
    const end = Number(level.earthGravity.end) || 0;
    return base + start + (end - start) * curve;
  }

  function smoothStep(edge0, edge1, value) {
    const t = clamp((value - edge0) / Math.max(1, edge1 - edge0), 0, 1);
    return t * t * (3 - 2 * t);
  }

  function atmosphereFactor(level = currentLevel()) {
    const atmosphere = level?.atmosphere;
    if (!atmosphere) return 0;
    const rise = smoothStep(atmosphere.startX, atmosphere.peakX, ship.x);
    const fall = 1 - smoothStep(atmosphere.peakX, atmosphere.endX, ship.x);
    return clamp(ship.x <= atmosphere.peakX ? rise : fall, 0, 1);
  }

  function currentThrust(level = currentLevel()) {
    const loss = Number(level?.atmosphere?.thrustLoss) || 0;
    state.thrustEfficiency = 1 - atmosphereFactor(level) * loss;
    return (Number(level?.thrust) || 0) * state.thrustEfficiency;
  }

  function currentFuelBurn(level = currentLevel()) {
    return (Number(level?.fuelBurn) || 0) * (1 + atmosphereFactor(level) * .18);
  }

  function updateFinalMissionSystems(dt, level) {
    if (!level?.finalMission || state.mode !== "playing") {
      state.atmosphericHeat += (0 - state.atmosphericHeat) * Math.min(1, dt * 2.5);
      state.thrustEfficiency = 1;
      state.missionPhase = "";
      return;
    }
    const progress = clamp(ship.x / Math.max(1, level.world.w), 0, 1);
    const nextPhase = progress < .32 ? "CAMPO DE ESCOMBROS" : progress < .68 ? "ENTRADA ATMOSFÉRICA" : "DESCENSO FINAL";
    if (nextPhase !== state.missionPhase) {
      state.lastMissionPhase = state.missionPhase;
      state.missionPhase = nextPhase;
      showPhaseBanner(nextPhase, nextPhase === "CAMPO DE ESCOMBROS" ? "COMBATE Y NAVEGACIÓN" : nextPhase === "ENTRADA ATMOSFÉRICA" ? "HULL STRESS / THRUST DEGRADED" : "NO COMBAT / PRECISION LANDING");
      audio.phaseShift();
    } else state.missionPhase = nextPhase;
    audio.updateAmbient(level, state.missionPhase);
    const factor = atmosphereFactor(level);
    const speed = Math.hypot(ship.vx, ship.vy);
    const targetHeat = clamp(factor * (28 + speed * .17 + (state.thrusting ? 15 : 0)), 0, 100);
    const heatEase = 1 - Math.exp(-dt * (targetHeat > state.atmosphericHeat ? 1.85 : 1.15));
    state.atmosphericHeat += (targetHeat - state.atmosphericHeat) * heatEase;
    currentThrust(level);

    if (factor > .02) {
      const turbulence = (Number(level.atmosphere?.turbulence) || 0) * factor;
      ship.vx += (Math.sin(state.worldTime * 3.7 + ship.y * .004) * turbulence + Math.sin(state.worldTime * 8.4) * turbulence * .22) * dt;
      ship.vy += (Math.cos(state.worldTime * 2.9 + ship.x * .003) * turbulence * .42) * dt;
      state.screenShake = Math.max(state.screenShake, factor * 2.5);
    }

    [34, 58, 80].forEach((threshold, index) => {
      if (state.atmosphericHeat < threshold || state.thermalMarks.has(threshold)) return;
      state.thermalMarks.add(threshold);
      const count = 5 + index * 3;
      for (let i = 0; i < count; i += 1) {
        state.particles.push({ x: ship.x + (Math.random() - .5) * 24, y: ship.y + (Math.random() - .5) * 20,
          vx: ship.vx * .2 + (Math.random() - .5) * 120, vy: ship.vy * .2 + 50 + Math.random() * 120,
          life: .65 + Math.random() * .8, maxLife: 1.45, size: 2 + Math.random() * 5, type: "debris" });
      }
      state.message = index < 2 ? "THERMAL STRESS: fragmentos del casco se han desprendido." : "HULL CRITICAL: reduce velocidad y propulsión.";
      state.hazardNotice = index < 2 ? "THERMAL STRESS" : "HULL TEMPERATURE CRITICAL";
      state.hazardNoticeTimer = 1.6;
      state.screenShake = Math.max(state.screenShake, 7 + index * 2);
      audio.structureBreak?.();
    });

    if (state.atmosphericHeat >= (Number(level.atmosphere?.criticalHeat) || 98)) {
      crash("La temperatura del casco ha superado el límite estructural durante la reentrada.");
    }
  }

  function orbitalPlatformRect(platform) { return movingRect(platform); }

  function awardThreat(id, score, message) {
    if (!id || state.scoredMeteors.has(id)) return;
    state.scoredMeteors.add(id);
    state.score += Math.max(0, Number(score) || 0);
    state.message = `${message} +${Math.max(0, Number(score) || 0)} SCORE.`;
    if (state.campaign?.active) saveCampaign({ silent: true });
  }

  function spawnThreatBurstAt(x, y, type = "spark", count = 18) {
    for (let index = 0; index < count; index += 1) {
      const angle = Math.random() * TAU;
      const speed = 40 + Math.random() * 210;
      state.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        life: .3 + Math.random() * .65, maxLife: .95, size: 1.5 + Math.random() * 4.8, type });
    }
  }

  function updateThreatSystems(dt, level) {
    let interferenceTarget = 0;
    for (const jammer of level.jammers || []) {
      if (ship.x >= jammer.x && ship.x <= jammer.x + jammer.w && ship.y >= jammer.y && ship.y <= jammer.y + jammer.h) {
        interferenceTarget = Math.max(interferenceTarget, jammer.strength || 1);
      }
    }
    const interferenceEase = 1 - Math.exp(-dt * (interferenceTarget > state.radarInterference ? 6 : 2.4));
    state.radarInterference += (interferenceTarget - state.radarInterference) * interferenceEase;

    state.turrets.forEach(turret => {
      if (turret.destroyed) return;
      turret.flash = Math.max(0, (turret.flash || 0) - dt * 4);
      const dx = ship.x - turret.x, dy = ship.y - turret.y;
      const distance = Math.hypot(dx, dy) || 1;
      turret.aim = Math.atan2(dy, dx);
      turret.cooldown -= dt;
      if (distance > (turret.range || 900) || turret.cooldown > 0 || state.mode !== "playing") return;
      const prediction = Math.min(.72, distance / Math.max(100, turret.projectileSpeed || 200) * .22);
      const angle = Math.atan2(ship.y + ship.vy * prediction - turret.y, ship.x + ship.vx * prediction - turret.x);
      const speed = turret.projectileSpeed || 205;
      state.enemyProjectiles.push({ id: `${turret.id}-${Math.floor(state.worldTime * 1000)}`,
        x: turret.x + Math.cos(angle) * 24, y: turret.y + Math.sin(angle) * 24,
        vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, radius: 5, life: 9, source: turret.id });
      turret.cooldown = Math.max(.8, turret.fireRate || 2); turret.flash = 1; audio.enemyShot?.();
    });

    state.mines.forEach(mine => {
      if (mine.destroyed) return;
      mine.pulse += dt * (mine.armed ? 11 : 2.4);
      const distance = Math.hypot(ship.x - mine.x, ship.y - mine.y);
      if (!mine.armed && distance <= (mine.trigger || 145)) {
        mine.armed = true; mine.timer = .82; state.hazardNotice = `MINA ${mine.id} ARMADA`; state.hazardNoticeTimer = 1.15;
        state.message = `PROXIMITY ALERT: ${mine.id}. Aléjate o destrúyela.`; audio.mineArm?.();
      }
      if (!mine.armed) return;
      mine.timer -= dt;
      if (mine.timer > 0) return;
      mine.destroyed = true; spawnThreatBurstAt(mine.x, mine.y, "explosion", 34);
      state.screenShake = Math.max(state.screenShake, 11); audio.mineExplosion?.();
      if (distance <= (mine.blast || 125) + 16) crash(`La mina ${mine.id} ha detonado junto a la nave.`);
    });

    for (let index = state.enemyProjectiles.length - 1; index >= 0; index -= 1) {
      const projectile = state.enemyProjectiles[index]; projectile.life -= dt;
      projectile.x += projectile.vx * dt; projectile.y += projectile.vy * dt;
      const world = worldBounds(level);
      const hitWall = (level.walls || []).some(wall => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, wall));
      const hitMoving = (level.movingWalls || []).some(wall => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, movingRect(wall)));
      const hitPlatform = (level.orbitalPlatforms || []).some(platform => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, orbitalPlatformRect(platform)));
      const hitDoor = state.destructibleDoors.some(door => !door.destroyed && circleIntersectsRect(projectile.x, projectile.y, projectile.radius, door));
      if (projectile.life <= 0 || projectile.x < -50 || projectile.x > world.w + 50 || projectile.y < -50 || projectile.y > world.h + 50 || hitWall || hitMoving || hitPlatform || hitDoor) {
        state.enemyProjectiles.splice(index, 1); continue;
      }
      if (Math.hypot(projectile.x - ship.x, projectile.y - ship.y) <= projectile.radius + 15) {
        state.enemyProjectiles.splice(index, 1); crash(`Impacto de la defensa orbital ${projectile.source}.`); return;
      }
    }
  }

  function updateRockfalls(dt, level) {
    state.hazardNoticeTimer = Math.max(0, state.hazardNoticeTimer - dt);
    if (state.hazardNoticeTimer <= 0) state.hazardNotice = null;
    state.rockfallControllers.forEach(controller => {
      const cfg = controller.config;
      const t = cfg.trigger;
      if (!controller.triggered && ship.x >= t.x && ship.x <= t.x + t.w && ship.y >= t.y && ship.y <= t.y + t.h) {
        controller.triggered = true;
        controller.elapsed = 0;
        state.hazardNotice = `DERRUMBE ${cfg.id}`;
        state.hazardNoticeTimer = 2.2;
        state.message = `ALERTA: desprendimiento ${cfg.id}. Busca cobertura o destruye los fragmentos pequeños.`;
        state.screenShake = Math.max(state.screenShake, 5);
        audio.rockfall?.();
      }
      if (!controller.triggered || controller.spawned >= cfg.count) return;
      controller.elapsed += dt;
      while (controller.spawned < cfg.count && controller.elapsed >= (cfg.delay || 0) + controller.spawned * cfg.interval) {
        const index = controller.spawned++;
        const seed = (index * 73 + cfg.id.charCodeAt(cfg.id.length - 1) * 17) % 997;
        const mix = seed / 997;
        const radius = cfg.rMin + (cfg.rMax - cfg.rMin) * mix;
        const vx = cfg.vxMin + (cfg.vxMax - cfg.vxMin) * (((seed * 31) % 991) / 991);
        const vy = cfg.vyMin + (cfg.vyMax - cfg.vyMin) * (((seed * 47) % 983) / 983);
        state.fallingRocks.push({
          id: `${cfg.id}-${index + 1}`,
          x: cfg.origin.x + (mix - .5) * cfg.spread,
          y: cfg.origin.y - radius,
          vx, vy, r: radius,
          hp: radius > 26 ? 3 : 2,
          hpLeft: radius > 26 ? 3 : 2,
          score: cfg.score,
          rotation: mix * TAU,
          spin: (mix - .5) * 2.1,
          life: 18,
          destructible: true,
          falling: true
        });
      }
    });

    for (let index = state.fallingRocks.length - 1; index >= 0; index -= 1) {
      const rock = state.fallingRocks[index];
      rock.life -= dt;
      rock.vy += level.gravity * .34 * dt;
      rock.x += rock.vx * dt;
      rock.y += rock.vy * dt;
      rock.rotation += rock.spin * dt;
      if (rock.life <= 0 || rock.y > level.world.h + 120 || rock.x < -120 || rock.x > level.world.w + 120) state.fallingRocks.splice(index, 1);
    }
  }

  function resetShip({ keepOverlay = false } = {}) {
    const level = currentLevel();
    const checkpoint = state.checkpoint && state.checkpoint.levelIndex === state.levelIndex ? state.checkpoint : null;
    ship.x = checkpoint ? checkpoint.x : level.start.x + level.start.w / 2;
    ship.y = checkpoint ? checkpoint.y : level.start.y - 15;
    ship.vx = 0;
    ship.vy = 0;
    ship.angle = -Math.PI / 2;
    ship.targetAngle = -Math.PI / 2;
    updateCamera(0, true);
    state.pointer.screenX = clamp(ship.x - state.camera.x, 0, W);
    state.pointer.screenY = clamp(ship.y - state.camera.y - 190, 0, H);
    state.pointer.x = state.camera.x + state.pointer.screenX;
    state.pointer.y = state.camera.y + state.pointer.screenY;
    updateRouteProgress();
    state.mode = "ready";
    state.started = false;
    state.thrusting = false;
    state.elapsed = checkpoint ? checkpoint.elapsed : 0;
    state.launchGrace = checkpoint ? .55 : 0;
    state.fuel = checkpoint ? checkpoint.fuel : 100;
    state.collectedCells = new Set(checkpoint ? checkpoint.cells : []);
    state.cellPulse = 0;
    state.lastLanding = null;
    state.recharge = null;
    state.particles.length = 0;
    state.projectiles.length = 0;
    state.enemyProjectiles.length = 0;
    state.meteors = (level.meteors || []).map(meteor => ({ ...meteor, baseX: meteor.x, baseY: meteor.y, currentX: meteor.x, currentY: meteor.y, hpLeft: meteor.hp, destroyed: false, rotation: meteor.phase || 0 }));
    state.turrets = (level.turrets || []).map(turret => ({ ...turret, hpLeft: turret.hp, destroyed: false, cooldown: Math.max(.35, (turret.fireRate || 2) * ((turret.phase || 0) % 1)), aim: 0, flash: 0 }));
    state.mines = (level.mines || []).map(mine => ({ ...mine, destroyed: false, armed: false, timer: 0, pulse: Math.random() * TAU }));
    state.destructibleDoors = (level.doors || []).map(door => ({ ...door, hpLeft: door.hp, destroyed: false, flash: 0 }));
    state.radarInterference = 0;
    state.atmosphericHeat = 0;
    state.thrustEfficiency = 1;
    state.thermalMarks = new Set();
    state.missionPhase = level.finalMission ? "CAMPO DE ESCOMBROS" : "";
    state.fallingRocks = [];
    state.rockfallControllers = (level.rockfalls || []).map(config => ({ config, triggered: false, elapsed: 0, spawned: 0 }));
    state.hazardNotice = null;
    state.hazardNoticeTimer = 0;
    state.firing = false;
    state.weaponHeat = 0;
    state.overheated = false;
    state.weaponNotice = null;
    state.weaponNoticeTimer = 0;
    state.screenShake = 0;
    state.flash = 0;
    state.message = checkpoint ? `${checkpoint.id} ACTIVE · ASCENT ${checkpoint.ascent}% · Fuel restaurado. Continúa el ascenso.` : (state.settings.controlMode === "arcade" ? "En muelle. WASD o flechas para impulsar · Espacio para disparar." : "En muelle. Clic izquierdo para impulsar · clic derecho o Espacio para disparar.");
    audio.stopThrust();
    if (!keepOverlay) hideOverlay();
    updateHud();
  }

  function loadLevel(index, { showIntro = false } = {}) {
    state.levelIndex = Math.max(0, Math.min(levels.length - 1, index));
    state.activeLevel = buildActiveLevel(state.levelIndex);
    state.checkpoint = state.campaign?.checkpoint && state.campaign.checkpoint.levelIndex === state.levelIndex ? { ...state.campaign.checkpoint, cells: [...state.campaign.checkpoint.cells] } : null;
    state.attempts = 1;
    state.worldTime = 0;
    state.scoredMeteors = new Set(state.campaign?.meteorAwards || []);
    state.sectorDeathsStart = state.deaths;
    resetShip({ keepOverlay: true });
    showPhaseBanner(`FASE ${String(currentLevel().id).padStart(2, "0")}`, currentLevel().name.toUpperCase());
    audio.updateAmbient(currentLevel(), "MISSION");
    renderLevelButtons();
    if (showIntro) {
      const level = currentLevel();
      showOverlay({
        kicker: `FASE ${String(level.id).padStart(2, "0")} / ${level.difficulty.toUpperCase()}`,
        title: level.name,
        copy: level.description,
        primary: "Preparar nave",
        action: "start"
      });
    } else {
      hideOverlay();
    }
    if (state.creditActive && state.campaign?.active) {
      state.campaign.levelIndex = state.levelIndex;
      state.campaign.attempts = state.attempts;
      saveCampaign({ silent: true });
    }
    updateHud();
  }

  function beginFlight() {
    if (state.mode === "ready") {
      state.mode = "playing";
      state.started = true;
      state.launchGrace = .34;
      state.message = "Maniobra activa. Dosifica el impulso, vigila el fuel y no sobrecargues el cañón.";
      saveCampaign({ silent: true });
    }
  }

  function setThrust(active) {
    const hasFuel = state.fuel > .05;
    const shouldThrust = state.creditActive && Boolean(active) && hasFuel && (state.mode === "ready" || state.mode === "playing");
    if (shouldThrust) beginFlight();
    state.thrusting = shouldThrust;
    if (state.thrusting) audio.startThrust();
    else audio.stopThrust();
    if (ui.toast) {
      ui.toast.hidden = !state.thrusting;
      ui.toast.textContent = state.thrusting ? "PROPULSOR VECTORIAL" : "";
    }
    if (ui.thrustBar) ui.thrustBar.style.width = state.thrusting ? "100%" : "0%";
  }


  function setFiring(active) {
    const playable = state.creditActive && !ui.arcadeLayer?.classList.contains("is-visible") && state.mode === "playing";
    state.firing = Boolean(active) && playable && !state.overheated;
  }

  function triggerOvercharge() {
    if (state.overheated) return;
    state.overheated = true;
    state.firing = false;
    state.weaponHeat = 100;
    state.weaponNotice = "overheat";
    state.weaponNoticeTimer = 0;
    state.message = "OVERCHARGE! Sistema de armas bloqueado. Espera a que el núcleo se enfríe.";
    state.screenShake = Math.max(state.screenShake, 5);
    audio.overchargeAlarm();
  }

  function spawnProjectile() {
    const forwardX = Math.cos(ship.angle);
    const forwardY = Math.sin(ship.angle);
    state.projectiles.push({
      x: ship.x + forwardX * 28,
      y: ship.y + forwardY * 28,
      vx: ship.vx + forwardX * 690,
      vy: ship.vy + forwardY * 690,
      life: 1.25,
      radius: 3
    });
    state.weaponHeat = Math.min(100, state.weaponHeat + 9.2);
    state.fireCooldown = .095;
    audio.shot();
    if (state.weaponHeat >= 99.5) triggerOvercharge();
  }

  function updateWeapon(dt) {
    state.fireCooldown = Math.max(0, state.fireCooldown - dt);
    state.weaponNoticeTimer = Math.max(0, state.weaponNoticeTimer - dt);
    if (state.weaponNoticeTimer <= 0 && state.weaponNotice === "ready") state.weaponNotice = null;

    if (state.overheated) {
      state.weaponHeat = Math.max(0, state.weaponHeat - 29 * dt);
      if (state.weaponHeat <= 12) {
        state.weaponHeat = 0;
        state.overheated = false;
        state.weaponNotice = "ready";
        state.weaponNoticeTimer = 1.45;
        state.message = "WEAPON READY. Cañón vectorial disponible.";
        audio.weaponRecovered();
      }
    } else {
      const cooling = state.firing ? 3.5 : 24;
      state.weaponHeat = Math.max(0, state.weaponHeat - cooling * dt);
      if (state.firing && state.fireCooldown <= 0 && (state.mode === "ready" || state.mode === "playing")) spawnProjectile();
    }

    for (let index = state.projectiles.length - 1; index >= 0; index -= 1) {
      const projectile = state.projectiles[index];
      projectile.life -= dt;
      projectile.x += projectile.vx * dt;
      projectile.y += projectile.vy * dt;
      const world = worldBounds();
      if (projectile.life <= 0 || projectile.x < -20 || projectile.x > world.w + 20 || projectile.y < -20 || projectile.y > world.h + 20) {
        state.projectiles.splice(index, 1);
      }
    }
  }

  function startFuelRecharge({ checkpoint = null } = {}) {
    if (state.mode !== "playing") return;
    setThrust(false);
    state.mode = "recharging";
    setFiring(false);
    const target = checkpoint ? Math.max(state.fuel, Math.min(100, Math.max(1, Number(checkpoint.fuelTarget) || 100))) : 100;
    state.recharge = { from: state.fuel, target, elapsed: 0, duration: checkpoint ? 2.8 : 2.15, checkpoint };
    state.message = checkpoint ? `${checkpoint.id} / ${checkpoint.phase || `RUTA ${checkpoint.ascent}%`} · Enlace de combustible y guardado de misión.` : "FUEL LINK conectado. Transferencia de combustible en curso...";
    audio.fuelPump(state.recharge.duration);
    updateHud();
  }

  function activateCheckpoint(platform, landing) {
    const alreadyActive = state.checkpoint?.id === platform.id && state.checkpoint.levelIndex === state.levelIndex;
    state.checkpoint = {
      levelIndex: state.levelIndex,
      id: platform.id,
      x: platform.x + platform.w / 2,
      y: platform.y - 15,
      elapsed: state.elapsed,
      cells: [...state.collectedCells],
      fuel: Math.min(100, Math.max(1, Number(platform.fuelTarget) || 100)),
      ascent: platform.ascent || Math.round(state.routeProgress * 100),
      phase: String(platform.phase || ""),
      fuelTarget: Math.min(100, Math.max(1, Number(platform.fuelTarget) || 100))
    };
    state.message = `${platform.id} ACTIVATED · ${state.checkpoint.phase || `RUTA ${state.checkpoint.ascent}%`} · TIME ${formatTime(state.elapsed)} · SCORE ${String(Math.floor(state.score)).padStart(6, "0")}`;
    state.screenShake = Math.max(state.screenShake, 3);
    showPhaseBanner(platform.id, `${state.checkpoint.phase || `RUTA ${state.checkpoint.ascent}%`} / REFUEL & SAVE`);
    audio.checkpoint();
    saveCampaign({ silent: false });
    startFuelRecharge({ checkpoint: state.checkpoint });
    if (!alreadyActive) audio.tone(520, .12, "sine", .025, 260);
  }

  function crash(reason) {
    if (state.mode !== "playing") return;
    state.mode = "crashed";
    state.thrusting = false;
    state.firing = false;
    state.screenShake = 15;
    state.flash = 1;
    state.message = reason;
    state.deaths += 1;
    state.score = Math.max(0, state.score - DEATH_PENALTY);
    if (state.campaign?.active) {
      state.campaign.deaths = state.deaths;
      state.campaign.score = state.score;
      state.campaign.attempts = state.attempts + 1;
      saveCampaign({ silent: true });
    }
    audio.explosion();
    spawnExplosion();
    updateHud();
    setTimeout(() => {
      if (state.mode !== "crashed") return;
      showOverlay({
        kicker: "FALLO DE NAVEGACIÓN / HULL LOST",
        title: "Unidad destruida",
        copy: `${reason} Intenta realizar correcciones más cortas y deja que la inercia trabaje.`,
        primary: "Reintentar",
        action: "retry"
      });
    }, 620);
  }

  function buildCampaignResult({ grade, levelTotal }) {
    const maxCells = levels.reduce((sum, level) => sum + (level.cells?.length || 0), 0);
    const cells = state.campaignCells.reduce((sum, value) => sum + (Number(value) || 0), 0);
    return {
      id: `mission-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      version: "1.0",
      balanceVersion: BALANCE_VERSION,
      score: Math.max(0, Math.floor(state.score)),
      time: Math.max(0, state.campaignTime),
      deaths: Math.max(0, Math.floor(state.deaths)),
      cells,
      maxCells,
      grade,
      finalBonus: levelTotal,
      landings: state.campaignGrades.map(value => value || "-").join(" "),
      phaseScores: state.scoreBreakdown.map(entry => entry ? { ...entry } : null),
      completedAt: new Date().toISOString(),
      shipColor: state.profile.equippedColor
    };
  }

  function showCampaignResult(result) {
    state.finalResult = result;
    if (ui.resultScore) ui.resultScore.textContent = String(result.score).padStart(6, "0");
    if (ui.resultTime) ui.resultTime.textContent = formatTime(result.time);
    if (ui.resultDeaths) ui.resultDeaths.textContent = String(result.deaths).padStart(2, "0");
    if (ui.resultCells) ui.resultCells.textContent = `${result.cells} / ${result.maxCells}`;
    if (ui.resultLandings) ui.resultLandings.textContent = result.landings;
    if (ui.resultRegister) {
      ui.resultRegister.hidden = Boolean(result.scoreRegistered);
      ui.resultRegister.textContent = result.scoreRegistered ? "SCORE REGISTRADO" : "REGISTRAR SCORE";
    }
    if (ui.resultBack) ui.resultBack.hidden = !result.scoreRegistered;
    showArcadeScreen(ui.resultScreen);
    state.mode = "results";
    audio.tone(180, .45, "sine", .03, 420);
    setTimeout(() => audio.tone(520, .4, "sine", .025, 260), 240);
  }

  function finishLevel(landing = { speed: 0, angle: 0 }) {
    if (state.mode !== "playing") return;
    state.mode = "landed";
    state.thrusting = false;
    state.firing = false;
    const grade = calculateLandingGrade(landing);
    state.lastLanding = { ...landing, grade, cells: state.collectedCells.size, fuel: state.fuel };
    ship.vx = 0;
    ship.vy = 0;
    ship.angle = -Math.PI / 2;
    state.message = `Atraque confirmado. Categoría ${grade}.`;
    audio.landing();
    const previousBest = state.progress.best[state.levelIndex];
    const isRecord = previousBest === null || state.elapsed < previousBest;
    if (isRecord) state.progress.best[state.levelIndex] = state.elapsed;
    const previousGrade = state.progress.grades[state.levelIndex];
    if (gradeRank(grade) > gradeRank(previousGrade)) state.progress.grades[state.levelIndex] = grade;
    state.progress.cells[state.levelIndex] = Math.max(state.progress.cells[state.levelIndex], state.collectedCells.size);
    state.progress.unlocked = Math.min(levels.length, Math.max(state.progress.unlocked, state.levelIndex + 2));
    const level = currentLevel();
    const gradeBonus = ({ S: 5000, A: 3000, B: 1500, C: 500 })[grade] || 0;
    const sectorBonus = level.baseScore || (5000 + state.levelIndex * 1500);
    const fuelBonus = Math.min(1600, Math.round(state.fuel) * 16);
    const cellsBonus = state.collectedCells.size * CELL_SCORE + (state.collectedCells.size === level.cells.length ? ALL_CELLS_BONUS : 0);
    const timeRatio = clamp(1 - Math.max(0, state.elapsed - level.parTime) / Math.max(30, level.parTime), 0, 1);
    const rawTimeBonus = Math.round((level.timeBonusMax || 1800) * timeRatio);
    const timeBonus = Math.min(rawTimeBonus, Math.round(sectorBonus * .22));
    const sectorDeaths = Math.max(0, state.deaths - state.sectorDeathsStart);
    const survivalBonus = sectorDeaths === 0 ? (level.survivalBonus || 2500) : 0;
    const levelTotal = sectorBonus + gradeBonus + fuelBonus + cellsBonus + timeBonus + survivalBonus;
    state.scoreBreakdown[state.levelIndex] = { base: sectorBonus, grade: gradeBonus, fuel: fuelBonus, cells: cellsBonus, time: timeBonus, survival: survivalBonus, total: levelTotal };
    state.campaignCells[state.levelIndex] = state.collectedCells.size;
    state.campaignGrades[state.levelIndex] = grade;
    state.score += levelTotal;
    state.checkpoint = null;
    const finalLevel = state.levelIndex === levels.length - 1;
    if (state.campaign?.active && !finalLevel) {
      state.campaign.score = state.score;
      state.campaign.deaths = state.deaths;
      state.campaign.totalTime = state.campaignTime;
      saveCampaign({ levelIndex: Math.min(levels.length - 1, state.levelIndex + 1), attempts: 1 });
    }
    saveProgress();
    renderLevelButtons();
    updateHud();

    const cellCopy = `${state.collectedCells.size}/${currentLevel().cells.length} celdas · ${Math.round(state.fuel)}% combustible`;
    const bonusCopy = `BASE ${sectorBonus} · RANGO ${gradeBonus} · CELDAS ${cellsBonus} · TIEMPO ${timeBonus} · SUPERVIVENCIA ${survivalBonus}`;
    setTimeout(() => {
      if (state.mode !== "landed") return;
      if (finalLevel) {
        const result = buildCampaignResult({ grade, levelTotal });
        safeWrite(RESULT_KEY, result);
        state.profile.campaignsCompleted = Math.max(0, Number(state.profile.campaignsCompleted) || 0) + 1;
        saveProfile();
        state.campaign = null;
        safeWrite(CAMPAIGN_KEY, { active: false, completedAt: result.completedAt });
        showCampaignResult(result);
        return;
      }
      showOverlay({
        kicker: `${isRecord ? "NUEVA MEJOR MARCA" : "ATRAQUE CONFIRMADO"} / CATEGORÍA ${grade}`,
        title: "Fase superada",
        copy: `${currentLevel().name}: ${formatTime(state.elapsed)} · ${cellCopy}. +${levelTotal} SCORE. ${bonusCopy}. La siguiente fase ha sido desbloqueada.`,
        primary: "Siguiente fase",
        action: "next"
      });
    }, 650);
  }

  function pauseGame() {
    if (!state.creditActive || (state.mode !== "playing" && state.mode !== "ready")) return;
    state.previousMode = state.mode;
    state.mode = "paused";
    setThrust(false);
    setFiring(false);
    state.message = "Simulación en pausa.";
    showOverlay({
      kicker: "SISTEMA EN ESPERA",
      title: "Pausa",
      copy: "La física está detenida. Continúa cuando estés preparado para recuperar el control.",
      primary: "Continuar",
      action: "resume"
    });
    updateHud();
  }

  function resumeGame() {
    state.mode = state.previousMode === "playing" ? "playing" : "ready";
    state.message = state.mode === "playing" ? "Vuelo reanudado." : (state.settings.controlMode === "arcade" ? "En muelle. WASD o flechas para impulsar · Espacio para disparar." : "En muelle. Clic izquierdo para impulsar · clic derecho o Espacio para disparar.");
    hideOverlay();
  }

  function retryLevel() {
    if (!state.creditActive) return;
    state.attempts += 1;
    resetShip();
    saveCampaign({ silent: true });
  }

  function nextLevel() {
    if (state.levelIndex < levels.length - 1) loadLevel(state.levelIndex + 1, { showIntro: true });
    else retryLevel();
  }

  function showOverlay({ kicker, title, copy, primary, action }) {
    state.overlayAction = action;
    ui.overlayKicker.textContent = kicker;
    ui.overlayTitle.textContent = title;
    ui.overlayCopy.textContent = copy;
    ui.startButton.textContent = primary;
    ui.overlay.classList.add("is-visible");
  }

  function hideOverlay() {
    ui.overlay.classList.remove("is-visible");
  }

  function handleOverlayAction() {
    audio.ensure();
    const action = state.overlayAction;
    if (action === "start") resetShip();
    else if (action === "retry") retryLevel();
    else if (action === "next") nextLevel();
    else if (action === "resume") resumeGame();
  }

  function toggleLevelPanel(force) {
    const shouldOpen = typeof force === "boolean" ? force : ui.levelPanel.hidden;
    ui.levelPanel.hidden = !shouldOpen;
    if (shouldOpen) {
      renderLevelButtons();
      ui.levelPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }

  function renderLevelButtons() {
    ui.levelGrid.replaceChildren(...levels.map((level, index) => {
      const button = document.createElement("button");
      const unlocked = index < state.progress.unlocked;
      const best = state.progress.best[index];
      const grade = state.progress.grades[index];
      const cells = state.progress.cells[index] || 0;
      const campaignLocked = Boolean(state.campaign?.active);
      button.type = "button";
      button.className = `flight-level-card${index === state.levelIndex ? " is-active" : ""}`;
      button.disabled = !unlocked || (campaignLocked && index !== state.levelIndex);
      button.innerHTML = `
        <span class="flight-level-card__top">
          <span class="flight-level-card__number">FASE ${String(level.id).padStart(2, "0")}</span>
          <span class="flight-level-card__lock">${unlocked ? (grade || "◇") : "LOCK"}</span>
        </span>
        <span>
          <strong>${level.name}</strong>
          <small>${unlocked ? (best === null ? level.difficulty : `${formatTime(best)} · ${cells}/${level.cells.length} CELDAS`) : "Completa la fase anterior"}</small>
        </span>`;
      button.addEventListener("click", () => {
        if (state.campaign?.active && index !== state.levelIndex) return;
        loadLevel(index, { showIntro: true });
        toggleLevelPanel(false);
      });
      return button;
    }));
  }

  function updatePointer(event) {
    const rect = canvas.getBoundingClientRect();
    const screenX = clamp((event.clientX - rect.left) * W / rect.width, 0, W);
    const screenY = clamp((event.clientY - rect.top) * H / rect.height, 0, H);
    const world = worldBounds();
    state.pointer.screenX = screenX;
    state.pointer.screenY = screenY;
    state.pointer.x = clamp(state.camera.x + screenX, 0, world.w);
    state.pointer.y = clamp(state.camera.y + screenY, 0, world.h);
  }

  function updatePhysics(dt) {
    const level = currentLevel();
    state.worldTime += dt;
    state.cellPulse += dt;
    updatePhaseBanner(dt);
    if (!level.finalMission && state.creditActive) audio.updateAmbient(level, state.mode);

    if (state.mode === "recharging" && state.recharge) {
      state.recharge.elapsed += dt;
      const progress = Math.min(1, state.recharge.elapsed / state.recharge.duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      state.fuel = state.recharge.from + (state.recharge.target - state.recharge.from) * eased;
      updateWeapon(dt);
      updateCamera(dt);
      updateRouteProgress();
      if (progress >= 1) {
        const checkpoint = state.recharge.checkpoint;
        state.fuel = state.recharge.target;
        state.recharge = null;
        state.mode = "ready";
        state.started = Boolean(checkpoint);
        state.launchGrace = .55;
        if (checkpoint) {
          state.checkpoint = { ...state.checkpoint, fuel: state.fuel, elapsed: state.elapsed, cells: [...state.collectedCells] };
          state.atmosphericHeat = 0;
          state.thermalMarks = new Set();
          state.message = `${checkpoint.id} READY · ${checkpoint.phase || `RUTA ${checkpoint.ascent}%`} · TIME ${formatTime(state.elapsed)} · SCORE ${String(Math.floor(state.score)).padStart(6, "0")}`;
          saveCampaign({ silent: false });
        } else {
          state.elapsed = 0;
          state.message = state.settings.controlMode === "arcade" ? "FUEL RESTORED. Usa WASD o flechas para despegar." : "FUEL RESTORED. Mantén clic izquierdo para despegar.";
        }
      }
      return;
    }

    if (state.mode !== "playing") {
      updateWeapon(dt);
      updateCamera(dt);
      updateRouteProgress();
      return;
    }

    state.elapsed += dt;
    state.campaignTime += dt;
    state.launchGrace = Math.max(0, state.launchGrace - dt);

    if (state.settings.controlMode === "arcade") {
      let dx = 0, dy = 0;
      if (state.arcadeKeys.has("left")) dx -= 1;
      if (state.arcadeKeys.has("right")) dx += 1;
      if (state.arcadeKeys.has("up")) dy -= 1;
      if (state.arcadeKeys.has("down")) dy += 1;
      if (dx || dy) ship.targetAngle = Math.atan2(dy, dx);
    } else {
      const world = worldBounds(level);
      state.pointer.x = clamp(state.camera.x + state.pointer.screenX, 0, world.w);
      state.pointer.y = clamp(state.camera.y + state.pointer.screenY, 0, world.h);
      ship.targetAngle = Math.atan2(state.pointer.y - ship.y, state.pointer.x - ship.x);
    }
    ship.angle = lerpAngle(ship.angle, ship.targetAngle, Math.min(1, dt * 11));
    updateWeapon(dt);

    ship.vy += currentGravity(level) * dt;
    for (const zone of level.zones) {
      if (ship.x >= zone.x && ship.x <= zone.x + zone.w && ship.y >= zone.y && ship.y <= zone.y + zone.h) {
        ship.vx += zone.fx * dt;
        ship.vy += zone.fy * dt;
      }
    }

    applyAnomalies(dt, level);
    updateFinalMissionSystems(dt, level);
    if (state.mode !== "playing") return;

    state.meteors.forEach(meteor => {
      if (meteor.destroyed) return;
      const position = meteorPosition(meteor);
      meteor.currentX = position.x;
      meteor.currentY = position.y;
      meteor.rotation += dt * (.35 + (meteor.speed || .55) * .18);
    });
    updateRockfalls(dt, level);
    updateThreatSystems(dt, level);
    if (state.mode !== "playing") return;

    if (state.thrusting && state.fuel > 0) {
      const thrustPower = currentThrust(level);
      ship.vx += Math.cos(ship.angle) * thrustPower * dt;
      ship.vy += Math.sin(ship.angle) * thrustPower * dt;
      state.fuel = Math.max(0, state.fuel - currentFuelBurn(level) * dt);
      state.particleClock -= dt;
      while (state.particleClock <= 0) {
        spawnThrustParticle();
        state.particleClock += .016;
      }
      if (state.fuel <= 0) {
        setThrust(false);
        state.message = "Combustible agotado. Conserva la inercia y busca el muelle.";
      }
    } else {
      state.particleClock = 0;
    }

    const drag = Math.pow(.9991, dt * 60);
    ship.vx *= drag;
    ship.vy *= drag;
    const maxSpeed = 580;
    const speed = Math.hypot(ship.vx, ship.vy);
    if (speed > maxSpeed) {
      ship.vx = ship.vx / speed * maxSpeed;
      ship.vy = ship.vy / speed * maxSpeed;
    }

    ship.x += ship.vx * dt;
    ship.y += ship.vy * dt;
    updateCamera(dt);
    updateRouteProgress();

    level.cells.forEach((cell, index) => {
      if (state.collectedCells.has(index)) return;
      if (Math.hypot(ship.x - cell.x, ship.y - cell.y) <= 29) {
        state.collectedCells.add(index);
        const cellFuel = Math.max(6, Number(level.cellFuel) || 8);
        state.fuel = Math.min(100, state.fuel + cellFuel);
        state.message = `Celda ${state.collectedCells.size}/${level.cells.length} sincronizada. +${cellFuel}% combustible.`;
        audio.cell();
        for (let i = 0; i < 14; i += 1) {
          const a = Math.random() * TAU;
          state.particles.push({ x: cell.x, y: cell.y, vx: Math.cos(a) * (35 + Math.random() * 90), vy: Math.sin(a) * (35 + Math.random() * 90), life: .3 + Math.random() * .35, maxLife: .65, size: 1.5 + Math.random() * 3, type: "cell" });
        }
      }
    });

    updateParticles(dt);
    detectProjectileCollisions();
    detectCollisions();
  }

  function circleIntersectsRect(cx, cy, radius, rect) {
    const nearestX = Math.max(rect.x, Math.min(cx, rect.x + rect.w));
    const nearestY = Math.max(rect.y, Math.min(cy, rect.y + rect.h));
    return (cx - nearestX) ** 2 + (cy - nearestY) ** 2 <= radius ** 2;
  }

  function spawnMeteorBurst(meteor, destroyed) {
    const count = destroyed ? 26 : 8;
    for (let index = 0; index < count; index += 1) {
      const angle = Math.random() * TAU;
      const speed = 35 + Math.random() * (destroyed ? 210 : 95);
      state.particles.push({
        x: meteor.currentX,
        y: meteor.currentY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: .28 + Math.random() * (destroyed ? .7 : .25),
        maxLife: destroyed ? 1 : .55,
        size: 1.5 + Math.random() * (destroyed ? 5 : 2.4),
        type: destroyed ? "rock" : "spark"
      });
    }
  }

  function detectProjectileCollisions() {
    const level = currentLevel();
    for (let projectileIndex = state.projectiles.length - 1; projectileIndex >= 0; projectileIndex -= 1) {
      const projectile = state.projectiles[projectileIndex]; let consumed = false;
      for (let enemyIndex = state.enemyProjectiles.length - 1; enemyIndex >= 0 && !consumed; enemyIndex -= 1) {
        const enemy = state.enemyProjectiles[enemyIndex];
        if (Math.hypot(projectile.x - enemy.x, projectile.y - enemy.y) > projectile.radius + enemy.radius + 2) continue;
        state.enemyProjectiles.splice(enemyIndex, 1); consumed = true; state.message = "Proyectil enemigo interceptado."; spawnThreatBurstAt(enemy.x, enemy.y, "spark", 8);
      }
      if (!consumed) for (const door of state.destructibleDoors) {
        if (door.destroyed || !circleIntersectsRect(projectile.x, projectile.y, projectile.radius, door)) continue;
        consumed = true; door.hpLeft -= 1; door.flash = 1; audio.meteorHit(); spawnThreatBurstAt(projectile.x, projectile.y, "spark", 8);
        if (door.hpLeft <= 0) { door.destroyed = true; audio.structureBreak?.(); spawnThreatBurstAt(door.x + door.w / 2, door.y + door.h / 2, "debris", 32); awardThreat(door.id, door.score, `Compuerta ${door.id} destruida.`); }
        else state.message = `Compuerta ${door.id}: integridad ${Math.max(0, door.hpLeft)}/${door.hp}.`;
        break;
      }
      if (!consumed) for (const turret of state.turrets) {
        if (turret.destroyed || Math.hypot(projectile.x - turret.x, projectile.y - turret.y) > projectile.radius + 23) continue;
        consumed = true; turret.hpLeft -= 1; turret.flash = 1; audio.meteorHit(); spawnThreatBurstAt(projectile.x, projectile.y, "spark", 9);
        if (turret.hpLeft <= 0) { turret.destroyed = true; audio.structureBreak?.(); spawnThreatBurstAt(turret.x, turret.y, "explosion", 30); awardThreat(turret.id, turret.score, `Defensa ${turret.id} neutralizada.`); }
        break;
      }
      if (!consumed) for (const mine of state.mines) {
        if (mine.destroyed || Math.hypot(projectile.x - mine.x, projectile.y - mine.y) > projectile.radius + 17) continue;
        consumed = true; mine.destroyed = true; spawnThreatBurstAt(mine.x, mine.y, "explosion", 25); audio.mineExplosion?.(); awardThreat(mine.id, mine.score, `Mina ${mine.id} desactivada.`); break;
      }
      if (!consumed) for (const rock of state.fallingRocks) {
        if (Math.hypot(projectile.x - rock.x, projectile.y - rock.y) > rock.r + projectile.radius) continue;
        consumed = true; audio.meteorHit(); rock.hpLeft -= 1; spawnMeteorBurst({ currentX: rock.x, currentY: rock.y }, rock.hpLeft <= 0);
        if (rock.hpLeft <= 0) { rock.life = 0; audio.meteorBreak(); awardThreat(rock.id, rock.score, `Fragmento ${rock.id} destruido.`); } break;
      }
      if (!consumed) for (const meteor of state.meteors) {
        if (meteor.destroyed || Math.hypot(projectile.x - meteor.currentX, projectile.y - meteor.currentY) > meteor.r + projectile.radius) continue;
        consumed = true; audio.meteorHit();
        if (meteor.destructible) { meteor.hpLeft -= 1; spawnMeteorBurst(meteor, meteor.hpLeft <= 0); if (meteor.hpLeft <= 0) { meteor.destroyed = true; audio.meteorBreak(); awardThreat(meteor.id, meteor.score, `Meteorito ${meteor.id} destruido.`); } }
        else { spawnMeteorBurst(meteor, false); state.message = "Fragmento masivo: el cañón no puede destruirlo."; } break;
      }
      if (!consumed) {
        const staticHit = (level.walls || []).some(wall => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, wall));
        const movingHit = (level.movingWalls || []).some(wall => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, movingRect(wall)));
        const platformHit = (level.orbitalPlatforms || []).some(platform => circleIntersectsRect(projectile.x, projectile.y, projectile.radius, orbitalPlatformRect(platform)));
        if (staticHit || movingHit || platformHit) consumed = true;
      }
      if (consumed) state.projectiles.splice(projectileIndex, 1);
    }
    state.fallingRocks = state.fallingRocks.filter(rock => rock.life > 0);
  }

  function detectCollisions() {
    if (state.mode !== "playing") return;
    const polygon = shipPolygon();
    const level = currentLevel();
    const world = worldBounds(level);
    if (polygon.some(point => point.x < 0 || point.x > world.w || point.y < 0 || point.y > world.h)) {
      crash("La nave ha salido del área de navegación.");
      return;
    }


    for (const wall of level.walls) {
      if (polygonsIntersect(polygon, rectPolygon(wall))) {
        crash("Impacto contra una pared.");
        return;
      }
    }

    for (const wall of level.movingWalls) {
      if (polygonsIntersect(polygon, rectPolygon(movingRect(wall)))) {
        crash("La compuerta móvil ha alcanzado la nave.");
        return;
      }
    }

    for (const strip of level.spikes) {
      for (const spike of spikePolygons(strip)) {
        if (polygonsIntersect(polygon, spike)) {
          crash("Impacto contra los pinchos.");
          return;
        }
      }
    }

    for (const anomaly of level.anomalies || []) {
      if (Math.hypot(ship.x - anomaly.x, ship.y - anomaly.y) <= anomaly.core + 14) {
        crash(anomaly.type === "repel" ? "Impacto contra un emisor de repulsión." : "La nave ha colisionado con un núcleo gravitatorio.");
        return;
      }
    }

    for (const door of state.destructibleDoors) {
      if (!door.destroyed && polygonsIntersect(polygon, rectPolygon(door))) { crash(`Impacto contra la compuerta ${door.id}.`); return; }
    }
    for (const turret of state.turrets) {
      if (!turret.destroyed && Math.hypot(ship.x - turret.x, ship.y - turret.y) <= 36) { crash(`Colisión con la defensa orbital ${turret.id}.`); return; }
    }
    for (const mine of state.mines) {
      if (!mine.destroyed && Math.hypot(ship.x - mine.x, ship.y - mine.y) <= 30) { crash(`Contacto directo con la mina ${mine.id}.`); return; }
    }
    for (const platform of level.orbitalPlatforms || []) {
      if (polygonsIntersect(polygon, rectPolygon(orbitalPlatformRect(platform)))) { crash(`Impacto contra la plataforma orbital ${platform.id}.`); return; }
    }

    for (const rock of state.fallingRocks) {
      const hit = polygon.some(point => Math.hypot(point.x - rock.x, point.y - rock.y) <= rock.r) || Math.hypot(ship.x - rock.x, ship.y - rock.y) <= rock.r + 13;
      if (hit) {
        crash("Impacto contra un desprendimiento de la cantera.");
        return;
      }
    }

    for (const meteor of state.meteors) {
      if (meteor.destroyed) continue;
      const points = polygon;
      const hit = points.some(point => Math.hypot(point.x - meteor.currentX, point.y - meteor.currentY) <= meteor.r) || Math.hypot(ship.x - meteor.currentX, ship.y - meteor.currentY) <= meteor.r + 13;
      if (hit) {
        crash(meteor.destructible ? "Impacto contra un meteorito." : "Impacto contra un fragmento masivo.");
        return;
      }
    }

    const startCollision = polygonsIntersect(polygon, rectPolygon(level.start));
    if (startCollision && state.launchGrace <= 0) {
      handlePlatformContact(level.start, "start", polygon);
      if (state.mode !== "playing") return;
    }

    for (const checkpoint of level.checkpoints || []) {
      if (state.launchGrace <= 0 && polygonsIntersect(polygon, rectPolygon(checkpoint))) {
        handlePlatformContact(checkpoint, "checkpoint", polygon);
        if (state.mode !== "playing") return;
      }
    }

    if (polygonsIntersect(polygon, rectPolygon(level.goal))) {
      handlePlatformContact(level.goal, "goal", polygon);
    }
  }

  function handlePlatformContact(platform, type, polygon) {
    const bottom = Math.max(...polygon.map(point => point.y));
    const nearTop = ship.y < platform.y && bottom <= platform.y + 21;
    const angle = angleDifference(ship.angle, -Math.PI / 2);
    const speed = Math.hypot(ship.vx, ship.vy);
    const upright = angle <= (Number(currentLevel().landingAngle) || .52);
    const verticalSafe = ship.vy >= -28 && ship.vy <= 96;
    const horizontalSafe = Math.abs(ship.vx) <= 82;
    const speedSafe = speed <= (Number(currentLevel().landingSpeed) || 122);

    if (nearTop && upright && verticalSafe && horizontalSafe && speedSafe) {
      ship.y = platform.y - 15;
      ship.vx = 0;
      ship.vy = 0;
      ship.angle = -Math.PI / 2;
      setThrust(false);
      if (type === "goal") finishLevel({ speed, angle });
      else if (type === "checkpoint") activateCheckpoint(platform, { speed, angle });
      else startFuelRecharge();
      return;
    }

    if (!nearTop) crash("Impacto contra el lateral o la parte inferior del muelle.");
    else if (!upright) crash("La nave no estaba alineada con el vector de atraque.");
    else if (!verticalSafe || !horizontalSafe || !speedSafe) crash("La velocidad de atraque era demasiado alta.");
  }

  function spawnThrustParticle() {
    const backward = { x: -Math.cos(ship.angle), y: -Math.sin(ship.angle) };
    const perpendicular = { x: -backward.y, y: backward.x };
    const spread = (Math.random() - .5) * 12;
    state.particles.push({
      x: ship.x + backward.x * 17 + perpendicular.x * spread * .25,
      y: ship.y + backward.y * 17 + perpendicular.y * spread * .25,
      vx: backward.x * (170 + Math.random() * 120) + perpendicular.x * spread,
      vy: backward.y * (170 + Math.random() * 120) + perpendicular.y * spread,
      life: .28 + Math.random() * .22,
      maxLife: .5,
      size: 2 + Math.random() * 4,
      type: "thrust"
    });
  }

  function spawnExplosion() {
    for (let index = 0; index < 48; index += 1) {
      const angle = Math.random() * TAU;
      const speed = 80 + Math.random() * 330;
      state.particles.push({
        x: ship.x,
        y: ship.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: .55 + Math.random() * .75,
        maxLife: 1.3,
        size: 2 + Math.random() * 7,
        type: index % 3 === 0 ? "debris" : "explosion"
      });
    }
  }

  function updateParticles(dt) {
    for (let index = state.particles.length - 1; index >= 0; index -= 1) {
      const particle = state.particles[index];
      particle.life -= dt;
      if (particle.life <= 0) {
        state.particles.splice(index, 1);
        continue;
      }
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(.985, dt * 60);
      particle.vy *= Math.pow(.985, dt * 60);
      if (particle.type !== "thrust" && particle.type !== "spark") particle.vy += 90 * dt;
    }
  }

  function drawBackground() {
    const gradient = ctx.createRadialGradient(W * .58, H * .42, 30, W * .58, H * .42, W * .78);
    gradient.addColorStop(0, "#0b1513");
    gradient.addColorStop(.42, "#060a0a");
    gradient.addColorStop(1, "#010303");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, W, H);

    const backdropLevel = currentLevel();
    if (backdropLevel?.earthBackdrop) {
      const progress = clamp(state.routeProgress, 0, 1);
      const radius = 96 + progress * 188;
      const earthX = W * .83 - state.camera.x * .012;
      const earthY = H * .46 - state.camera.y * .008;
      ctx.save(); ctx.shadowColor = "rgba(111,177,214,.42)"; ctx.shadowBlur = 42 + progress * 36;
      const atmosphere = ctx.createRadialGradient(earthX - radius * .24, earthY - radius * .3, radius * .08, earthX, earthY, radius);
      atmosphere.addColorStop(0, "#dce9ec"); atmosphere.addColorStop(.18, "#729db4"); atmosphere.addColorStop(.56, "#23495c"); atmosphere.addColorStop(.84, "#0d222d"); atmosphere.addColorStop(1, "#02080b");
      ctx.fillStyle = atmosphere; ctx.beginPath(); ctx.arc(earthX, earthY, radius, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
      ctx.globalAlpha = .34; ctx.fillStyle = "#78927a"; ctx.beginPath(); ctx.ellipse(earthX - radius * .22, earthY - radius * .08, radius * .34, radius * .18, -.4, 0, TAU); ctx.ellipse(earthX + radius * .18, earthY + radius * .2, radius * .26, radius * .12, .35, 0, TAU); ctx.fill();
      ctx.globalAlpha = .22; ctx.strokeStyle = "#f3f7f5"; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(earthX - radius * .08, earthY, radius * .72, -1.7, -.4); ctx.stroke(); ctx.restore();
    }

    if (backdropLevel?.earthLanding) {
      const descent = smoothStep(.62, 1, state.routeProgress);
      if (descent > .001) {
        ctx.save();
        const sky = ctx.createLinearGradient(0, 0, 0, H);
        sky.addColorStop(0, `rgba(15,31,45,${descent * .72})`);
        sky.addColorStop(.55, `rgba(45,83,99,${descent * .68})`);
        sky.addColorStop(1, `rgba(190,119,68,${descent * .62})`);
        ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
        const horizonY = H * (1.08 - descent * .26);
        ctx.fillStyle = `rgba(31,42,37,${descent * .94})`; ctx.fillRect(0, horizonY, W, H - horizonY);
        ctx.fillStyle = `rgba(110,133,102,${descent * .34})`; ctx.fillRect(0, horizonY, W, 7);
        ctx.restore();
      }
    }

    ctx.save();
    ctx.strokeStyle = "rgba(157,255,197,.026)";
    ctx.lineWidth = 1;
    const gridX = -((state.camera.x * .16) % 50);
    const gridY = -((state.camera.y * .16) % 50);
    for (let x = gridX - 50; x <= W + 50; x += 50) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = gridY - 50; y <= H + 50; y += 50) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    ctx.restore();

    stars.forEach((star, index) => {
      const pulse = .68 + Math.sin(state.worldTime * .65 + index) * .2;
      const spanX = W + 160;
      const spanY = H + 160;
      const sx = ((star.x - state.camera.x * star.depth) % spanX + spanX) % spanX - 80;
      const sy = ((star.y - state.camera.y * star.depth) % spanY + spanY) % spanY - 80;
      ctx.fillStyle = `rgba(220,239,232,${star.a * pulse})`;
      ctx.fillRect(sx, sy, star.r, star.r);
    });

    ctx.save();
    ctx.globalAlpha = .09;
    ctx.strokeStyle = "#4ee889";
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 15]);
    const orbitX = W * .72 - state.camera.x * .035;
    const orbitY = H * .36 - state.camera.y * .025;
    ctx.beginPath(); ctx.arc(orbitX, orbitY, 178, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(orbitX, orbitY, 244, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  function roundedRectPath(x, y, w, h, r = 5) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  function drawWall(rect, moving = false) {
    ctx.save();
    if (moving && rect.style === "platform") {
      const deck = ctx.createLinearGradient(rect.x, rect.y, rect.x, rect.y + rect.h + 18); deck.addColorStop(0, "#b7c2c4"); deck.addColorStop(.22, "#596467"); deck.addColorStop(.58, "#242b2e"); deck.addColorStop(1, "#090d0e");
      ctx.fillStyle = deck; ctx.fillRect(rect.x, rect.y, rect.w, Math.max(14, rect.h)); ctx.strokeStyle = "rgba(218,238,233,.72)"; ctx.lineWidth = 1.5; ctx.strokeRect(rect.x + .5, rect.y + .5, rect.w - 1, Math.max(14, rect.h) - 1);
      ctx.fillStyle = "rgba(83,230,141,.72)"; for (let x = rect.x + 8; x < rect.x + rect.w - 8; x += 28) ctx.fillRect(x, rect.y - 3, 16, 3);
      ctx.fillStyle = "rgba(211,234,226,.5)"; ctx.font = "700 8px Cascadia Mono, monospace"; ctx.fillText(rect.id || "ORBITAL PLATFORM", rect.x + 8, rect.y + Math.max(14, rect.h) + 12); ctx.restore(); return;
    }
    if (moving) {
      const gradient = ctx.createLinearGradient(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
      gradient.addColorStop(0, "#3a4143");
      gradient.addColorStop(.28, "#202629");
      gradient.addColorStop(1, "#080b0c");
      ctx.fillStyle = gradient;
      ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
      ctx.strokeStyle = "rgba(255,175,60,.9)";
      ctx.lineWidth = 3;
      ctx.strokeRect(rect.x + 1, rect.y + 1, rect.w - 2, rect.h - 2);
      ctx.fillStyle = "rgba(240,162,41,.72)";
      const bandY = rect.y + rect.h / 2 - 8;
      for (let x = rect.x + 5; x < rect.x + rect.w - 5; x += 20) {
        ctx.beginPath(); ctx.moveTo(x, bandY + 16); ctx.lineTo(x + 10, bandY); ctx.lineTo(x + 18, bandY); ctx.lineTo(x + 8, bandY + 16); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
      return;
    }

    if (rect.material === "metal") {
      const metal = ctx.createLinearGradient(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h); metal.addColorStop(0, "#677174"); metal.addColorStop(.18, "#30383b"); metal.addColorStop(.55, "#171c1e"); metal.addColorStop(1, "#070a0b");
      ctx.fillStyle = metal; ctx.fillRect(rect.x, rect.y, rect.w, rect.h); ctx.strokeStyle = "rgba(198,215,213,.52)"; ctx.lineWidth = 1.4; ctx.strokeRect(rect.x + 1, rect.y + 1, rect.w - 2, rect.h - 2);
      ctx.strokeStyle = "rgba(84,105,104,.42)"; for (let x = rect.x + 34; x < rect.x + rect.w; x += 74) { ctx.beginPath(); ctx.moveTo(x, rect.y); ctx.lineTo(x, rect.y + rect.h); ctx.stroke(); }
      for (let y = rect.y + 34; y < rect.y + rect.h; y += 74) { ctx.beginPath(); ctx.moveTo(rect.x, y); ctx.lineTo(rect.x + rect.w, y); ctx.stroke(); }
      ctx.fillStyle = "rgba(83,230,141,.22)"; for (let x = rect.x + 12; x < rect.x + rect.w - 8; x += 92) ctx.fillRect(x, rect.y + 8, 24, 3); ctx.restore(); return;
    }

    const rock = ctx.createLinearGradient(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
    rock.addColorStop(0, "#76533c");
    rock.addColorStop(.28, "#4e3427");
    rock.addColorStop(.66, "#2b1d18");
    rock.addColorStop(1, "#130e0c");
    ctx.fillStyle = rock;
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
    ctx.strokeStyle = "rgba(173,126,88,.68)";
    ctx.lineWidth = 2;
    ctx.strokeRect(rect.x + 1, rect.y + 1, rect.w - 2, rect.h - 2);

    const seed = Math.floor(rect.x * 3 + rect.y * 5 + rect.w * 7 + rect.h * 11);
    for (let index = 0; index < Math.max(5, Math.floor((rect.w + rect.h) / 70)); index += 1) {
      const px = rect.x + 10 + ((seed + index * 67) % Math.max(12, rect.w - 20));
      const py = rect.y + 10 + ((seed * 2 + index * 43) % Math.max(12, rect.h - 20));
      const length = 12 + ((seed + index * 19) % 32);
      ctx.strokeStyle = index % 2 ? "rgba(12,7,5,.52)" : "rgba(190,139,98,.16)";
      ctx.lineWidth = 1 + (index % 3) * .35;
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px + length * .48, py + length * .22);
      ctx.lineTo(px + length, py - length * .14);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(255,211,164,.06)";
    for (let y = rect.y + 18; y < rect.y + rect.h; y += 46) {
      for (let x = rect.x + 18; x < rect.x + rect.w; x += 58) {
        const size = 2 + ((x + y + seed) % 4);
        ctx.fillRect(x, y, size, size);
      }
    }
    ctx.restore();
  }

  function drawPlatform(platform, type) {
    const isStart = type === "start";
    const isCheckpoint = type === "checkpoint";
    const checkpointActive = isCheckpoint && state.checkpoint?.id === platform.id;
    const accent = isStart ? "#55e58d" : isCheckpoint ? (checkpointActive ? "#83f5c1" : "#76d9cf") : "#ef5a61";
    const pulse = .7 + Math.sin(state.worldTime * 3.2 + (isStart ? 0 : isCheckpoint ? .7 : 1.4)) * .22;
    ctx.save();
    ctx.shadowColor = isStart ? `rgba(72,224,133,${.26 * pulse})` : isCheckpoint ? `rgba(91,224,205,${.3 * pulse})` : `rgba(239,90,97,${.28 * pulse})`;
    ctx.shadowBlur = 24;
    const deck = ctx.createLinearGradient(platform.x, platform.y, platform.x, platform.y + platform.h + 22);
    deck.addColorStop(0, "#a7b2b4");
    deck.addColorStop(.2, "#546064");
    deck.addColorStop(.48, "#252d30");
    deck.addColorStop(1, "#0c1112");
    ctx.fillStyle = deck;
    ctx.fillRect(platform.x, platform.y, platform.w, platform.h + 12);
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(223,236,236,.72)";
    ctx.lineWidth = 1.4;
    ctx.strokeRect(platform.x, platform.y, platform.w, platform.h + 12);

    ctx.fillStyle = accent;
    const lightW = Math.max(10, platform.w / 12);
    for (let x = platform.x + 6; x < platform.x + platform.w - 6; x += lightW + 6) {
      ctx.globalAlpha = .55 + pulse * .35;
      ctx.fillRect(x, platform.y - 4, Math.min(lightW, platform.x + platform.w - 6 - x), 4);
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = isStart ? "rgba(85,229,141,.12)" : isCheckpoint ? "rgba(91,224,205,.13)" : "rgba(239,90,97,.12)";
    ctx.fillRect(platform.x + 8, platform.y + 4, platform.w - 16, 4);

    ctx.strokeStyle = isStart ? "rgba(85,229,141,.42)" : isCheckpoint ? "rgba(91,224,205,.5)" : "rgba(239,90,97,.46)";
    ctx.setLineDash([6, 7]);
    ctx.strokeRect(platform.x - 7, platform.y - 8, platform.w + 14, platform.h + 28);
    ctx.setLineDash([]);

    ctx.fillStyle = accent;
    ctx.font = "700 12px Cascadia Mono, monospace";
    ctx.fillText(isStart ? "DOCK L / SALIDA" : isCheckpoint ? `${platform.id} / CHECKPOINT` : "DOCK T / DESTINO", platform.x, platform.y - 16);
    ctx.fillStyle = "rgba(216,234,228,.42)";
    ctx.font = "700 9px Cascadia Mono, monospace";
    ctx.fillText(isStart ? "REFUEL ENABLED" : isCheckpoint ? `ASCENT ${platform.ascent || 61}% · REFUEL · SAVE` : "ALIGN · BRAKE · LAND", platform.x, platform.y + platform.h + 28);
    ctx.restore();
  }

  function drawSpikes(strip) {
    ctx.save();
    spikePolygons(strip).forEach((polygon, index) => {
      const g = ctx.createLinearGradient(polygon[0].x, polygon[0].y, polygon[2].x, polygon[2].y);
      g.addColorStop(0, "#a87956");
      g.addColorStop(.45, "#5a3a2a");
      g.addColorStop(1, "#1d1210");
      ctx.fillStyle = g;
      ctx.strokeStyle = index % 2 ? "rgba(221,91,58,.84)" : "rgba(173,126,88,.72)";
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(polygon[0].x, polygon[0].y);
      polygon.slice(1).forEach(point => ctx.lineTo(point.x, point.y));
      ctx.closePath(); ctx.fill(); ctx.stroke();
    });
    ctx.restore();
  }

  function drawZone(zone) {
    ctx.save();
    const pulse = .3 + Math.sin(state.worldTime * 2.1 + zone.x) * .08;
    ctx.fillStyle = `rgba(60,205,136,${pulse * .18})`;
    ctx.fillRect(zone.x, zone.y, zone.w, zone.h);
    ctx.strokeStyle = `rgba(86,235,157,${.35 + pulse})`;
    ctx.lineWidth = 1;
    ctx.setLineDash([7, 9]);
    ctx.strokeRect(zone.x, zone.y, zone.w, zone.h);
    ctx.setLineDash([]);
    const mag = Math.hypot(zone.fx, zone.fy) || 1;
    const ux = zone.fx / mag, uy = zone.fy / mag;
    ctx.strokeStyle = "rgba(118,255,185,.38)";
    for (let y = zone.y + 24; y < zone.y + zone.h; y += 38) {
      for (let x = zone.x + 22; x < zone.x + zone.w; x += 46) {
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + ux * 20, y + uy * 20); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x + ux*20, y + uy*20); ctx.lineTo(x + ux*14 - uy*4, y + uy*14 + ux*4); ctx.lineTo(x + ux*14 + uy*4, y + uy*14 - ux*4); ctx.closePath(); ctx.fillStyle="rgba(118,255,185,.38)"; ctx.fill();
      }
    }
    ctx.fillStyle = "rgba(153,255,201,.55)";
    ctx.font = "700 9px Cascadia Mono, monospace";
    ctx.fillText(zone.label, zone.x + 10, zone.y + 15);
    ctx.restore();
  }

  function drawAnomaly(anomaly) {
    const pulse = .5 + Math.sin(state.worldTime * 2.2 + anomaly.x * .01) * .18;
    const attract = anomaly.type !== "repel";
    ctx.save();
    const gradient = ctx.createRadialGradient(anomaly.x, anomaly.y, anomaly.core * .25, anomaly.x, anomaly.y, anomaly.radius);
    gradient.addColorStop(0, attract ? `rgba(91,224,188,${.28 + pulse * .18})` : `rgba(236,113,83,${.3 + pulse * .18})`);
    gradient.addColorStop(.18, attract ? "rgba(38,118,101,.17)" : "rgba(145,51,43,.17)");
    gradient.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = gradient;
    ctx.beginPath(); ctx.arc(anomaly.x, anomaly.y, anomaly.radius, 0, TAU); ctx.fill();
    ctx.strokeStyle = attract ? "rgba(92,235,192,.32)" : "rgba(255,120,88,.34)";
    ctx.setLineDash([7, 12]);
    for (let ring = .36; ring <= 1; ring += .22) {
      ctx.beginPath(); ctx.arc(anomaly.x, anomaly.y, anomaly.radius * ring, state.worldTime * (attract ? .18 : -.18), TAU + state.worldTime * (attract ? .18 : -.18)); ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.shadowColor = attract ? "rgba(83,238,188,.85)" : "rgba(255,100,72,.85)";
    ctx.shadowBlur = 22;
    ctx.fillStyle = attract ? "#5de8bd" : "#f16b51";
    ctx.beginPath(); ctx.arc(anomaly.x, anomaly.y, anomaly.core, 0, TAU); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#08110f";
    ctx.beginPath(); ctx.arc(anomaly.x, anomaly.y, anomaly.core * .48, 0, TAU); ctx.fill();
    ctx.fillStyle = attract ? "rgba(157,255,223,.82)" : "rgba(255,190,171,.82)";
    ctx.font = "700 10px Cascadia Mono, monospace";
    ctx.fillText(`${anomaly.label} / ${attract ? "ATRACCIÓN" : "REPULSIÓN"}`, anomaly.x - anomaly.radius * .42, anomaly.y - anomaly.radius * .72);
    ctx.restore();
  }

  function drawSatellite(satellite) {
    ctx.save(); ctx.translate(satellite.x, satellite.y); ctx.rotate((satellite.rotation || 0) + Math.sin(state.worldTime * .13 + satellite.x) * .025); ctx.scale(satellite.scale || 1, satellite.scale || 1); ctx.globalAlpha = .7;
    ctx.fillStyle = "#242b2e"; ctx.strokeStyle = "rgba(184,205,202,.55)"; ctx.lineWidth = 2; ctx.fillRect(-56,-18,112,36); ctx.strokeRect(-56,-18,112,36);
    ctx.fillStyle = "#18262c"; ctx.strokeStyle = "rgba(82,139,155,.55)"; ctx.fillRect(-142,-34,78,68); ctx.strokeRect(-142,-34,78,68); ctx.fillRect(64,-34,78,68); ctx.strokeRect(64,-34,78,68);
    ctx.strokeStyle = "rgba(212,229,224,.42)"; ctx.beginPath(); ctx.moveTo(-64,0); ctx.lineTo(-142,0); ctx.moveTo(64,0); ctx.lineTo(142,0); ctx.stroke(); ctx.fillStyle = "rgba(239,90,97,.72)"; ctx.beginPath(); ctx.arc(0,0,6,0,TAU); ctx.fill(); ctx.restore();
  }
  function drawJammer(jammer) { const pulse=.22+Math.sin(state.worldTime*5+jammer.x*.01)*.07; ctx.save(); ctx.fillStyle=`rgba(197,65,91,${pulse*.16})`; ctx.fillRect(jammer.x,jammer.y,jammer.w,jammer.h); ctx.strokeStyle=`rgba(239,90,110,${.22+pulse})`; ctx.setLineDash([4,14]); ctx.strokeRect(jammer.x,jammer.y,jammer.w,jammer.h); ctx.setLineDash([]); ctx.fillStyle="rgba(255,122,140,.48)"; ctx.font="700 9px Cascadia Mono, monospace"; ctx.fillText(`${jammer.id} / NAV JAMMING`,jammer.x+12,jammer.y+18); ctx.restore(); }
  function drawDoor(door) { if(door.destroyed)return; const flash=door.flash||0; door.flash=Math.max(0,flash*.84); ctx.save(); const metal=ctx.createLinearGradient(door.x,door.y,door.x+door.w,door.y); metal.addColorStop(0,"#151a1c"); metal.addColorStop(.45,flash>.08?"#9b3d42":"#586164"); metal.addColorStop(1,"#090c0d"); ctx.fillStyle=metal; ctx.fillRect(door.x,door.y,door.w,door.h); ctx.strokeStyle=flash>.08?"rgba(255,101,106,.95)":"rgba(211,226,222,.56)"; ctx.lineWidth=2; ctx.strokeRect(door.x+1,door.y+1,door.w-2,door.h-2); ctx.fillStyle="rgba(239,71,78,.66)"; for(let y=door.y+10;y<door.y+door.h-8;y+=34)ctx.fillRect(door.x+7,y,door.w-14,5); const ratio=Math.max(0,door.hpLeft/door.hp); ctx.fillStyle="rgba(0,0,0,.72)";ctx.fillRect(door.x-7,door.y-14,door.w+14,5);ctx.fillStyle=ratio>.45?"#e8a758":"#ef4a4a";ctx.fillRect(door.x-7,door.y-14,(door.w+14)*ratio,5);ctx.fillStyle="rgba(241,223,216,.58)";ctx.font="700 9px Cascadia Mono, monospace";ctx.fillText(`${door.id} / ${door.hpLeft}`,door.x-3,door.y-20);ctx.restore(); }
  function drawTurret(turret){if(turret.destroyed)return;ctx.save();ctx.translate(turret.x,turret.y);const flash=turret.flash||0;ctx.shadowColor=flash>.05?"rgba(255,78,72,.95)":"rgba(239,90,97,.45)";ctx.shadowBlur=flash>.05?22:9;ctx.fillStyle="#252d30";ctx.strokeStyle="rgba(205,220,216,.62)";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,21,0,TAU);ctx.fill();ctx.stroke();ctx.rotate(turret.aim||0);ctx.fillStyle=flash>.05?"#ff695e":"#6a7375";ctx.fillRect(-2,-6,34,12);ctx.fillStyle="#0b0e0f";ctx.fillRect(24,-3,12,6);ctx.rotate(-(turret.aim||0));ctx.shadowBlur=0;ctx.fillStyle="#ef5059";ctx.beginPath();ctx.arc(0,0,5,0,TAU);ctx.fill();const ratio=Math.max(0,turret.hpLeft/turret.hp);ctx.fillStyle="rgba(0,0,0,.68)";ctx.fillRect(-24,29,48,4);ctx.fillStyle=ratio>.4?"#e7a85f":"#ef4a4a";ctx.fillRect(-24,29,48*ratio,4);ctx.restore();}
  function drawMine(mine){if(mine.destroyed)return;const armed=mine.armed,pulse=.55+Math.sin(mine.pulse||0)*.32;ctx.save();ctx.translate(mine.x,mine.y);ctx.rotate(state.worldTime*.22+mine.x*.001);ctx.shadowColor=armed?"rgba(255,63,62,.95)":"rgba(234,169,77,.72)";ctx.shadowBlur=armed?24:10;ctx.strokeStyle=armed?`rgba(255,74,70,${.65+pulse*.3})`:"rgba(224,178,101,.72)";ctx.fillStyle="#171b1d";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,16,0,TAU);ctx.fill();ctx.stroke();for(let i=0;i<8;i++){const a=i*TAU/8;ctx.beginPath();ctx.moveTo(Math.cos(a)*15,Math.sin(a)*15);ctx.lineTo(Math.cos(a)*25,Math.sin(a)*25);ctx.stroke();}ctx.fillStyle=armed?"#ff4545":"#d9a957";ctx.beginPath();ctx.arc(0,0,5+pulse*2,0,TAU);ctx.fill();ctx.restore();}

  function drawFallingRock(rock) {
    drawMeteor({ ...rock, currentX: rock.x, currentY: rock.y, hp: rock.hp, destructible: true, destroyed: false });
  }

  function drawRockfallWarnings(level) {
    state.rockfallControllers.forEach(controller => {
      const cfg = controller.config;
      if (!controller.triggered) {
        ctx.save();
        ctx.strokeStyle = "rgba(224,164,89,.18)";
        ctx.setLineDash([5, 13]);
        ctx.strokeRect(cfg.trigger.x, cfg.trigger.y, cfg.trigger.w, cfg.trigger.h);
        ctx.setLineDash([]);
        ctx.fillStyle = "rgba(225,173,105,.42)";
        ctx.font = "700 9px Cascadia Mono, monospace";
        ctx.fillText(`FRACTURA ${cfg.id}`, cfg.origin.x - 60, cfg.origin.y - 18);
        ctx.restore();
      }
    });
  }

  function drawCell(cell, index) {
    if (state.collectedCells.has(index)) return;
    const pulse = 1 + Math.sin(state.cellPulse * 4 + index * 1.7) * .12;
    ctx.save();
    ctx.translate(cell.x, cell.y);
    ctx.scale(pulse, pulse);
    ctx.rotate(state.worldTime * .65 + index);
    ctx.shadowColor = "rgba(74,245,143,.9)";
    ctx.shadowBlur = 20;
    ctx.strokeStyle = "#7dffb1";
    ctx.fillStyle = "rgba(43,136,86,.28)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 6; i += 1) {
      const a = -Math.PI/2 + i * TAU/6;
      const x = Math.cos(a)*13, y=Math.sin(a)*13;
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.rotate(-state.worldTime * 1.4);
    ctx.fillStyle = "#d9ffe8";
    ctx.beginPath();
    ctx.moveTo(0,-8); ctx.lineTo(7,0); ctx.lineTo(0,8); ctx.lineTo(-7,0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#2a9d61";
    ctx.beginPath(); ctx.arc(0,0,2.5,0,TAU); ctx.fill();
    ctx.restore();
  }

  function drawMeteor(meteor) {
    if (meteor.destroyed) return;
    ctx.save();
    ctx.translate(meteor.currentX, meteor.currentY);
    ctx.rotate(meteor.rotation);
    const gradient = ctx.createRadialGradient(-meteor.r * .3, -meteor.r * .35, 2, 0, 0, meteor.r * 1.15);
    gradient.addColorStop(0, meteor.destructible ? "#9d6d4b" : "#76523d");
    gradient.addColorStop(.42, "#513426");
    gradient.addColorStop(1, "#17100d");
    ctx.fillStyle = gradient;
    ctx.strokeStyle = meteor.destructible ? "rgba(203,148,101,.66)" : "rgba(136,98,75,.58)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    const vertices = 11;
    for (let index = 0; index < vertices; index += 1) {
      const angle = index * TAU / vertices;
      const variance = .78 + ((index * 37 + meteor.id.charCodeAt(0)) % 25) / 100;
      const radius = meteor.r * variance;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = "rgba(28,15,11,.62)";
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-meteor.r*.45,-meteor.r*.18); ctx.lineTo(-meteor.r*.05,meteor.r*.05); ctx.lineTo(meteor.r*.34,-meteor.r*.22); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(meteor.r*.18,meteor.r*.1); ctx.lineTo(-meteor.r*.08,meteor.r*.42); ctx.stroke();
    if (meteor.destructible) {
      const ratio = Math.max(0, meteor.hpLeft / meteor.hp);
      ctx.fillStyle = "rgba(0,0,0,.58)"; ctx.fillRect(-meteor.r, meteor.r + 7, meteor.r * 2, 3);
      ctx.fillStyle = ratio > .45 ? "#e7a85f" : "#ef4a4a"; ctx.fillRect(-meteor.r, meteor.r + 7, meteor.r * 2 * ratio, 3);
    }
    ctx.restore();
  }

  function drawProjectiles() {
    ctx.save();
    state.projectiles.forEach(projectile => { ctx.shadowColor="rgba(255,232,176,.95)";ctx.shadowBlur=10;ctx.fillStyle="#fff2bd";ctx.beginPath();ctx.arc(projectile.x,projectile.y,projectile.radius,0,TAU);ctx.fill();ctx.strokeStyle="rgba(235,82,52,.8)";ctx.beginPath();ctx.moveTo(projectile.x-projectile.vx*.018,projectile.y-projectile.vy*.018);ctx.lineTo(projectile.x,projectile.y);ctx.stroke(); });
    state.enemyProjectiles.forEach(projectile => { ctx.shadowColor="rgba(255,62,66,.95)";ctx.shadowBlur=14;ctx.fillStyle="#ff5258";ctx.beginPath();ctx.arc(projectile.x,projectile.y,projectile.radius,0,TAU);ctx.fill();ctx.strokeStyle="rgba(255,155,118,.72)";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(projectile.x-projectile.vx*.04,projectile.y-projectile.vy*.04);ctx.lineTo(projectile.x,projectile.y);ctx.stroke(); });
    ctx.restore();
  }

  function drawLevel() {
    const level = currentLevel();
    (level.satellites || []).forEach(drawSatellite);
    (level.jammers || []).forEach(drawJammer);
    (level.anomalies || []).forEach(drawAnomaly);
    level.zones.forEach(drawZone);
    drawRockfallWarnings(level);
    level.walls.forEach(wall => drawWall(wall));
    level.movingWalls.forEach(wall => drawWall(movingRect(wall), true));
    (level.orbitalPlatforms || []).forEach(platform => drawWall(orbitalPlatformRect(platform), true));
    state.destructibleDoors.forEach(drawDoor);
    level.spikes.forEach(drawSpikes);
    drawPlatform(level.start, "start");
    (level.checkpoints || []).forEach(checkpoint => drawPlatform(checkpoint, "checkpoint"));
    drawPlatform(level.goal, "goal");
    level.cells.forEach(drawCell);
    state.meteors.forEach(drawMeteor);
    state.fallingRocks.forEach(drawFallingRock);
    state.turrets.forEach(drawTurret);
    state.mines.forEach(drawMine);

    ctx.save();
    const gx = level.goal.x + level.goal.w / 2;
    const top = Math.max(48, level.goal.y - 145);
    const pulse = .48 + Math.sin(state.worldTime * 3) * .18;
    ctx.strokeStyle = `rgba(239,90,97,${pulse})`;
    ctx.setLineDash([8, 10]);
    ctx.beginPath(); ctx.moveTo(gx, level.goal.y - 22); ctx.lineTo(gx, top); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(gx, top, 10, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  function drawPointerGuide() {
    if (state.settings.controlMode !== "classic" || state.mode === "intro" || state.mode === "crashed" || state.mode === "landed") return;
    ctx.save();
    ctx.strokeStyle = state.thrusting ? "rgba(92,242,151,.62)" : "rgba(212,231,225,.2)";
    ctx.lineWidth = 1.4;
    ctx.setLineDash([5, 10]);
    ctx.beginPath(); ctx.moveTo(ship.x, ship.y); ctx.lineTo(state.pointer.x, state.pointer.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.translate(state.pointer.x, state.pointer.y);
    ctx.rotate(state.worldTime * .22);
    ctx.strokeStyle = state.thrusting ? "#72f8a8" : "rgba(218,235,229,.68)";
    ctx.beginPath(); ctx.arc(0, 0, 13, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-23,0); ctx.lineTo(-9,0); ctx.moveTo(23,0); ctx.lineTo(9,0); ctx.moveTo(0,-23); ctx.lineTo(0,-9); ctx.moveTo(0,23); ctx.lineTo(0,9); ctx.stroke();
    ctx.restore();
  }

  function drawParticles() {
    state.particles.forEach(particle => {
      const alpha = Math.max(0, particle.life / particle.maxLife);
      if (particle.type === "thrust") ctx.fillStyle = `rgba(${Math.floor(120+90*alpha)},255,${Math.floor(180+60*alpha)},${alpha})`;
      else if (particle.type === "debris") ctx.fillStyle = `rgba(203,218,218,${alpha})`;
      else if (particle.type === "cell") ctx.fillStyle = `rgba(90,255,159,${alpha})`;
      else if (particle.type === "rock") ctx.fillStyle = `rgba(132,91,62,${alpha})`;
      else if (particle.type === "spark") ctx.fillStyle = `rgba(255,208,124,${alpha})`;
      else ctx.fillStyle = `rgba(255,${Math.floor(75 + 120 * alpha)},35,${alpha})`;
      ctx.fillRect(particle.x - particle.size / 2, particle.y - particle.size / 2, particle.size, particle.size);
    });
  }

  function drawShip() {
    if (state.mode === "crashed") return;
    const fx = Math.cos(ship.angle), fy = Math.sin(ship.angle);
    const px = -fy, py = fx;
    const nose = { x: ship.x + fx * 24, y: ship.y + fy * 24 };
    const rear = { x: ship.x - fx * 15, y: ship.y - fy * 15 };
    const left = { x: rear.x + px * 14, y: rear.y + py * 14 };
    const right = { x: rear.x - px * 14, y: rear.y - py * 14 };

    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,.8)"; ctx.shadowBlur = 18; ctx.shadowOffsetY = 9;
    const color = getShipColor();
    const hull = ctx.createLinearGradient(nose.x, nose.y, rear.x, rear.y);
    if (color.id === "rainbow") {
      hull.addColorStop(0, "#ff6f86"); hull.addColorStop(.22, "#ffd66f"); hull.addColorStop(.44, "#72f1a5"); hull.addColorStop(.66, "#64c9ff"); hull.addColorStop(.84, "#b982ff"); hull.addColorStop(1, "#ff76c8");
    } else {
      hull.addColorStop(0, color.light); hull.addColorStop(.30, color.base); hull.addColorStop(.76, color.dark); hull.addColorStop(1, "#151a1b");
    }
    ctx.fillStyle = hull; ctx.strokeStyle = color.id === "gold" ? "rgba(255,240,163,.95)" : "rgba(235,247,244,.92)"; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(nose.x,nose.y); ctx.lineTo(left.x,left.y); ctx.lineTo(ship.x-fx*5,ship.y-fy*5); ctx.lineTo(right.x,right.y); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.shadowBlur = 0;

    ctx.strokeStyle = "rgba(24,36,36,.72)"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(nose.x,nose.y); ctx.lineTo(ship.x-fx*6,ship.y-fy*6); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(left.x,left.y); ctx.lineTo(right.x,right.y); ctx.stroke();

    ctx.shadowColor = "rgba(78,240,143,.72)"; ctx.shadowBlur = 10;
    ctx.fillStyle = "#62e999";
    ctx.beginPath(); ctx.ellipse(ship.x+fx*5,ship.y+fy*5,5.5,9.5,ship.angle+Math.PI/2,0,TAU); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(221,255,235,.65)"; ctx.stroke();

    ctx.fillStyle = "#161c1e";
    ctx.beginPath(); ctx.moveTo(rear.x+px*9,rear.y+py*9); ctx.lineTo(rear.x-fx*5,rear.y-fy*5); ctx.lineTo(rear.x-px*9,rear.y-py*9); ctx.closePath(); ctx.fill();

    if (state.thrusting && state.fuel > 0) {
      const flameLength = 26 + Math.random() * 22;
      ctx.shadowColor = "rgba(86,255,164,.95)"; ctx.shadowBlur = 18;
      const flame = ctx.createLinearGradient(rear.x,rear.y,ship.x-fx*(18+flameLength),ship.y-fy*(18+flameLength));
      flame.addColorStop(0,"#ecfff4"); flame.addColorStop(.25,"#6effae"); flame.addColorStop(.7,"#22a96c"); flame.addColorStop(1,"rgba(34,169,108,0)");
      ctx.fillStyle=flame;
      ctx.beginPath(); ctx.moveTo(rear.x+px*5,rear.y+py*5); ctx.lineTo(ship.x-fx*(16+flameLength),ship.y-fy*(16+flameLength)); ctx.lineTo(rear.x-px*5,rear.y-py*5); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  function drawRadar() {
    const level = currentLevel();
    const world = worldBounds(level);
    const rw = 238;
    const rh = 126;
    const rx = W - rw - 24;
    const ry = H - rh - 22;
    const pad = 13;
    const mapX = rx + pad;
    const mapY = ry + 24;
    const mapW = rw - pad * 2;
    const mapH = rh - 36;
    const sx = mapW / world.w;
    const sy = mapH / world.h;

    ctx.save();
    ctx.fillStyle = "rgba(2,7,6,.82)";
    ctx.fillRect(rx, ry, rw, rh);
    ctx.strokeStyle = "rgba(116,226,166,.42)";
    ctx.lineWidth = 1;
    ctx.strokeRect(rx + .5, ry + .5, rw - 1, rh - 1);
    ctx.fillStyle = "rgba(182,232,207,.62)";
    ctx.font = "700 9px Cascadia Mono, monospace";
    ctx.fillText(`NAV/RADAR · ${Math.round(state.routeProgress * 100)}% RUTA`, rx + 12, ry + 16);

    ctx.save();
    ctx.beginPath();
    ctx.rect(mapX, mapY, mapW, mapH);
    ctx.clip();
    ctx.fillStyle = "rgba(95,67,50,.52)";
    level.walls.forEach(wall => ctx.fillRect(mapX + wall.x * sx, mapY + wall.y * sy, Math.max(1, wall.w * sx), Math.max(1, wall.h * sy)));
    ctx.fillStyle = "rgba(229,164,77,.58)";
    level.movingWalls.forEach(wall => {
      const rect = movingRect(wall);
      ctx.fillRect(mapX + rect.x * sx, mapY + rect.y * sy, Math.max(1, rect.w * sx), Math.max(1, rect.h * sy));
    });
    (level.orbitalPlatforms || []).forEach(platform => { const rect=orbitalPlatformRect(platform);ctx.fillStyle="rgba(104,211,174,.62)";ctx.fillRect(mapX+rect.x*sx,mapY+rect.y*sy,Math.max(2,rect.w*sx),Math.max(2,rect.h*sy)); });
    state.destructibleDoors.forEach(door => { if(door.destroyed)return;ctx.fillStyle="rgba(239,82,86,.8)";ctx.fillRect(mapX+door.x*sx,mapY+door.y*sy,Math.max(2,door.w*sx),Math.max(2,door.h*sy)); });
    ctx.fillStyle = "rgba(83,230,141,.8)";
    ctx.fillRect(mapX + level.start.x * sx, mapY + level.start.y * sy, Math.max(3, level.start.w * sx), 3);
    (level.checkpoints || []).forEach(checkpoint => {
      ctx.fillStyle = state.checkpoint?.id === checkpoint.id ? "rgba(126,255,201,.95)" : "rgba(91,224,205,.78)";
      ctx.fillRect(mapX + checkpoint.x * sx, mapY + checkpoint.y * sy, Math.max(3, checkpoint.w * sx), 3);
    });
    ctx.fillStyle = "rgba(239,90,97,.9)";
    ctx.fillRect(mapX + level.goal.x * sx, mapY + level.goal.y * sy, Math.max(3, level.goal.w * sx), 3);
    level.cells.forEach((cell, index) => {
      if (state.collectedCells.has(index)) return;
      ctx.fillStyle = "rgba(99,247,155,.72)";
      ctx.fillRect(mapX + cell.x * sx - 1, mapY + cell.y * sy - 1, 3, 3);
    });
    state.meteors.forEach(meteor => {
      if (meteor.destroyed) return;
      ctx.fillStyle = meteor.destructible ? "rgba(226,157,96,.8)" : "rgba(142,101,75,.72)";
      ctx.beginPath();
      ctx.arc(mapX + meteor.currentX * sx, mapY + meteor.currentY * sy, Math.max(1.5, meteor.r * Math.min(sx, sy)), 0, TAU);
      ctx.fill();
    });
    (level.anomalies || []).forEach(anomaly => {
      ctx.strokeStyle = anomaly.type === "repel" ? "rgba(241,105,78,.55)" : "rgba(84,230,184,.55)";
      ctx.beginPath();
      ctx.arc(mapX + anomaly.x * sx, mapY + anomaly.y * sy, Math.max(2, anomaly.radius * Math.min(sx, sy)), 0, TAU);
      ctx.stroke();
    });
    state.fallingRocks.forEach(rock => { ctx.fillStyle="rgba(236,177,112,.85)";ctx.fillRect(mapX+rock.x*sx-1,mapY+rock.y*sy-1,3,3); });
    state.turrets.forEach(turret => { if(turret.destroyed)return;ctx.fillStyle="rgba(255,91,91,.9)";ctx.fillRect(mapX+turret.x*sx-1.5,mapY+turret.y*sy-1.5,4,4); });
    state.mines.forEach(mine => { if(mine.destroyed)return;ctx.strokeStyle=mine.armed?"rgba(255,72,72,.95)":"rgba(225,174,91,.78)";ctx.beginPath();ctx.arc(mapX+mine.x*sx,mapY+mine.y*sy,2.4,0,TAU);ctx.stroke(); });
    state.enemyProjectiles.forEach(projectile => { ctx.fillStyle="rgba(255,77,82,.82)";ctx.fillRect(mapX+projectile.x*sx,mapY+projectile.y*sy,2,2); });
    ctx.strokeStyle = "rgba(219,238,230,.28)";
    ctx.strokeRect(mapX + state.camera.x * sx, mapY + state.camera.y * sy, W * sx, H * sy);
    ctx.fillStyle = "#f4fff8";
    ctx.beginPath();
    ctx.arc(mapX + ship.x * sx, mapY + ship.y * sy, 2.8, 0, TAU);
    ctx.fill();
    if (state.radarInterference > .08) {
      const strength=clamp(state.radarInterference,0,1);ctx.globalAlpha=.2+strength*.48;
      for(let line=0;line<14;line++){const gy=mapY+((line*17+Math.floor(state.worldTime*90))%Math.max(1,mapH));const shift=Math.sin(line*2.7+state.worldTime*17)*16*strength;ctx.fillStyle=line%3===0?"rgba(255,82,96,.42)":"rgba(206,242,224,.2)";ctx.fillRect(mapX+shift,gy,mapW,line%4===0?3:1);}
      ctx.globalAlpha=1;ctx.fillStyle="rgba(255,98,112,.9)";ctx.font="800 10px Cascadia Mono, monospace";ctx.fillText("NAV SIGNAL CORRUPTED",mapX+14,mapY+mapH/2);
    }
    ctx.restore();
    ctx.restore();
  }

  function drawCanvasHud() {
    const level = currentLevel();
    const speed = Math.hypot(ship.vx, ship.vy);
    const angle = angleDifference(ship.angle, -Math.PI / 2);
    const safeSpeed = speed <= (Number(level.landingSpeed) || 122);
    const safeAngle = angle <= (Number(level.landingAngle) || .52);

    ctx.save();
    ctx.font = "700 11px Cascadia Mono, monospace";
    ctx.fillStyle = "rgba(210,232,224,.52)";
    ctx.fillText(`JGS-005 // FASE ${String(level.id).padStart(2, "0")}`, 24, 30);
    ctx.textAlign = "right";
    ctx.fillText(`${state.mode.toUpperCase()} // FUEL ${Math.round(state.fuel)}%`, W - 24, 30);
    ctx.textAlign = "left";

    ctx.fillStyle = "rgba(255,255,255,.06)"; ctx.fillRect(24,44,148,5);
    ctx.fillStyle = state.fuel > 25 ? "#55e58d" : "#ef4a4a"; ctx.fillRect(24,44,148*state.fuel/100,5);
    ctx.fillStyle = "rgba(196,228,214,.62)"; ctx.font="700 9px Cascadia Mono, monospace";
    ctx.fillText(`CELDAS ${state.collectedCells.size}/${level.cells.length}`, 24,65);
    ctx.fillStyle = "rgba(255,255,255,.06)"; ctx.fillRect(W - 172,44,148,5);
    ctx.fillStyle = state.overheated || state.weaponHeat > 75 ? "#ef4a4a" : state.weaponHeat > 45 ? "#e7a85f" : "#d9eee6";
    ctx.fillRect(W - 172,44,148*state.weaponHeat/100,5);
    ctx.fillStyle = "rgba(196,228,214,.62)";
    ctx.textAlign = "right"; ctx.fillText(`CANNON ${Math.round(state.weaponHeat)}%`, W - 24,65); ctx.textAlign = "left";

    if (state.mode === "ready") {
      ctx.fillStyle = "rgba(217,238,230,.82)"; ctx.font = "700 14px Cascadia Mono, monospace";
      ctx.fillText(state.settings.controlMode === "arcade" ? "WASD / FLECHAS: IMPULSO · ESPACIO: FUEGO" : "CLICK IZQ: IMPULSO · CLICK DER/ESPACIO: FUEGO", 24, 88);
    }

    if (state.hazardNotice) {
      const blink = .55 + Math.sin(state.worldTime * 11) * .35;
      ctx.fillStyle = `rgba(239,113,70,${blink})`; ctx.font = "800 15px Cascadia Mono, monospace"; ctx.textAlign = "center"; ctx.fillText(`⚠ ${state.hazardNotice} / IMPACTO INMINENTE`, W / 2, 96); ctx.textAlign = "left";
    }
    if (level.finalMission && state.missionPhase) {
      const thermal = Math.round(state.atmosphericHeat);
      ctx.fillStyle = thermal >= 80 ? "rgba(255,74,52,.94)" : "rgba(232,188,126,.76)";
      ctx.font = "800 12px Cascadia Mono, monospace"; ctx.textAlign = "center";
      ctx.fillText(`${state.missionPhase} · HULL TEMP ${thermal}% · THRUST ${Math.round(state.thrustEfficiency * 100)}%`, W / 2, 118);
      ctx.textAlign = "left";
    }
    if (state.radarInterference > .12) {
      const blink=.55+Math.sin(state.worldTime*14)*.3;ctx.fillStyle=`rgba(255,86,106,${blink})`;ctx.font="800 12px Cascadia Mono, monospace";ctx.textAlign="center";ctx.fillText("NAV INTERFERENCE / RADAR DEGRADED",W/2,116);ctx.textAlign="left";
    }

    const meterX = W / 2 - 104, meterY = 52;
    ctx.fillStyle = "rgba(211,231,224,.42)"; ctx.font = "700 9px Cascadia Mono, monospace";
    ctx.fillText("VELOCIDAD", meterX, meterY - 11); ctx.fillText("ALINEACIÓN", meterX + 112, meterY - 11);
    ctx.fillStyle = "rgba(255,255,255,.075)"; ctx.fillRect(meterX,meterY,96,5); ctx.fillRect(meterX+112,meterY,96,5);
    ctx.fillStyle = safeSpeed ? "#58e38d" : "#ef4a4a"; ctx.fillRect(meterX,meterY,96*Math.max(0,1-speed/360),5);
    ctx.fillStyle = safeAngle ? "#58e38d" : "#ef4a4a"; ctx.fillRect(meterX+112,meterY,96*Math.max(0,1-angle/Math.PI),5);

    const routeW = 280;
    const routeX = W / 2 - routeW / 2;
    const routeY = H - 29;
    ctx.fillStyle = "rgba(210,232,224,.42)";
    ctx.font = "700 9px Cascadia Mono, monospace";
    ctx.fillText(`${level.verticalAscent ? "ASCENT" : "RUTA"} ${Math.round(state.routeProgress * 100)}%${state.checkpoint ? " · CP ACTIVE" : ""}`, routeX, routeY - 8);
    ctx.fillStyle = "rgba(255,255,255,.07)";
    ctx.fillRect(routeX, routeY, routeW, 5);
    ctx.fillStyle = "#dcebe5";
    ctx.fillRect(routeX, routeY, routeW * state.routeProgress, 5);
    drawRadar();
    ctx.restore();
  }

  function drawPhaseBanner() {
    if (!state.phaseBanner || state.phaseBannerTimer <= 0) return;
    const duration = 2.8;
    const elapsed = duration - state.phaseBannerTimer;
    const fadeIn = clamp(elapsed / .28, 0, 1);
    const fadeOut = clamp(state.phaseBannerTimer / .55, 0, 1);
    const alpha = Math.min(fadeIn, fadeOut);
    ctx.save();
    ctx.globalAlpha = alpha;
    const boxW = Math.min(620, W - 70);
    const boxH = 92;
    const x = (W - boxW) / 2;
    const y = H * .34;
    ctx.fillStyle = "rgba(2,8,7,.84)";
    ctx.fillRect(x, y, boxW, boxH);
    ctx.strokeStyle = "rgba(104,235,164,.52)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x + .5, y + .5, boxW - 1, boxH - 1);
    ctx.fillStyle = "rgba(104,235,164,.8)";
    ctx.fillRect(x, y, 4, boxH);
    ctx.textAlign = "center";
    ctx.fillStyle = "#effff5";
    ctx.font = "900 25px Cascadia Mono, monospace";
    ctx.fillText(state.phaseBanner.title, W / 2, y + 39);
    ctx.fillStyle = "rgba(173,218,198,.7)";
    ctx.font = "700 10px Cascadia Mono, monospace";
    ctx.fillText(state.phaseBanner.subtitle, W / 2, y + 64);
    ctx.textAlign = "left";
    ctx.restore();
  }

  function render() {
    ctx.save();
    if (state.settings.shake && state.screenShake > .1) {
      ctx.translate((Math.random() - .5) * state.screenShake, (Math.random() - .5) * state.screenShake);
      state.screenShake *= .88;
    }
    drawBackground();
    ctx.save();
    ctx.translate(-state.camera.x, -state.camera.y);
    drawLevel();
    drawPointerGuide();
    drawProjectiles();
    drawParticles();
    drawShip();
    ctx.restore();
    if (currentLevel()?.finalMission && state.atmosphericHeat > 1) {
      const heat = clamp(state.atmosphericHeat / 100, 0, 1);
      ctx.save();
      const glow = ctx.createRadialGradient(W / 2, H / 2, W * .16, W / 2, H / 2, W * .72);
      glow.addColorStop(0, "rgba(255,128,54,0)");
      glow.addColorStop(.72, `rgba(255,95,35,${heat * .08})`);
      glow.addColorStop(1, `rgba(255,44,22,${heat * .34})`);
      ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = heat * .5;
      ctx.strokeStyle = "rgba(255,180,92,.72)"; ctx.lineWidth = 1.2;
      for (let i = 0; i < 24; i += 1) {
        const y = (i * 37 + state.worldTime * (140 + i * 3)) % (H + 80) - 40;
        const x = (i * 83 + state.worldTime * 95) % (W + 180) - 90;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 42 - heat * 65, y + 18); ctx.stroke();
      }
      ctx.restore();
    }
    drawCanvasHud();
    drawPhaseBanner();
    if (state.radarInterference > .08) {
      const strength=clamp(state.radarInterference,0,1);ctx.save();ctx.globalAlpha=.035+strength*.08;ctx.fillStyle="#ff405d";for(let y=(Math.floor(state.worldTime*80)%23)-23;y<H;y+=23)ctx.fillRect(0,y,W,2);ctx.restore();
    }
    ctx.restore();

    if (state.flash > .01) {
      ctx.fillStyle = `rgba(238,23,59,${state.flash * .28})`;
      ctx.fillRect(0, 0, W, H);
      state.flash *= .84;
    }
  }

  function updateHud() {
    const level = currentLevel();
    ui.levelLabel.textContent = `${String(level.id).padStart(2, "0")} / ${level.name.toUpperCase()}`;
    ui.attempts.textContent = String(state.attempts).padStart(2, "0");
    ui.time.textContent = formatTime(state.elapsed);
    ui.speed.textContent = String(Math.round(Math.hypot(ship.vx, ship.vy)));
    if (ui.fuel) ui.fuel.textContent = `${Math.round(state.fuel)}%`;
    if (ui.heat) ui.heat.textContent = state.overheated ? "LOCK" : `${Math.round(state.weaponHeat)}%`;
    if (ui.hull) ui.hull.textContent = level.finalMission ? `${Math.round(state.atmosphericHeat)}%` : "NOMINAL";
    if (ui.reentryWarning) {
      const visible = level.finalMission && state.mode === "playing" && state.atmosphericHeat >= 8;
      ui.reentryWarning.hidden = !visible;
      if (ui.reentryValue) ui.reentryValue.textContent = `${Math.round(state.atmosphericHeat)}%`;
      if (ui.reentryBar) ui.reentryBar.style.width = `${Math.round(state.atmosphericHeat)}%`;
      ui.reentryWarning.classList.toggle("is-critical", state.atmosphericHeat >= 78);
    }
    if (ui.best) ui.best.textContent = formatTime(state.progress.best[state.levelIndex]);
    if (ui.score) ui.score.textContent = String(Math.max(0, Math.floor(state.score))).padStart(6, "0");
    ui.status.textContent = state.message;
    if (ui.fuelWarning) ui.fuelWarning.hidden = !(state.mode === "playing" && state.fuel <= 20);
    if (ui.overchargeWarning) {
      const visible = state.overheated || state.weaponNotice === "ready";
      ui.overchargeWarning.hidden = !visible;
      ui.overchargeWarning.classList.toggle("is-ready", state.weaponNotice === "ready" && !state.overheated);
      const span = ui.overchargeWarning.querySelector("span");
      const strong = ui.overchargeWarning.querySelector("b");
      if (span) span.textContent = state.overheated ? "OVERCHARGE! OVERCHARGE!" : "WEAPON READY";
      if (strong) strong.textContent = state.overheated ? "CANNON LOCKED / COOLING" : "FIRE CONTROL RESTORED";
    }
    if (ui.rechargePanel) {
      const charging = state.mode === "recharging" && state.recharge;
      ui.rechargePanel.hidden = !charging;
      if (charging) {
        const percentage = Math.round(state.fuel);
        if (ui.rechargeBar) ui.rechargeBar.style.width = `${percentage}%`;
        if (ui.rechargeValue) ui.rechargeValue.textContent = `${percentage}%`;
        if (ui.rechargeStatus) {
          const checkpoint = state.recharge.checkpoint;
          ui.rechargeStatus.textContent = checkpoint ? `${checkpoint.id} · ${checkpoint.phase || `RUTA ${checkpoint.ascent}%`} · TIME ${formatTime(state.elapsed)} · SCORE ${String(Math.floor(state.score)).padStart(6, "0")}` : (percentage >= 100 ? "FUEL RESTORED" : "TRANSFERENCIA EN CURSO");
        }
      }
    }
    if (ui.cells) ui.cells.textContent = `CELDAS ${state.collectedCells.size} / ${level.cells.length}${state.progress.grades[state.levelIndex] ? ` · RANGO ${state.progress.grades[state.levelIndex]}` : ""}`;
    if (ui.fuelBar) {
      ui.fuelBar.style.width = `${state.fuel}%`;
      ui.fuelBar.classList.toggle("is-low", state.fuel <= 25);
    }
    if (ui.heatBar) {
      ui.heatBar.style.width = `${state.weaponHeat}%`;
      ui.heatBar.classList.toggle("is-hot", state.weaponHeat >= 65);
      ui.heatBar.classList.toggle("is-locked", state.overheated);
    }
    ui.pauseLabel.textContent = state.mode === "paused" ? "Continuar" : "Pausa";
  }

  function loop(now) {
    const dt = Math.min(.033, Math.max(0, (now - state.lastTime) / 1000));
    state.lastTime = now;
    if (state.mode !== "paused") {
      updatePhysics(dt);
      if (state.mode !== "playing") updateParticles(dt);
    }
    render();
    updateHud();
    requestAnimationFrame(loop);
  }

  canvas.addEventListener("pointermove", event => {
    if (state.settings.controlMode === "classic") updatePointer(event);
  });
  canvas.addEventListener("pointerdown", event => {
    if (state.settings.controlMode !== "classic" || !state.creditActive || ui.arcadeLayer?.classList.contains("is-visible")) return;
    updatePointer(event);
    audio.ensure();
    if (!ui.overlay.classList.contains("is-visible") && state.mode !== "paused") {
      canvas.setPointerCapture?.(event.pointerId);
      if (event.button === 2) setFiring(true);
      else if (event.button === 0) setThrust(true);
    }
  });
  canvas.addEventListener("pointerup", event => {
    canvas.releasePointerCapture?.(event.pointerId);
    if (state.settings.controlMode === "classic") {
      if (event.button === 2) setFiring(false);
      else if (event.button === 0) setThrust(false);
    }
  });
  canvas.addEventListener("pointercancel", () => { setThrust(false); setFiring(false); });
  canvas.addEventListener("contextmenu", event => event.preventDefault());
  window.addEventListener("pointerup", () => {
    state.introFast = false;
    if (state.settings.controlMode === "classic") setThrust(false);
    setFiring(false);
  });

  const directionForCode = code => ({
    KeyW: "up", ArrowUp: "up", KeyS: "down", ArrowDown: "down",
    KeyA: "left", ArrowLeft: "left", KeyD: "right", ArrowRight: "right"
  })[code] || null;

  window.addEventListener("keydown", event => {
    if (ui.nameScreen && !ui.nameScreen.hidden) {
      if (/^[A-Z0-9]$/i.test(event.key)) { event.preventDefault(); typeNameCharacter(event.key); return; }
      if (event.key === "Backspace" || event.key === "Delete") { event.preventDefault(); eraseNameCharacter(); return; }
      if (event.key === "ArrowLeft") { event.preventDefault(); moveNamePosition(-1); return; }
      if (event.key === "ArrowRight") { event.preventDefault(); moveNamePosition(1); return; }
      if (event.key === "ArrowUp") { event.preventDefault(); cycleNameCharacter(1); return; }
      if (event.key === "ArrowDown") { event.preventDefault(); cycleNameCharacter(-1); return; }
      if (event.key === "Enter") { event.preventDefault(); registerHighScore(); return; }
    }
    const direction = directionForCode(event.code);
    if (direction && state.settings.controlMode === "arcade" && state.creditActive && !ui.arcadeLayer?.classList.contains("is-visible") && !ui.overlay.classList.contains("is-visible")) {
      event.preventDefault();
      state.arcadeKeys.add(direction);
      audio.ensure();
      setThrust(true);
      return;
    }
    if (event.code === "Space" && state.creditActive && !ui.arcadeLayer?.classList.contains("is-visible") && !ui.overlay.classList.contains("is-visible")) {
      event.preventDefault();
      audio.ensure();
      setFiring(true);
      return;
    }
    if (event.code === "KeyR" && state.creditActive && !ui.arcadeLayer?.classList.contains("is-visible") && !ui.overlay.classList.contains("is-visible")) {
      event.preventDefault();
      retryLevel();
    } else if ((event.code === "KeyP" || event.code === "Escape") && state.creditActive && !ui.arcadeLayer?.classList.contains("is-visible") && !ui.overlay.classList.contains("is-visible")) {
      event.preventDefault();
      if (state.mode === "paused") resumeGame();
      else pauseGame();
    } else if (event.code === "Enter" && ui.attractScreen && !ui.attractScreen.hidden) {
      event.preventDefault();
      insertCredit();
    }
  });
  window.addEventListener("keyup", event => {
    if (event.code === "Space") setFiring(false);
    const direction = directionForCode(event.code);
    if (direction) {
      state.arcadeKeys.delete(direction);
      if (state.settings.controlMode === "arcade" && state.arcadeKeys.size === 0) setThrust(false);
    }
  });
  window.addEventListener("blur", () => {
    state.arcadeKeys.clear();
    setThrust(false);
    setFiring(false);
    if (state.mode === "playing") pauseGame();
  });
  window.addEventListener("beforeunload", () => saveCampaign({ silent: true }));
  window.addEventListener("pagehide", () => {
    saveCampaign({ silent: true });
    state.creditActive = false;
    state.arcadeKeys.clear();
    setThrust(false);
    setFiring(false);
    audio.stopAmbient();
  });
  window.addEventListener("pageshow", event => {
    if (!event.persisted) return;
    state.creditActive = false;
    state.mode = "attract";
    updateBalance();
    showArcadeScreen(ui.attractScreen);
  });

  ui.startButton.addEventListener("click", handleOverlayAction);
  ui.levelButton.addEventListener("click", () => toggleLevelPanel());
  ui.levelClose.addEventListener("click", () => toggleLevelPanel(false));
  ui.restart.addEventListener("click", () => retryLevel());
  ui.pause.addEventListener("click", () => {
    if (state.mode === "paused") resumeGame();
    else pauseGame();
  });
  ui.menuButton?.addEventListener("click", openMainMenu);
  ui.sound.addEventListener("click", () => {
    state.settings.muted = audio.enabled;
    saveSettings();
  });

  ui.insertCoin?.addEventListener("click", insertCredit);
  ui.newGame?.addEventListener("click", startNewGame);
  ui.continueGame?.addEventListener("click", continueSavedGame);
  ui.hangarButton?.addEventListener("click", openHangar);
  ui.settingsButton?.addEventListener("click", openSettings);
  ui.highscoresButton?.addEventListener("click", () => { state.highlightedScoreId = ""; openHighScores("menu"); });
  ui.pendingCargoButton?.addEventListener("click", openPendingMetagame);
  ui.exitCredit?.addEventListener("click", exitCredit);
  ui.hangarBack?.addEventListener("click", openMainMenu);
  ui.settingsBack?.addEventListener("click", () => { saveSettings(); openMainMenu(); });
  ui.resultRegister?.addEventListener("click", openNameEntry);
  ui.resultBack?.addEventListener("click", openMainMenu);
  ui.nameUp?.addEventListener("click", () => cycleNameCharacter(1));
  ui.nameDown?.addEventListener("click", () => cycleNameCharacter(-1));
  ui.nameLeft?.addEventListener("click", () => moveNamePosition(-1));
  ui.nameRight?.addEventListener("click", () => moveNamePosition(1));
  ui.nameConfirm?.addEventListener("click", registerHighScore);
  ui.highscoresNext?.addEventListener("click", beginCargoRecovery);
  ui.highscoresBack?.addEventListener("click", openMainMenu);
  ui.cargoOpen?.addEventListener("click", openCargoContainer);
  ui.cargoEquip?.addEventListener("click", equipCargoReward);
  ui.cargoBack?.addEventListener("click", closeCargoRecovery);

  document.querySelectorAll('input[name="triangle-control"]').forEach(input => {
    input.addEventListener("change", () => {
      state.settings.controlMode = input.value === "arcade" ? "arcade" : "classic";
      state.arcadeKeys.clear();
      setThrust(false);
      applySettings();
    });
  });
  ui.settingMute?.addEventListener("change", () => { state.settings.muted = ui.settingMute.checked; applySettings(); });
  ui.settingMusic?.addEventListener("change", () => { state.settings.music = ui.settingMusic.checked; applySettings(); });
  ui.settingShake?.addEventListener("change", () => { state.settings.shake = ui.settingShake.checked; applySettings(); });
  ui.settingTimer?.addEventListener("change", () => { state.settings.showTimer = ui.settingTimer.checked; applySettings(); });
  ui.settingCrt?.addEventListener("input", () => { state.settings.crt = Number(ui.settingCrt.value) || 0; applySettings(); });

  ui.skipIntro?.addEventListener("pointerdown", event => { event.preventDefault(); state.introFast = true; });
  ui.skipIntro?.addEventListener("pointerup", () => { state.introFast = false; });
  ui.skipIntro?.addEventListener("pointercancel", () => { state.introFast = false; });
  ui.skipIntro?.addEventListener("click", () => {
    if (ui.skipIntro.dataset.ready === "true") launchCampaign();
    else state.introFast = true;
  });

  const touchStart = event => {
    event.preventDefault();
    if (!state.creditActive || state.settings.controlMode !== "classic" || ui.arcadeLayer?.classList.contains("is-visible") || ui.overlay.classList.contains("is-visible") || state.mode === "paused") return;
    audio.ensure();
    setThrust(true);
  };
  const touchStop = event => {
    event.preventDefault();
    setThrust(false);
  };
  ui.touchThrust.addEventListener("pointerdown", touchStart);
  ui.touchThrust.addEventListener("pointerup", touchStop);
  ui.touchThrust.addEventListener("pointercancel", touchStop);
  ui.touchThrust.addEventListener("pointerleave", touchStop);
  const touchFireStart = event => { event.preventDefault(); audio.ensure(); setFiring(true); };
  const touchFireStop = event => { event.preventDefault(); setFiring(false); };
  ui.touchFire?.addEventListener("pointerdown", touchFireStart);
  ui.touchFire?.addEventListener("pointerup", touchFireStop);
  ui.touchFire?.addEventListener("pointercancel", touchFireStop);
  ui.touchFire?.addEventListener("pointerleave", touchFireStop);

  const releaseTouchDirection = button => {
    const direction = button.dataset.touchDirection;
    if (!direction) return;
    state.arcadeKeys.delete(direction);
    button.classList.remove("is-pressed");
    if (state.settings.controlMode === "arcade" && state.arcadeKeys.size === 0) setThrust(false);
  };
  ui.touchDirections.forEach(button => {
    button.addEventListener("pointerdown", event => {
      event.preventDefault();
      if (!state.creditActive || state.settings.controlMode !== "arcade" || ui.arcadeLayer?.classList.contains("is-visible") || ui.overlay.classList.contains("is-visible") || state.mode === "paused") return;
      const direction = button.dataset.touchDirection;
      if (!direction) return;
      button.setPointerCapture?.(event.pointerId);
      state.arcadeKeys.add(direction);
      button.classList.add("is-pressed");
      audio.ensure();
      setThrust(true);
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach(type => button.addEventListener(type, event => {
      event.preventDefault();
      releaseTouchDirection(button);
    }));
  });



  renderLevelButtons();
  loadLevel(0, { showIntro: false });
  state.mode = "attract";
  state.message = "INSERT COIN para activar la máquina.";
  applySettings();
  updateMenuUI();
  showArcadeScreen(ui.attractScreen);
  requestAnimationFrame(loop);
})();
