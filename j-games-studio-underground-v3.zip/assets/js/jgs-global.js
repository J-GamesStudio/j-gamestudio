(() => {
  "use strict";
  const body=document.body;
  const id=body.dataset.jgsProject || location.pathname.match(/\/projects\/([^/]+)/)?.[1] || "project";
  const names={"detective-black":"DETECTIVE BLACK","tri-angle-ship":"TRI-ANGLE SHIP","pong":"PONG","uno":"UNO","cartas":"CARTAS","dados":"DADOS","nave":"NAVE"};
  const name=body.dataset.jgsProjectName || names[id] || id.toUpperCase();
  const root="../../";
  const dock=document.createElement("aside");dock.className="jgs-global-dock";dock.setAttribute("aria-label","J-GAMES perfil y economía");
  dock.innerHTML=`<a class="jgs-global-dock__home" href="${root}index.html#projects" aria-label="Volver a proyectos">←</a><a href="${root}account/profile.html"><span>JCOIN</span><strong data-dock-coins>0000</strong></a><a href="${root}account/profile.html"><span>HI-SCORE</span><strong data-dock-score>000000</strong></a><a href="${root}account/profile.html"><span>PERFIL</span><strong data-dock-profile>LOCAL</strong></a>`;
  body.appendChild(dock);
  const pad=(n,l)=>String(Math.max(0,Number(n)||0)).padStart(l,"0");
  function update(){const s=window.JGS_PLATFORM?.snapshot?.()||{};dock.querySelector("[data-dock-coins]").textContent=pad(s.balance,4);dock.querySelector("[data-dock-score]").textContent=pad(s.score,6);dock.querySelector("[data-dock-profile]").textContent=s.active&&s.profile?`#${s.profile.id}`:"REGISTRO";dock.querySelectorAll('a[href$="profile.html"]').forEach(a=>a.href=s.active?`${root}account/profile.html`:`${root}account/register.html`)}
  window.addEventListener("jgs:platform-change",update);update();
  const result=window.JGS_PLATFORM?.recordPlay?.(id,name);
  if(result?.awarded){const toast=document.createElement("div");toast.className="jgs-score-toast";toast.textContent=`+${result.awarded} PUNTOS / ${result.first?"PRIMERA PARTIDA":"NUEVA PARTIDA"}`;body.appendChild(toast);setTimeout(()=>toast.remove(),3000)}
})();