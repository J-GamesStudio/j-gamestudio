(() => {
  "use strict";
  const PAGE_SIZE = 25;
  const cards = Array.from(document.querySelectorAll("[data-project-card]"));
  const pager = document.querySelector("[data-pagination]");
  const empty = document.querySelector("[data-empty]");
  const visibleCount = document.querySelector("[data-visible-count]");
  const balanceNodes = document.querySelectorAll("[data-jgs-balance]");
  const scoreNodes = document.querySelectorAll("[data-jgs-score]");
  const accountLinks = document.querySelectorAll("[data-jgs-account-link]");
  const accountLabels = document.querySelectorAll("[data-jgs-account-label]");
  const accountIds = document.querySelectorAll("[data-jgs-account-id]");
  const pad = (n,l=4)=>String(Math.max(0,Number(n)||0)).padStart(l,"0");

  function renderPlatform(){
    const p = window.JGS_PLATFORM?.snapshot?.() || {};
    balanceNodes.forEach(n=>n.textContent=pad(p.balance,4));
    scoreNodes.forEach(n=>n.textContent=pad(p.score,6));
    const active = Boolean(p.active && p.profile);
    accountLinks.forEach(n=>n.href=active?"account/profile.html":"account/register.html");
    accountLabels.forEach(n=>n.textContent=active?p.profile.nick:"REGISTRARME");
    accountIds.forEach(n=>n.textContent=active?`ID ${p.profile.id}`:"+1000 JCOIN");
  }
  window.addEventListener("jgs:platform-change",renderPlatform); renderPlatform();

  const totalPages = Math.max(1,Math.ceil(cards.length/PAGE_SIZE));
  function showPage(page){
    const safe=Math.max(1,Math.min(totalPages,page)); const start=(safe-1)*PAGE_SIZE;
    cards.forEach((card,i)=>card.hidden=i<start||i>=start+PAGE_SIZE);
    if(visibleCount) visibleCount.textContent=pad(Math.min(PAGE_SIZE,Math.max(0,cards.length-start)),2);
    if(empty) empty.hidden=cards.length>0;
    pager?.querySelectorAll("button").forEach(b=>b.classList.toggle("is-active",Number(b.dataset.page)===safe));
  }
  if(pager && totalPages>1){pager.hidden=false;for(let i=1;i<=totalPages;i++){const b=document.createElement("button");b.type="button";b.dataset.page=i;b.textContent=pad(i,2);b.addEventListener("click",()=>showPage(i));pager.appendChild(b)}}
  showPage(1);

  document.querySelectorAll("[data-project-card] a").forEach(link=>{
    link.addEventListener("click",()=>{ try{sessionStorage.setItem("jgs-pending-project",link.closest("[data-project-id]")?.dataset.projectId||"")}catch{} });
  });

  const form=document.querySelector("[data-support-form]");
  if(form){
    form.addEventListener("submit",event=>{
      event.preventDefault();
      const status=form.querySelector("[data-form-status]");
      if(!form.checkValidity()){form.reportValidity();if(status)status.textContent="Completa los campos obligatorios antes de enviar.";return}
      const data=new FormData(form); const profile=window.JGS_PLATFORM?.getProfile?.();
      const subject=`[J-GAMES ${data.get("type")}] ${data.get("project")}`;
      const body=["REPORTE J-GAMES STUDIO","",`Proyecto: ${data.get("project")}`,`Tipo: ${data.get("type")}`,`E-mail: ${data.get("email")||profile?.email||"No indicado"}`,`Perfil: ${profile?`${profile.nick} / ID ${profile.id}`:"Sin perfil"}`,`Página: ${location.href}`,`Navegador: ${navigator.userAgent}`,"","Descripción:",String(data.get("message")||"")].join("\n");
      const gmail=`https://mail.google.com/mail/?view=cm&fs=1&to=contacto.jgamesstudio@gmail.com&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      if(status)status.textContent="Abriendo Gmail con el informe preparado…";
      const popup=window.open(gmail,"_blank","noopener");
      if(!popup) location.href=`mailto:contacto.jgamesstudio@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
  }
})();