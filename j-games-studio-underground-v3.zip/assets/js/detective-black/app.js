(() => {
  "use strict";

  const CASES = window.DETECTIVE_BLACK_CASES || {};
  const CATALOG = window.DETECTIVE_BLACK_CATALOG || [];
  const AVAILABLE = new Set(Object.keys(CASES));
  const STORAGE_PREFIX = "detective-black:v0.5:";
  const SELECTED_KEY = `${STORAGE_PREFIX}selected-case`;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const clone = value => JSON.parse(JSON.stringify(value));
  const asset = path => `../../${path}`;

  let CASE;
  let engine;
  let characterMap = new Map();
  let cellMap = new Map();
  let objectMap = new Map();

  function readJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  }
  function writeJSON(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }

  function emptyCaseState(caseData) {
    return {
      status: "unstarted",
      placements: {},
      marks: {},
      candidates: {},
      selectedCharacter: caseData.characters[0].id,
      tool: "place",
      undo: [],
      redo: [],
      hints: { observation: 0, deduction: 0, intervention: 0 },
      checks: 0,
      elapsedMs: 0,
      startedAt: null,
      resolvedAt: null,
      result: null
    };
  }

  function stateKey(id) { return `${STORAGE_PREFIX}${id}`; }
  function loadCaseState(id) {
    const caseData = CASES[id];
    if (!caseData) return null;
    let stored = readJSON(stateKey(id), null);
    if (!stored) stored = readJSON(`detective-black:v0.4:${id}`, null);
    if (!stored && id === "case-001") stored = readJSON("detective-black:v0.2:case-001", null);
    const result = { ...emptyCaseState(caseData), ...(stored || {}) };
    result.hints = { observation: 0, deduction: 0, intervention: 0, ...(result.hints || {}) };
    result.undo = [];
    result.redo = [];
    if (!caseData.characters.some(character => character.id === result.selectedCharacter)) result.selectedCharacter = caseData.characters[0].id;
    return result;
  }

  const selectedStored = readJSON(SELECTED_KEY, "case-001");
  const state = {
    view: "home",
    activeCaseId: AVAILABLE.has(selectedStored) ? selectedStored : "case-001",
    case: null,
    conflictCells: new Set(),
    reconstructionIndex: 0,
    timerId: null
  };

  function saveCase() {
    if (!CASE || !state.case) return;
    const copy = clone(state.case);
    copy.undo = [];
    copy.redo = [];
    writeJSON(stateKey(CASE.id), copy);
    renderGlobalStatus();
  }

  function elapsedMs() {
    return state.case.elapsedMs + (state.case.startedAt ? Date.now() - state.case.startedAt : 0);
  }
  function formatTime(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    return hours
      ? `${String(hours).padStart(2,"0")}:${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`
      : `${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;
  }
  function resumeClock() {
    if (state.case.status !== "investigating" || state.case.startedAt) return;
    state.case.startedAt = Date.now();
    saveCase();
  }
  function pauseClock() {
    if (!state.case?.startedAt) return;
    state.case.elapsedMs += Date.now() - state.case.startedAt;
    state.case.startedAt = null;
    saveCase();
  }
  function startTimer() {
    clearInterval(state.timerId);
    state.timerId = setInterval(() => {
      const node = $("[data-case-time]");
      if (node && state.case) node.textContent = formatTime(elapsedMs());
    }, 500);
  }

  function catalogItem(id = CASE?.id) { return CATALOG.find(item => item.id === id); }
  function victim() { return CASE.characters.find(character => character.id === CASE.victimId); }
  function rank() {
    const penalty = state.case.hints.deduction + state.case.hints.intervention * 2 + state.case.checks;
    if (penalty === 0) return "S";
    if (penalty <= 1) return "A";
    if (penalty <= 3) return "B";
    return "C";
  }

  function statusLabel(caseState) {
    if (caseState.status === "resolved") return "RESOLVED";
    if (caseState.status === "investigating") return "ACTIVE";
    return "OPEN";
  }

  function updateCaseChrome() {
    const item = catalogItem();
    const vic = victim();
    const number = item?.number || CASE.id.slice(-3);
    const difficulty = item?.difficultyLabel || CASE.difficulty.toUpperCase();
    const status = statusLabel(state.case);
    document.title = `DETECTIVE BLACK — Caso ${number}: ${CASE.title}`;

    const setText = (selector, text) => { const node = $(selector); if (node) node.textContent = text; };
    setText("[data-active-case-kicker]", `BLACK ARCHIVE // CASE ${number} SELECTED`);
    const heroHeading = $("[data-active-case-heading]");
    if (heroHeading) heroHeading.innerHTML = `${CASE.title}<br><em>${CASE.subtitle || "EXPEDIENTE ABIERTO"}</em>`;
    setText("[data-active-case-lead]", CASE.briefing.incident);
    setText("[data-active-case-number]", `CASE ${number}`);
    setText("[data-active-case-state]", status);
    setText("[data-active-victim-name]", vic.name.toUpperCase());
    setText("[data-active-victim-role]", vic.role.toUpperCase());
    setText("[data-active-location]", CASE.briefing.address.split(" / ")[0]);
    setText("[data-active-time]", CASE.briefing.time);
    setText("[data-active-subjects]", String(CASE.characters.length).padStart(2,"0"));
    setText("[data-active-grid]", `${CASE.gridSize}×${CASE.gridSize}`);
    const heroVictim = $("[data-active-victim-image]");
    if (heroVictim) { heroVictim.src = asset(vic.portrait); heroVictim.alt = `Retrato de ${vic.name}`; }

    setText("[data-home-case-label]", `CASE ${number}`);
    setText("[data-home-case-status]", status);
    setText("[data-home-case-meta]", `${difficulty} / ${CASE.gridSize}×${CASE.gridSize}`);
    setText("[data-home-active-title]", `${CASE.title}.`);
    setText("[data-home-active-description]", `${CASE.briefing.address}. ${CASE.characters.length} personas, ${CASE.clues.length} testimonios y una única reconstrucción.`);
    const start = $("[data-start-case]");
    if (start) start.textContent = state.case.status === "resolved" ? `Revisar Caso ${number}` : state.case.status === "investigating" ? `Continuar Caso ${number}` : `Investigar Caso ${number}`;

    setText("[data-investigation-kicker]", `CASE ${number} // ${CASE.title.toUpperCase()}`);
    setText("[data-scene-title]", `${CASE.briefing.address.split(" / ")[0]} / ${CASE.gridSize}×${CASE.gridSize}`);
    setText("[data-scene-coordinates]", `F01–F${String(CASE.gridSize).padStart(2,"0")} / C01–C${String(CASE.gridSize).padStart(2,"0")}`);
    setText("[data-tools-case]", `BLACK / CASE ${number}`);
    setText("[data-shortcut-subjects]", `1–${CASE.characters.length} Persona`);

    setText("[data-briefing-kicker]", `CASE ${number} / INCIDENT BRIEF`);
    setText("[data-briefing-title]", CASE.title);
    setText("[data-briefing-location]", CASE.briefing.address);
    setText("[data-briefing-meta]", `${difficulty} / ${CASE.gridSize}×${CASE.gridSize}`);
    setText("[data-briefing-victim-name]", vic.name.toUpperCase());
    setText("[data-briefing-victim-role]", vic.role.toUpperCase());
    const modalVictim = $("[data-briefing-victim-image]");
    if (modalVictim) { modalVictim.src = asset(vic.portrait); modalVictim.alt = vic.name; }
    setText("[data-accusation-title]", `¿Quién mató a ${vic.name.split(" ")[0]}?`);
  }

  function selectCase(id, options = {}) {
    if (!AVAILABLE.has(id)) return false;
    if (CASE && CASE.id !== id) pauseClock();
    CASE = CASES[id];
    engine = new window.DetectiveBlackRuleEngine(CASE);
    characterMap = new Map(CASE.characters.map(character => [character.id, character]));
    cellMap = new Map(CASE.cells.map(cell => [cell.id, cell]));
    objectMap = new Map(CASE.objects.map(object => [object.id, object]));
    state.activeCaseId = id;
    state.case = loadCaseState(id);
    state.conflictCells.clear();
    state.reconstructionIndex = 0;
    writeJSON(SELECTED_KEY, id);
    updateCaseChrome();
    buildSuspects();
    buildRegionLegend();
    buildCaseBoard();
    renderGlobalStatus();
    renderCase();
    if (options.runDiagnostics !== false) runDiagnostics();
    return true;
  }

  function setView(view) {
    if (state.view === "investigation" && view !== "investigation") pauseClock();
    state.view = view;
    $$('[data-db-view]').forEach(section => { section.hidden = section.dataset.dbView !== view; });
    $$('[data-db-nav]').forEach(button => {
      const active = button.dataset.dbNav === view;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-current", active ? "page" : "false");
    });
    document.body.dataset.dbCurrentView = view;
    if (view === "investigation" && state.case.status !== "resolved") {
      if (state.case.status === "unstarted") state.case.status = "investigating";
      resumeClock();
      renderCase();
    }
    window.scrollTo({ top: 0, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }

  function renderGlobalStatus() {
    if (!CASE || !state.case) return;
    updateCaseChrome();
    renderArchive();
  }

  function renderArchive() {
    const root = $("[data-case-archive]");
    if (!root) return;
    root.innerHTML = "";
    for (const item of CATALOG) {
      const available = AVAILABLE.has(item.id);
      const caseState = available ? loadCaseState(item.id) : null;
      const status = available ? caseState.status : "classified";
      const article = document.createElement("article");
      article.className = `db-case-card db-case-card--${item.difficulty}`;
      article.dataset.caseDifficulty = item.difficulty;
      article.dataset.caseStatus = status;
      let label = "CLASIFICADO";
      if (status === "unstarted") label = "DISPONIBLE";
      if (status === "investigating") label = "INVESTIGANDO";
      if (status === "resolved") label = "RESUELTO";
      const progress = available ? `${Object.keys(caseState.placements || {}).length}/${item.gridSize}` : "—";
      article.innerHTML = `
        <button type="button" class="db-case-card__button" data-case-open="${item.id}" aria-label="Abrir expediente ${item.number}: ${item.title}">
          <span class="db-case-card__index">CASE ${item.number}</span>
          <span class="db-case-card__status">${label}</span>
          <span class="db-case-card__grid">${item.gridSize}×${item.gridSize}</span>
          <span class="db-case-card__title">${item.title}</span>
          <span class="db-case-card__location">${item.location}</span>
          <span class="db-case-card__difficulty">${item.difficultyLabel}</span>
          <span class="db-case-card__focus">${item.focus}</span>
          <span class="db-case-card__progress">PROGRESO ${progress}</span>
          <span class="db-case-card__seal" aria-hidden="true">${status === "resolved" ? "✓" : available ? "DB" : "LOCK"}</span>
        </button>`;
      root.appendChild(article);
    }
    const activeFilter = $("[data-case-filter].is-active")?.dataset.caseFilter || "all";
    filterArchive(activeFilter);
  }

  function filterArchive(filter) {
    $$('[data-case-filter]').forEach(button => {
      const active = button.dataset.caseFilter === filter;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    let count = 0;
    $$('[data-case-difficulty]').forEach(card => {
      const show = filter === "all" || card.dataset.caseDifficulty === filter;
      card.hidden = !show;
      if (show) count += 1;
    });
    const output = $("[data-case-visible-count]");
    if (output) output.textContent = String(count).padStart(2, "0");
  }

  function archiveNotice(text, tone = "neutral") {
    const node = $("[data-archive-notice]");
    if (!node) return;
    node.textContent = text;
    node.dataset.tone = tone;
  }

  function openBriefing() {
    updateCaseChrome();
    $("[data-briefing-incident]").textContent = CASE.briefing.incident;
    $("[data-briefing-objective]").textContent = CASE.briefing.objective;
    $("[data-modal-status]").textContent = state.case.status === "resolved" ? "RECONSTRUCCIÓN CONFIRMADA" : state.case.status === "investigating" ? "INVESTIGACIÓN GUARDADA" : "EXPEDIENTE SIN ABRIR";
    $("[data-begin-investigation]").textContent = state.case.status === "resolved" ? "Revisar solución" : state.case.status === "investigating" ? "Continuar investigación" : "Abrir escena";
    $("[data-case-modal]").hidden = false;
    document.body.classList.add("db-modal-open");
  }
  function closeModal(selector) {
    const modal = $(selector);
    if (modal) modal.hidden = true;
    if (!$$('.db-modal:not([hidden])').length) document.body.classList.remove("db-modal-open");
  }
  function beginInvestigation() {
    closeModal("[data-case-modal]");
    if (state.case.status === "resolved") { openReconstruction(CASE.explanation.length - 1); return; }
    if (state.case.status === "unstarted") {
      state.case.status = "investigating";
      state.case.elapsedMs = 0;
      state.case.startedAt = Date.now();
      saveCase();
    }
    setView("investigation");
  }

  function renderRuleStep(index) {
    $$('[data-rule-step-button]').forEach(button => {
      const active = Number(button.dataset.ruleStepButton) === index;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", String(active));
    });
    $$('[data-rule-step]').forEach(panel => { panel.hidden = Number(panel.dataset.ruleStep) !== index; });
    const board = $("[data-rule-board]");
    if (board) board.dataset.step = String(index);
  }

  function objectAbbr(object) {
    const map = {
      chair:"SEAT", stool:"SEAT", sofa:"SOFA", bench:"BENCH", bed:"BED", cart:"CART", trolley:"CART", pallet:"PAL",
      mark:"MARK", spill:"WET", terminal:"TERM", ladder:"LADR", console:"CTRL", linen:"LINEN", luggage:"BAG",
      rack:"RACK", shelf:"SHLF", wardrobe:"WARD", curtain:"CURT", trunk:"TRNK", detector:"SCAN", scanner:"SCAN",
      tray:"TRAY", machine:"MACH", shower:"DECO", tank:"TANK", reel:"HOSE", lights:"LITE", painting:"ART", sculpture:"SCUL",
      podium:"PODM", sofa:"SOFA", piano:"PIAN", cage:"CAGE", safe:"SAFE", pallet:"PAL", vehicle:"LIFT", frames:"FRAM"
    };
    return map[object.type] || String(object.label || object.type || "OBJ").replace(/[^A-ZÁÉÍÓÚÑ0-9]/gi, "").slice(0,4).toUpperCase() || "OBJ";
  }

  function buildSuspects() {
    const root = $("[data-suspect-list]");
    if (!root || !CASE) return;
    root.innerHTML = `<header><span>SUBJECT INDEX</span><strong>${String(CASE.characters.length).padStart(2,"0")} PERSONAS</strong></header>`;
    CASE.characters.forEach((character, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.subject = character.id;
      button.style.setProperty("--subject-color", character.color);
      button.innerHTML = `<img src="${asset(character.portrait)}" alt=""><span class="db-suspect-card__copy"><small>${character.victim ? "VÍCTIMA" : character.role}</small><strong>${character.name}</strong><em>${character.clue}</em><b data-subject-position="${character.id}">SIN COLOCAR</b></span><kbd>${index + 1}</kbd>`;
      root.appendChild(button);
    });
  }

  function buildRegionLegend() {
    const root = $("[data-region-legend]");
    if (!root) return;
    root.innerHTML = CASE.regions.map(region => `<span style="--region:${region.accent}"><i></i>${region.name}</span>`).join("");
  }

  function buildCaseBoard(rootSelector = "[data-case-board]", reconstruction = false) {
    const board = $(rootSelector);
    if (!board) return;
    board.innerHTML = "";
    board.style.setProperty("--grid-size", CASE.gridSize);
    board.dataset.gridSize = String(CASE.gridSize);
    for (const cell of CASE.cells) {
      const node = reconstruction ? document.createElement("div") : document.createElement("button");
      if (!reconstruction) node.type = "button";
      node.className = "db-case-cell";
      node.dataset.cellId = cell.id;
      node.dataset.row = String(cell.row);
      node.dataset.col = String(cell.col);
      node.dataset.region = cell.regionId;
      const region = CASE.regions.find(entry => entry.id === cell.regionId);
      node.style.setProperty("--region", region?.accent || "#666");
      const top = cell.row === 1 || cellMap.get(`r${cell.row - 1}c${cell.col}`)?.regionId !== cell.regionId;
      const bottom = cell.row === CASE.gridSize || cellMap.get(`r${cell.row + 1}c${cell.col}`)?.regionId !== cell.regionId;
      const left = cell.col === 1 || cellMap.get(`r${cell.row}c${cell.col - 1}`)?.regionId !== cell.regionId;
      const right = cell.col === CASE.gridSize || cellMap.get(`r${cell.row}c${cell.col + 1}`)?.regionId !== cell.regionId;
      if (top) node.classList.add("region-top");
      if (bottom) node.classList.add("region-bottom");
      if (left) node.classList.add("region-left");
      if (right) node.classList.add("region-right");
      const object = cell.objectId ? objectMap.get(cell.objectId) : null;
      if (!engine.isOccupable(cell.id)) {
        node.classList.add("is-blocked");
        if (!reconstruction) node.disabled = true;
      } else if (object) node.classList.add("is-occupiable-object");
      const label = [`Fila ${cell.row}, columna ${cell.col}`, region?.name || cell.regionId];
      if (object) label.push(object.label, object.occupiable ? "ocupable" : "bloqueado");
      node.setAttribute("aria-label", label.join(", "));
      node.innerHTML = `<span class="db-case-cell__coord">${cell.row}.${cell.col}</span>${object ? `<span class="db-case-cell__object" title="${object.label}"><b>${objectAbbr(object)}</b><small>${object.label}</small></span>` : ""}`;
      board.appendChild(node);
    }
  }

  function boardSnapshot() { return { placements: clone(state.case.placements), marks: clone(state.case.marks), candidates: clone(state.case.candidates) }; }
  function pushHistory() {
    state.case.undo.push(boardSnapshot());
    if (state.case.undo.length > 100) state.case.undo.shift();
    state.case.redo = [];
  }

  function renderCase() {
    const board = $("[data-case-board]");
    if (!board || !CASE || !state.case) return;
    const placedRows = new Set();
    const placedCols = new Set();
    Object.values(state.case.placements).forEach(cellId => {
      const cell = cellMap.get(cellId);
      if (cell) { placedRows.add(cell.row); placedCols.add(cell.col); }
    });
    $$('.db-case-cell', board).forEach(node => {
      const id = node.dataset.cellId;
      node.classList.remove("has-piece","has-mark","has-candidate","is-line-used","is-conflict","is-selected-piece");
      node.querySelectorAll(".db-case-cell__piece,.db-case-cell__mark,.db-case-cell__candidate").forEach(child => child.remove());
      if (placedRows.has(Number(node.dataset.row)) || placedCols.has(Number(node.dataset.col))) node.classList.add("is-line-used");
      const characterId = Object.entries(state.case.placements).find(([, cellId]) => cellId === id)?.[0];
      if (characterId) {
        const character = characterMap.get(characterId);
        node.classList.add("has-piece");
        if (characterId === state.case.selectedCharacter) node.classList.add("is-selected-piece");
        const piece = document.createElement("span");
        piece.className = "db-case-cell__piece";
        piece.style.setProperty("--subject-color", character.color);
        piece.innerHTML = `<img src="${asset(character.portrait)}" alt=""><b>${character.initial}</b>`;
        node.appendChild(piece);
      }
      if ((state.case.marks[id] || []).includes(state.case.selectedCharacter)) {
        node.classList.add("has-mark");
        const mark = document.createElement("span"); mark.className = "db-case-cell__mark"; mark.textContent = "×"; node.appendChild(mark);
      }
      const candidates = state.case.candidates[id] || [];
      if (candidates.length) {
        node.classList.add("has-candidate");
        const note = document.createElement("span"); note.className = "db-case-cell__candidate"; note.textContent = candidates.map(id => characterMap.get(id)?.initial || "?").join(" "); node.appendChild(note);
      }
      if (state.conflictCells.has(id)) node.classList.add("is-conflict");
    });
    $$('[data-subject]').forEach(button => {
      const id = button.dataset.subject;
      button.classList.toggle("is-active", id === state.case.selectedCharacter);
      const position = $(`[data-subject-position="${id}"]`, button);
      const cell = cellMap.get(state.case.placements[id]);
      if (position) position.textContent = cell ? `F${cell.row} / C${cell.col}` : "SIN COLOCAR";
    });
    $$('[data-tool]').forEach(button => button.classList.toggle("is-active", button.dataset.tool === state.case.tool));
    $("[data-undo]").disabled = state.case.undo.length === 0;
    $("[data-redo]").disabled = state.case.redo.length === 0;
    $("[data-case-placed]").textContent = `${Object.keys(state.case.placements).length}/${CASE.gridSize}`;
    $("[data-case-rank]").textContent = rank();
    $("[data-case-time]").textContent = formatTime(elapsedMs());
    $("[data-accuse]").disabled = !readyForAccusation();
    saveCase();
  }

  function setMessage(text, tone = "neutral") {
    const node = $("[data-case-message]");
    if (!node) return;
    node.textContent = text;
    node.dataset.tone = tone;
  }

  function useCaseCell(node) {
    if (node.disabled || state.case.status === "resolved") return;
    const cellId = node.dataset.cellId;
    const selected = state.case.selectedCharacter;
    pushHistory();
    state.conflictCells.clear();
    if (state.case.tool === "place") {
      const cell = cellMap.get(cellId);
      const rowConflict = Object.entries(state.case.placements).find(([id, placedId]) => id !== selected && cellMap.get(placedId)?.row === cell.row);
      const colConflict = Object.entries(state.case.placements).find(([id, placedId]) => id !== selected && cellMap.get(placedId)?.col === cell.col);
      if (rowConflict || colConflict) {
        state.case.undo.pop();
        const conflict = rowConflict || colConflict;
        state.conflictCells.add(cellId); state.conflictCells.add(conflict[1]);
        setMessage(`Contradicción: la fila o columna ya pertenece a ${characterMap.get(conflict[0]).name}.`, "danger");
        renderCase(); return;
      }
      const occupant = Object.entries(state.case.placements).find(([, placedId]) => placedId === cellId)?.[0];
      if (occupant && occupant !== selected) delete state.case.placements[occupant];
      if (state.case.placements[selected] === cellId) delete state.case.placements[selected];
      else state.case.placements[selected] = cellId;
      state.case.marks[cellId] = (state.case.marks[cellId] || []).filter(id => id !== selected);
      state.case.candidates[cellId] = (state.case.candidates[cellId] || []).filter(id => id !== selected);
      setMessage("Posición registrada. La fila y la columna han quedado reservadas.", "success");
    } else if (state.case.tool === "x") {
      const list = new Set(state.case.marks[cellId] || []);
      list.has(selected) ? list.delete(selected) : list.add(selected);
      state.case.marks[cellId] = [...list];
      setMessage("Marca de descarte actualizada para la persona seleccionada.");
    } else {
      const list = new Set(state.case.candidates[cellId] || []);
      list.has(selected) ? list.delete(selected) : list.add(selected);
      state.case.candidates[cellId] = [...list].sort();
      setMessage("Candidatos de la casilla actualizados.");
    }
    renderCase();
  }

  function undo() {
    if (!state.case.undo.length) return;
    state.case.redo.push(boardSnapshot());
    const snapshot = state.case.undo.pop();
    state.case.placements = snapshot.placements;
    state.case.marks = snapshot.marks;
    state.case.candidates = snapshot.candidates;
    state.conflictCells.clear();
    renderCase();
  }
  function redo() {
    if (!state.case.redo.length) return;
    state.case.undo.push(boardSnapshot());
    const snapshot = state.case.redo.pop();
    state.case.placements = snapshot.placements;
    state.case.marks = snapshot.marks;
    state.case.candidates = snapshot.candidates;
    state.conflictCells.clear();
    renderCase();
  }

  function readyForAccusation() {
    if (Object.keys(state.case.placements).length !== CASE.gridSize) return false;
    const structural = engine.checkAssignment(state.case.placements, { partial: false });
    return structural.valid && engine.findMurderer(state.case.placements).valid;
  }

  function checkCase() {
    state.conflictCells.clear();
    const partial = Object.keys(state.case.placements).length < CASE.gridSize;
    const validation = engine.checkAssignment(state.case.placements, { partial });
    if (!validation.valid) {
      state.case.checks += 1;
      Object.values(state.case.placements).forEach(id => state.conflictCells.add(id));
      setMessage(`La escena contiene contradicciones: ${validation.errors[0]}`, "danger");
    } else if (partial) {
      setMessage("No hay contradicciones en las posiciones actuales. La investigación sigue abierta.", "success");
    } else {
      const murder = engine.findMurderer(state.case.placements);
      if (!murder.valid) {
        state.case.checks += 1;
        setMessage("La zona de la víctima no contiene exactamente a una persona más.", "danger");
      } else setMessage("Reconstrucción coherente. Ya puedes firmar la acusación.", "success");
    }
    renderCase();
  }

  function nextUnresolvedStep() {
    const placementSteps = CASE.explanation.filter(step => step.characterId && step.cellId && step.title !== "La acusación");
    return placementSteps.find(step => state.case.placements[step.characterId] !== step.cellId) || placementSteps[placementSteps.length - 1];
  }

  function useHint(level) {
    const hint = CASE.hintLayers.find(entry => entry.level === level);
    if (!hint) return;
    if (level === "observation") {
      state.case.hints.observation += 1;
      setMessage(hint.text, "hint");
    } else if (level === "deduction") {
      state.case.hints.deduction += 1;
      const step = nextUnresolvedStep();
      setMessage(`DEDUCCIÓN: ${step.text}`, "hint");
    } else {
      state.case.hints.intervention += 1;
      const step = nextUnresolvedStep();
      pushHistory();
      const target = cellMap.get(step.cellId);
      for (const [id, placedId] of Object.entries(state.case.placements)) {
        const current = cellMap.get(placedId);
        if (id !== step.characterId && (placedId === step.cellId || current?.row === target.row || current?.col === target.col)) delete state.case.placements[id];
      }
      state.case.placements[step.characterId] = step.cellId;
      state.case.selectedCharacter = step.characterId;
      setMessage(`INTERVENCIÓN: ${step.text}`, "hint");
    }
    renderCase();
  }

  function resetCase() {
    const item = catalogItem();
    if (!confirm(`¿Reiniciar por completo el Caso ${item.number}? Se perderán las marcas y el tiempo actual.`)) return;
    pauseClock();
    state.case = emptyCaseState(CASE);
    state.case.status = "investigating";
    state.case.startedAt = Date.now();
    state.conflictCells.clear();
    setMessage("El expediente ha vuelto a su estado inicial.");
    renderCase();
  }

  function openAccusation() {
    if (!readyForAccusation()) return;
    const root = $("[data-accusation-list]");
    root.innerHTML = "";
    CASE.characters.filter(character => !character.victim).forEach(character => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.accuseCharacter = character.id;
      button.innerHTML = `<img src="${asset(character.portrait)}" alt=""><span><strong>${character.name}</strong><small>${character.role}</small></span>`;
      root.appendChild(button);
    });
    $("[data-accusation-message]").textContent = "";
    $("[data-accusation-modal]").hidden = false;
    document.body.classList.add("db-modal-open");
  }

  function accuse(characterId) {
    const murder = engine.findMurderer(state.case.placements);
    if (characterId !== murder.murdererId) {
      state.case.checks += 1;
      saveCase();
      $("[data-accusation-message]").textContent = "La acusación no se sostiene con la escena reconstruida. Revisa el área de la víctima.";
      return;
    }
    pauseClock();
    state.case.status = "resolved";
    state.case.resolvedAt = new Date().toISOString();
    state.case.result = { rank: rank(), timeMs: state.case.elapsedMs, hints: clone(state.case.hints), checks: state.case.checks, murdererId: characterId };
    saveCase();
    closeModal("[data-accusation-modal]");
    openReconstruction(0);
  }

  function buildReconstructionBoard() { buildCaseBoard("[data-reconstruction-board]", true); }
  function openReconstruction(index = 0) {
    state.reconstructionIndex = Math.max(0, Math.min(CASE.explanation.length - 1, index));
    buildReconstructionBoard();
    renderReconstruction();
    $("[data-reconstruction-modal]").hidden = false;
    document.body.classList.add("db-modal-open");
  }
  function renderReconstruction() {
    const step = CASE.explanation[state.reconstructionIndex];
    $("[data-reconstruction-counter]").textContent = `PASO ${String(step.step).padStart(2,"0")} / ${String(CASE.explanation.length).padStart(2,"0")}`;
    $("[data-reconstruction-title]").textContent = step.title;
    $("[data-reconstruction-text]").textContent = step.text;
    $("[data-reconstruction-progress]").style.width = `${((state.reconstructionIndex + 1) / CASE.explanation.length) * 100}%`;
    const seen = new Set();
    CASE.explanation.slice(0, state.reconstructionIndex + 1).forEach(entry => { if (entry.characterId && entry.cellId) seen.add(entry.characterId); });
    $$('.db-case-cell', $("[data-reconstruction-board]")).forEach(node => {
      node.querySelectorAll(".db-case-cell__piece").forEach(child => child.remove());
      node.classList.remove("has-piece","is-focus-step");
      const characterId = [...seen].find(id => CASE.solution[id] === node.dataset.cellId);
      if (characterId) {
        const character = characterMap.get(characterId);
        const piece = document.createElement("span");
        piece.className = "db-case-cell__piece";
        piece.style.setProperty("--subject-color", character.color);
        piece.innerHTML = `<img src="${asset(character.portrait)}" alt=""><b>${character.initial}</b>`;
        node.appendChild(piece);
        node.classList.add("has-piece");
      }
      if (node.dataset.cellId === step.cellId) node.classList.add("is-focus-step");
    });
    $("[data-reconstruction-prev]").disabled = state.reconstructionIndex === 0;
    const final = state.reconstructionIndex === CASE.explanation.length - 1;
    $("[data-reconstruction-next]").hidden = final;
    $("[data-case-result]").hidden = !final;
    if (final) {
      const result = state.case.result || { rank: rank(), timeMs: elapsedMs(), hints: state.case.hints, checks: state.case.checks };
      $("[data-result-rank]").textContent = result.rank;
      $("[data-result-time]").textContent = formatTime(result.timeMs);
      $("[data-result-hints]").textContent = String((result.hints?.deduction || 0) + (result.hints?.intervention || 0));
      $("[data-result-checks]").textContent = String(result.checks || 0);
    }
  }

  function archiveResult() {
    closeModal("[data-reconstruction-modal]");
    setView("archive");
    renderArchive();
  }

  function runDiagnostics() {
    if (!CASE || !window.DetectiveBlackSolver) return;
    const button = $("[data-run-diagnostics]");
    if (button) { button.disabled = true; button.textContent = "ANALIZANDO…"; }
    setTimeout(() => {
      const solver = new window.DetectiveBlackSolver(CASE);
      const report = solver.diagnose();
      const essential = report.clueNecessity.filter(entry => entry.essential).length;
      const values = {
        schema: report.schemaErrors.length ? `${report.schemaErrors.length} ERROR` : "VALID",
        solutions: String(report.solutionCount),
        unique: report.unique ? "CONFIRMED" : "FAILED",
        murderer: report.murdererId ? characterMap.get(report.murdererId)?.initial || "?" : "—",
        essential: `${essential}/${CASE.clues.length}`,
        human: `${report.human.steps.length} STEPS`
      };
      Object.entries(values).forEach(([key, value]) => { const node = $(`[data-diagnostic="${key}"]`); if (node) node.textContent = value; });
      const item = catalogItem();
      $("[data-diagnostic-log]").textContent = report.unique && report.solutionValidation.valid && report.human.solved
        ? `CASE ${item.number} PASS // Solución única, culpable víctima-área confirmado y ${report.human.steps.length} pasos humanos registrados. ${essential}/${CASE.clues.length} pistas son estructuralmente esenciales; las restantes cumplen una función pedagógica.`
        : `CASE ${item.number} FAIL // ${[...report.schemaErrors, ...report.solutionValidation.errors].join(" | ")}`;
      if (button) { button.disabled = false; button.textContent = "REPETIR DIAGNÓSTICO"; }
    }, 60);
  }

  function bind() {
    $$('[data-db-nav]').forEach(button => button.addEventListener("click", () => {
      if (button.dataset.dbNav === "investigation" && state.case.status === "unstarted") openBriefing();
      else setView(button.dataset.dbNav);
    }));
    $$('[data-view-target]').forEach(button => button.addEventListener("click", () => setView(button.dataset.viewTarget)));
    $("[data-start-case]")?.addEventListener("click", () => state.case.status === "resolved" ? openReconstruction(CASE.explanation.length - 1) : openBriefing());
    $("[data-case-archive]")?.addEventListener("click", event => {
      const button = event.target.closest("[data-case-open]");
      if (!button) return;
      const id = button.dataset.caseOpen;
      if (!AVAILABLE.has(id)) {
        archiveNotice("Este expediente permanece clasificado para el siguiente bloque de producción.", "neutral");
        return;
      }
      selectCase(id);
      archiveNotice(`CASE ${catalogItem(id).number} seleccionado: ${CASES[id].title}.`, "success");
      state.case.status === "resolved" ? openReconstruction(CASE.explanation.length - 1) : openBriefing();
    });
    $$('[data-case-filter]').forEach(button => button.addEventListener("click", () => filterArchive(button.dataset.caseFilter)));
    $("[data-close-case-modal]")?.addEventListener("click", () => closeModal("[data-case-modal]"));
    $("[data-case-modal]")?.addEventListener("click", event => { if (event.target.matches("[data-case-modal]")) closeModal("[data-case-modal]"); });
    $("[data-begin-investigation]")?.addEventListener("click", beginInvestigation);
    $("[data-open-briefing]")?.addEventListener("click", openBriefing);
    $$('[data-rule-step-button]').forEach(button => button.addEventListener("click", () => renderRuleStep(Number(button.dataset.ruleStepButton))));
    $("[data-suspect-list]")?.addEventListener("click", event => { const button = event.target.closest("[data-subject]"); if (button) { state.case.selectedCharacter = button.dataset.subject; renderCase(); } });
    $("[data-case-board]")?.addEventListener("click", event => { const cell = event.target.closest(".db-case-cell"); if (cell) useCaseCell(cell); });
    $$('[data-tool]').forEach(button => button.addEventListener("click", () => { state.case.tool = button.dataset.tool; renderCase(); }));
    $("[data-check-case]")?.addEventListener("click", checkCase);
    $$('[data-hint]').forEach(button => button.addEventListener("click", () => useHint(button.dataset.hint)));
    $("[data-undo]")?.addEventListener("click", undo);
    $("[data-redo]")?.addEventListener("click", redo);
    $("[data-reset-case]")?.addEventListener("click", resetCase);
    $("[data-accuse]")?.addEventListener("click", openAccusation);
    $("[data-close-accusation]")?.addEventListener("click", () => closeModal("[data-accusation-modal]"));
    $("[data-accusation-list]")?.addEventListener("click", event => { const button = event.target.closest("[data-accuse-character]"); if (button) accuse(button.dataset.accuseCharacter); });
    $("[data-reconstruction-prev]")?.addEventListener("click", () => { state.reconstructionIndex -= 1; renderReconstruction(); });
    $("[data-reconstruction-next]")?.addEventListener("click", () => { state.reconstructionIndex += 1; renderReconstruction(); });
    $("[data-archive-result]")?.addEventListener("click", archiveResult);
    $("[data-run-diagnostics]")?.addEventListener("click", runDiagnostics);
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        const open = $$('.db-modal:not([hidden])').pop();
        if (open) { open.hidden = true; document.body.classList.remove("db-modal-open"); return; }
      }
      if (state.view !== "investigation") return;
      if (/^[1-9]$/.test(event.key)) {
        const character = CASE.characters[Number(event.key) - 1];
        if (character) { state.case.selectedCharacter = character.id; renderCase(); }
      }
      if (event.key.toLowerCase() === "p") { state.case.tool = "place"; renderCase(); }
      if (event.key.toLowerCase() === "x") { state.case.tool = "x"; renderCase(); }
      if (event.key.toLowerCase() === "c") { state.case.tool = "candidate"; renderCase(); }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") { event.preventDefault(); event.shiftKey ? redo() : undo(); }
    });
    window.addEventListener("pagehide", pauseClock);
  }

  document.addEventListener("DOMContentLoaded", () => {
    bind();
    renderRuleStep(1);
    selectCase(state.activeCaseId, { runDiagnostics: false });
    startTimer();
    setView("home");
    runDiagnostics();
  });
})();
