(() => {
  "use strict";
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  const clone=v=>JSON.parse(JSON.stringify(v));
  const CASES={"case-001":window.DETECTIVE_BLACK_CASE_001,"case-002":window.DETECTIVE_BLACK_CASE_002,"case-003":window.DETECTIVE_BLACK_CASE_003,"case-004":window.DETECTIVE_BLACK_CASE_004,"case-005":window.DETECTIVE_BLACK_CASE_005,"case-006":window.DETECTIVE_BLACK_CASE_006};
  let currentId="case-001", data=clone(CASES[currentId]), history=[], selectedClues=[];
  const colorFor=(index)=>["#66727c","#7b665a","#675c72","#666861","#5f7270","#745d55","#496f91","#755482","#56735f"][index%9];
  const cellMap=()=>new Map((data.cells||[]).map(c=>[c.id,c]));
  const objectMap=()=>new Map((data.objects||[]).map(o=>[o.id,o]));
  const characterMap=()=>new Map((data.characters||[]).map(c=>[c.id,c]));
  function pushHistory(){ history.push(clone(data)); if(history.length>30) history.shift(); }
  function loadCase(id){ currentId=id; data=clone(CASES[id]); history=[]; selectedClues=clone(data.clues||[]); renderAll(); }
  function setMessage(text,tone="neutral"){ const n=$("[data-editor-message]"); if(n){n.textContent=text;n.dataset.tone=tone;} }
  function renderEditorControls(){
    $("[data-editor-title]").textContent=`${data.id.toUpperCase()} / ${data.title}`; $("[data-editor-grid-label]").textContent=`${data.gridSize}×${data.gridSize}`;
    const reg=$("[data-editor-region]"); reg.innerHTML=(data.regions||[]).map(r=>`<option value="${r.id}">${r.name}</option>`).join("");
    const chr=$("[data-editor-character]"); chr.innerHTML=(data.characters||[]).map(c=>`<option value="${c.id}">${c.name}</option>`).join("");
  }
  function renderBoard(){
    const root=$("[data-editor-board]"); root.style.setProperty("--tool-grid",data.gridSize); root.innerHTML="";
    const objects=objectMap(), chars=characterMap(); const solutionReverse=new Map(Object.entries(data.solution||{}).map(([id,cid])=>[cid,id]));
    for(const cell of data.cells||[]){
      const b=document.createElement("button"); b.type="button"; b.className="db-tool-cell"; b.dataset.cell=cell.id;
      const region=data.regions.find(r=>r.id===cell.regionId); b.style.setProperty("--cell-region",region?.accent||"#666");
      if(cell.kind==="blocked") b.classList.add("is-blocked"); if(cell.kind==="object") b.classList.add("is-object");
      const obj=cell.objectId?objects.get(cell.objectId):null; const charId=solutionReverse.get(cell.id); const ch=charId?chars.get(charId):null;
      b.innerHTML=`<span class="db-tool-cell__coord">${cell.row},${cell.col}</span><span class="db-tool-cell__region">${region?.name||cell.regionId}</span>${obj?`<span class="db-tool-cell__object">${obj.label||obj.type}</span>`:""}${ch?`<span class="db-tool-cell__solution" title="${ch.name}">${ch.initial||ch.name[0]}</span>`:""}`;
      root.appendChild(b);
    }
    $("[data-editor-legend]").innerHTML=(data.regions||[]).map(r=>`<span style="--region:${r.accent}">${r.name}</span>`).join("");
  }
  function syncJson(){ $("[data-editor-json]").value=JSON.stringify(data,null,2); }
  function renderClues(){
    const root=$("[data-generated-clues]"); root.innerHTML=selectedClues.map((c,i)=>`<label class="db-clue-item"><input type="checkbox" data-clue-index="${i}" checked><span><strong>${c.text||c.type}</strong><small>${c.type} / ${c.characterId}</small></span></label>`).join("");
    $("[data-generated-count]").textContent=String(selectedClues.length).padStart(2,"0");
  }
  function selectedFromUI(){ const indexes=$$("[data-clue-index]:checked").map(n=>Number(n.dataset.clueIndex)); return indexes.map(i=>selectedClues[i]); }
  function applyCell(cellId){
    const cell=data.cells.find(c=>c.id===cellId); if(!cell)return; pushHistory();
    const tool=$("[data-editor-tool]").value;
    if(tool==="region") cell.regionId=$("[data-editor-region]").value;
    if(tool==="floor"||tool==="blocked") { if(cell.objectId) data.objects=data.objects.filter(o=>o.id!==cell.objectId); cell.objectId=null; cell.kind=tool; }
    if(tool==="object-yes"||tool==="object-no") {
      if(cell.objectId) data.objects=data.objects.filter(o=>o.id!==cell.objectId);
      const id=`obj-${cell.id}-${Date.now().toString(36)}`; const occupiable=tool==="object-yes";
      data.objects.push({id,type:$("[data-editor-object-type]").value.trim()||"object",label:$("[data-editor-object-label]").value.trim()||"Objeto",occupiable,cellId:cell.id});
      cell.objectId=id; cell.kind=occupiable?"object":"blocked";
    }
    if(tool==="solution") { const charId=$("[data-editor-character]").value; data.solution[charId]=cell.id; }
    renderBoard(); syncJson(); setMessage(`Cambio aplicado en ${cell.id}.`,"success");
  }
  function renderAnalysis(){
    const solver=new window.DetectiveBlackSolver(data); const report=solver.diagnose();
    const necessity=report.clueNecessity||[]; const essential=necessity.filter(x=>x.essential).length;
    const vals={schema:report.schemaErrors.length?`${report.schemaErrors.length} ERR`:"VALID",solutions:String(report.solutionCount),difficulty:report.difficulty.label,human:report.human.solved?`${report.human.steps.length} STEPS`:"OPEN",nodes:String(report.searchStats.nodes),essential:`${essential}/${(data.clues||[]).length}`};
    Object.entries(vals).forEach(([k,v])=>{const n=$(`[data-tool-metric="${k}"]`);if(n)n.textContent=v;});
    $("[data-difficulty-score]").textContent=`SCORE ${report.difficulty.score}`;
    $("[data-human-steps]").innerHTML=report.human.steps.length?report.human.steps.map((s,i)=>`<li><strong>${String(i+1).padStart(2,"0")} / ${s.technique}</strong>${characterMap().get(s.characterId)?.name||s.characterId} → ${s.cellId}<br>${s.reason}</li>`).join(""):"<li>No se ha producido una cadena completa con las técnicas activas.</li>";
    const bars=[['Candidatos medios',report.difficulty.averageInitialCandidates,12],['Pasos humanos',report.difficulty.humanStepCount,12],['Pistas relacionales',report.difficulty.relationalClues,8],['Pistas negativas',report.difficulty.negativeClues,8],['Nodos de búsqueda',Math.min(report.searchStats.nodes,500),500]];
    $("[data-analysis-bars]").innerHTML=bars.map(([l,v,m])=>`<div><span>${l}</span><i style="width:${Math.max(3,Math.min(100,(v/m)*100))}%"></i><b>${v}</b></div>`).join("");
    $("[data-analysis-json]").textContent=JSON.stringify(report.difficulty,null,2);
    return report;
  }
  function buildReport(report){
    const necessity=report.clueNecessity||[]; const essential=necessity.filter(x=>x.essential).length;
    const lines=[
      `DETECTIVE BLACK // CASE TOOLING v0.5`,`CASE: ${data.id} / ${data.title}`,`STATUS: ${data.productionStatus||"playable"}`,`GRID: ${data.gridSize}×${data.gridSize}`,``,
      `SCHEMA: ${report.schemaErrors.length?"FAIL":"VALID"}`,`SOLUTION DECLARED: ${report.solutionValidation.valid?"VALID":"FAIL"}`,`SOLUTIONS FOUND: ${report.solutionCount}`,`UNIQUENESS: ${report.unique?"CONFIRMED":"FAILED"}`,`MURDERER RULE: ${report.murdererId||"—"}`,`SEARCH NODES: ${report.searchStats.nodes}`,``,
      `DIFFICULTY SCORE: ${report.difficulty.score}`,`DIFFICULTY LABEL: ${report.difficulty.label}`,`HEURISTIC LABEL: ${report.difficulty.heuristicLabel}`,`AVERAGE INITIAL CANDIDATES: ${report.difficulty.averageInitialCandidates}`,`HUMAN SOLVER: ${report.human.solved?"SOLVED":"INCOMPLETE"}`,`HUMAN STEPS: ${report.human.steps.length}`,``,
      `CLUES: ${(data.clues||[]).length}`,`ESSENTIAL CLUES: ${essential}`, ...necessity.map(n=>`- ${n.clueId}: ${n.essential?"ESSENTIAL":"REDUNDANT"} / solutions without: ${n.solutionsWithout}`),``,
      report.schemaErrors.length?`SCHEMA ERRORS:\n${report.schemaErrors.map(e=>`- ${e}`).join("\n")}`:"NO SCHEMA ERRORS.",
      report.solutionValidation.errors?.length?`SOLUTION ERRORS:\n${report.solutionValidation.errors.map(e=>`- ${e}`).join("\n")}`:"NO SOLUTION ERRORS."
    ];
    const text=lines.join("\n"); $("[data-tool-report]").textContent=text; $("[data-report-case]").textContent=data.id.toUpperCase(); return text;
  }
  function runAll(){ const report=renderAnalysis(); buildReport(report); syncJson(); setMessage(report.unique&&report.solutionValidation.valid?"Build validada: una solución.":"La build requiere revisión.",report.unique?"success":"danger"); return report; }
  function renderAll(){ renderEditorControls(); renderBoard(); syncJson(); selectedClues=clone(data.clues||[]); renderClues(); runAll(); }
  function download(name,text,type="application/json"){ const blob=new Blob([text],{type}); const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500); }
  function bind(){
    $("[data-tool-case]").addEventListener("change",e=>loadCase(e.target.value));
    $$("[data-tool-tab]").forEach(b=>b.addEventListener("click",()=>{$$("[data-tool-tab]").forEach(x=>x.classList.toggle("is-active",x===b));$$("[data-tool-view]").forEach(v=>v.hidden=v.dataset.toolView!==b.dataset.toolTab);}));
    $("[data-editor-board]").addEventListener("click",e=>{const c=e.target.closest("[data-cell]");if(c)applyCell(c.dataset.cell);});
    $("[data-editor-undo]").addEventListener("click",()=>{if(history.length){data=history.pop();renderAll();}});
    $("[data-editor-reset]").addEventListener("click",()=>loadCase(currentId));
    $("[data-editor-sync]").addEventListener("click",syncJson);
    $("[data-import-json]").addEventListener("click",()=>{try{pushHistory();data=JSON.parse($("[data-editor-json]").value);renderAll();setMessage("JSON importado.","success");}catch(err){setMessage(`JSON inválido: ${err.message}`,"danger");}});
    $("[data-copy-json]").addEventListener("click",async()=>{await navigator.clipboard?.writeText($("[data-editor-json]").value);setMessage("JSON copiado.","success");});
    $("[data-download-json]").addEventListener("click",()=>download(`${data.id}-${data.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}.json`,JSON.stringify(data,null,2)));
    $("[data-generate-clues]").addEventListener("click",()=>{selectedClues=new window.DetectiveBlackSolver(data).generateTrueClues();renderClues();});
    $("[data-select-authored]").addEventListener("click",()=>{selectedClues=clone(data.clues||[]);renderClues();});
    $("[data-reduce-clues]").addEventListener("click",()=>{const chosen=selectedFromUI();const result=new window.DetectiveBlackSolver({...clone(data),clues:chosen}).minimizeClues(chosen);$("[data-reduced-count]").textContent=`${result.clues.length}/${chosen.length}`;$("[data-clue-reduction]").textContent=`UNIQUE: ${result.unique?"YES":"NO"}\nKEPT: ${result.clues.map(c=>c.id).join(', ')||'—'}\nREMOVED: ${result.removed.map(c=>c.id).join(', ')||'—'}`;selectedClues=result.clues;renderClues();});
    $("[data-run-all]").addEventListener("click",()=>{runAll();$('[data-tool-tab="report"]').click();});
    $("[data-copy-report]").addEventListener("click",async()=>{await navigator.clipboard?.writeText($("[data-tool-report]").textContent);});
  }
  document.addEventListener("DOMContentLoaded",()=>{bind();renderAll();});
})();
