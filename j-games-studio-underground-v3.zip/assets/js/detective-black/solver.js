(() => {
  "use strict";
  const clone = value => JSON.parse(JSON.stringify(value));

  class DetectiveBlackSolver {
    constructor(caseData, EngineClass = window.DetectiveBlackRuleEngine) {
      this.caseData = caseData;
      this.EngineClass = EngineClass;
      this.engine = new EngineClass(caseData);
      this.lastSearchStats = { nodes: 0, deadEnds: 0 };
    }

    enumerateSolutions(maxSolutions = 2, seed = {}) {
      const characters = (this.caseData.characters || []).map(character => character.id);
      const solutions = [];
      const stats = { nodes: 0, deadEnds: 0 };
      const initial = { ...seed };
      if (!this.engine.checkAssignment(initial, { partial: true }).valid) return [];
      const search = assignment => {
        stats.nodes += 1;
        if (solutions.length >= maxSolutions) return;
        if (Object.keys(assignment).filter(id => assignment[id]).length === characters.length) {
          const validation = this.engine.validateSolution(assignment, { requireDeclaredMurderer: false });
          if (validation.valid) solutions.push({ ...assignment }); else stats.deadEnds += 1;
          return;
        }
        const remaining = characters.filter(id => !assignment[id]);
        const ranked = remaining.map(id => ({ id, candidates: this.engine.candidateCellsFor(id, assignment) })).sort((a,b) => a.candidates.length - b.candidates.length || a.id.localeCompare(b.id));
        const next = ranked[0];
        if (!next || !next.candidates.length) { stats.deadEnds += 1; return; }
        for (const cellId of next.candidates) {
          assignment[next.id] = cellId;
          if (this.engine.checkAssignment(assignment, { partial: true }).valid) search(assignment);
          delete assignment[next.id];
          if (solutions.length >= maxSolutions) break;
        }
      };
      search(initial);
      this.lastSearchStats = stats;
      return solutions;
    }

    hasSolution(seed = {}) { return this.enumerateSolutions(1, seed).length === 1; }

    viableCandidates(characterId, assignment = {}) {
      return this.engine.candidateCellsFor(characterId, assignment).filter(cellId => this.hasSolution({ ...assignment, [characterId]: cellId }));
    }

    humanSolve() {
      const characters = (this.caseData.characters || []).map(character => character.id);
      const assignment = {};
      const steps = [];
      const unresolved = new Set(characters);
      while (unresolved.size) {
        let placed = false;
        const domains = [...unresolved].map(id => ({ id, candidates: this.engine.candidateCellsFor(id, assignment) })).sort((a,b) => a.candidates.length - b.candidates.length || a.id.localeCompare(b.id));
        const contradiction = domains.find(entry => entry.candidates.length === 0);
        if (contradiction) return { solved:false, assignment, unresolved:[...unresolved], steps, contradiction:`${contradiction.id} no tiene candidatos.` };

        const single = domains.find(entry => entry.candidates.length === 1);
        if (single) {
          assignment[single.id] = single.candidates[0]; unresolved.delete(single.id);
          steps.push({ type:"direct-single", technique:"Candidato único", characterId:single.id, cellId:single.candidates[0], candidatesBefore:1, reason:"Solo queda una casilla compatible con las pistas y los bloqueos actuales." });
          placed = true;
        }
        if (placed) continue;

        // Hidden single by row or column: only one character can occupy the unit and only one cell remains for it there.
        for (const axis of ["row", "col"]) {
          for (let unit=1; unit<=this.caseData.gridSize && !placed; unit++) {
            const possible = domains.map(entry => ({ ...entry, cells:entry.candidates.filter(cid => this.engine.cells.get(cid)?.[axis] === unit) })).filter(entry => entry.cells.length);
            if (possible.length === 1 && possible[0].cells.length === 1) {
              const entry=possible[0]; assignment[entry.id]=entry.cells[0]; unresolved.delete(entry.id);
              steps.push({ type:`hidden-${axis}`, technique:axis === "row" ? "Único sujeto de la fila" : "Único sujeto de la columna", characterId:entry.id, cellId:entry.cells[0], reason:`Solo ${entry.id} puede ocupar la ${axis === "row" ? "fila" : "columna"} ${unit}.` });
              placed=true;
            }
          }
        }
        if (placed) continue;

        // Controlled contradiction: test the smallest domain and keep candidates that can extend to a complete solution.
        const target = domains[0];
        const viable = target.candidates.filter(cellId => this.hasSolution({ ...assignment, [target.id]: cellId }));
        if (viable.length === 1) {
          assignment[target.id] = viable[0]; unresolved.delete(target.id);
          steps.push({ type:"forced-by-contradiction", technique:"Contradicción controlada", characterId:target.id, cellId:viable[0], candidatesBefore:target.candidates.length, rejected:target.candidates.filter(id => id !== viable[0]), reason:"Las demás posiciones conducen a una escena sin solución completa." });
          continue;
        }
        break;
      }
      return { solved: unresolved.size === 0 && this.engine.validateSolution(assignment).valid, assignment, unresolved:[...unresolved], steps };
    }

    generateTrueClues(options = {}) {
      const solution = this.caseData.solution || {};
      const clues = [];
      const push = clue => { if (!clues.some(existing => JSON.stringify({ ...existing, id:undefined, text:undefined }) === JSON.stringify({ ...clue, id:undefined, text:undefined }))) clues.push(clue); };
      const cellFor = id => this.engine.cells.get(solution[id]);
      const nameFor = id => this.engine.characters.get(id)?.name || id;
      const objectForCell = cell => cell?.objectId ? this.engine.objects.get(cell.objectId) : null;
      let serial = 1;
      for (const character of this.caseData.characters || []) {
        const cell = cellFor(character.id); if (!cell) continue;
        const object = objectForCell(cell);
        if (object) {
          push({ id:`generated-${serial++}`, type:"onObject", characterId:character.id, objectId:object.id, text:`${nameFor(character.id)} estaba sobre ${object.label || object.type}.`, source:"solution" });
          if ((this.caseData.objects || []).filter(entry => entry.type === object.type && entry.occupiable !== false).length > 1) {
            push({ id:`generated-${serial++}`, type:"onObjectType", characterId:character.id, objectType:object.type, text:`${nameFor(character.id)} estaba sobre uno de los objetos de tipo ${object.type}.`, source:"solution" });
          }
        }
        push({ id:`generated-${serial++}`, type:"inRegion", characterId:character.id, regionId:cell.regionId, text:`${nameFor(character.id)} estaba en ${this.engine.regions.get(cell.regionId)?.name || cell.regionId}.`, source:"solution" });
        const occupants = Object.entries(solution).filter(([,cid]) => this.engine.cells.get(cid)?.regionId === cell.regionId);
        if (occupants.length === 1) push({ id:`generated-${serial++}`, type:"aloneInRegion", characterId:character.id, regionId:cell.regionId, text:`${nameFor(character.id)} estaba a solas en ${this.engine.regions.get(cell.regionId)?.name || cell.regionId}.`, source:"solution" });
        for (const objectEntry of this.caseData.objects || []) {
          const target = this.engine.objectCells.get(objectEntry.id);
          if (target && this.engine.manhattan(cell,target) === 1 && this.engine.sameRegion(cell,target)) {
            push({ id:`generated-${serial++}`, type:"besideObject", characterId:character.id, objectId:objectEntry.id, text:`${nameFor(character.id)} estaba junto a ${objectEntry.label || objectEntry.type}.`, source:"solution" });
            if ((this.caseData.objects || []).filter(entry => entry.type === objectEntry.type).length > 1) push({ id:`generated-${serial++}`, type:"besideObjectType", characterId:character.id, objectType:objectEntry.type, text:`${nameFor(character.id)} estaba junto a un objeto de tipo ${objectEntry.type}.`, source:"solution" });
          }
        }
      }
      const chars = this.caseData.characters || [];
      for (let i=0;i<chars.length;i++) for (let j=i+1;j<chars.length;j++) {
        const a=chars[i], b=chars[j], ca=cellFor(a.id), cb=cellFor(b.id); if(!ca||!cb) continue;
        if (ca.regionId === cb.regionId) push({ id:`generated-${serial++}`, type:"sameRegionAs", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} estaba en la misma zona que ${nameFor(b.id)}.`, source:"solution" });
        else if (options.includeNegativeRelations) push({ id:`generated-${serial++}`, type:"notSameRegionAs", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} no compartía zona con ${nameFor(b.id)}.`, source:"solution" });
        if (ca.row < cb.row) push({ id:`generated-${serial++}`, type:"northOf", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} estaba más al norte que ${nameFor(b.id)}.`, source:"solution" });
        if (ca.row > cb.row) push({ id:`generated-${serial++}`, type:"southOf", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} estaba más al sur que ${nameFor(b.id)}.`, source:"solution" });
        if (ca.col < cb.col) push({ id:`generated-${serial++}`, type:"westOf", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} estaba más al oeste que ${nameFor(b.id)}.`, source:"solution" });
        if (ca.col > cb.col) push({ id:`generated-${serial++}`, type:"eastOf", characterId:a.id, otherCharacterId:b.id, text:`${nameFor(a.id)} estaba más al este que ${nameFor(b.id)}.`, source:"solution" });
      }
      return clues;
    }

    minimizeClues(clues = this.caseData.clues || []) {
      const working = clues.map(clone);
      const removed=[];
      let index=0;
      while(index < working.length) {
        const test=working.slice(0,index).concat(working.slice(index+1));
        const testCase={...clone(this.caseData), clues:test};
        const solutions=new DetectiveBlackSolver(testCase,this.EngineClass).enumerateSolutions(2);
        if(solutions.length===1) { removed.push(working[index]); working.splice(index,1); }
        else index += 1;
      }
      return { clues:working, removed, unique:new DetectiveBlackSolver({...clone(this.caseData),clues:working},this.EngineClass).enumerateSolutions(2).length===1 };
    }

    clueNecessityReport(clues = this.caseData.clues || []) {
      return clues.map((clue,index) => {
        const reduced=clues.filter((_,i)=>i!==index);
        const count=new DetectiveBlackSolver({...clone(this.caseData),clues:reduced},this.EngineClass).enumerateSolutions(3).length;
        return { clueId:clue.id, essential:count!==1, solutionsWithout:count };
      });
    }

    buildExplanation(human = this.humanSolve()) {
      const charMap=new Map((this.caseData.characters||[]).map(c=>[c.id,c]));
      return human.steps.map((step,index)=>({
        step:index+1, characterId:step.characterId, cellId:step.cellId,
        title:step.technique,
        text:`${charMap.get(step.characterId)?.name || step.characterId} queda en ${String(step.cellId).replace(/r(\d+)c(\d+)/,'F$1-C$2')}. ${step.reason}`,
        technique:step.type
      }));
    }

    analyzeDifficulty() {
      const characters=(this.caseData.characters||[]).map(c=>c.id);
      const initial=characters.map(id=>this.engine.candidateCellsFor(id,{}).length);
      const human=this.humanSolve();
      const types={}; human.steps.forEach(step=>{types[step.type]=(types[step.type]||0)+1;});
      const negatives=(this.caseData.clues||[]).filter(c=>String(c.type).startsWith('not')).length;
      const relational=(this.caseData.clues||[]).filter(c=>c.otherCharacterId).length;
      const avg=initial.length ? initial.reduce((a,b)=>a+b,0)/initial.length : 0;
      const score=Math.max(0,Math.round(Math.max(0,avg-6)*2 + Math.max(0,human.steps.length-5)*2 + (types['forced-by-contradiction']||0)*5 + negatives*4 + relational*2 + human.unresolved.length*25 - initial.filter(v=>v===1).length*3));
      let heuristicLabel='MUY FÁCIL'; if(score>=35) heuristicLabel='FÁCIL'; if(score>=60) heuristicLabel='NORMAL'; if(score>=90) heuristicLabel='DIFÍCIL'; if(score>=120) heuristicLabel='EXPERTO';
      const declaredLabels={"muy-facil":"MUY FÁCIL","facil":"FÁCIL","normal":"NORMAL","dificil":"DIFÍCIL","experto":"EXPERTO"};
      const label=declaredLabels[this.caseData.difficulty] || heuristicLabel;
      return { averageInitialCandidates:Number(avg.toFixed(2)), minInitialCandidates:Math.min(...initial), maxInitialCandidates:Math.max(...initial), directPlacements:initial.filter(v=>v===1).length, humanStepCount:human.steps.length, humanSolved:human.solved, unresolvedAfterHuman:human.unresolved.length, techniques:types, negativeClues:negatives, relationalClues:relational, score, label, heuristicLabel };
    }

    diagnose() {
      const schemaErrors=this.engine.validateSchema();
      const solutionValidation=this.engine.validateSolution();
      const solutions=schemaErrors.length ? [] : this.enumerateSolutions(3);
      const searchStats={...this.lastSearchStats};
      const human=this.humanSolve();
      return { schemaErrors, solutionValidation, solutionCount:solutions.length, unique:solutions.length===1, murdererId:solutionValidation.murder?.murdererId||null, human, difficulty:this.analyzeDifficulty(), clueNecessity:this.clueNecessityReport(), searchStats };
    }
  }
  window.DetectiveBlackSolver = DetectiveBlackSolver;
})();
