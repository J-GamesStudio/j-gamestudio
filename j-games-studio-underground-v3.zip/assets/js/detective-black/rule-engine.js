(() => {
  "use strict";

  class DetectiveBlackRuleEngine {
    constructor(caseData) {
      this.caseData = caseData || {};
      this.cells = new Map((this.caseData.cells || []).map(cell => [cell.id, cell]));
      this.objects = new Map((this.caseData.objects || []).map(object => [object.id, object]));
      this.characters = new Map((this.caseData.characters || []).map(character => [character.id, character]));
      this.regions = new Map((this.caseData.regions || []).map(region => [region.id, region]));
      this.objectCells = new Map();
      for (const object of this.objects.values()) this.objectCells.set(object.id, this.cells.get(object.cellId));
    }

    validateSchema() {
      const errors = [];
      const data = this.caseData;
      const required = ["schemaVersion", "id", "title", "difficulty", "gridSize", "victimId", "regions", "cells", "objects", "characters", "clues", "solution", "murdererId"];
      required.forEach(key => { if (!(key in data)) errors.push(`Falta el campo obligatorio: ${key}`); });
      if (!Number.isInteger(data.gridSize) || data.gridSize < 4 || data.gridSize > 9) errors.push("gridSize debe ser un entero entre 4 y 9.");
      if ((data.characters || []).length !== data.gridSize) errors.push("El número de personajes debe coincidir con el tamaño del tablero.");
      if ((data.cells || []).length !== data.gridSize * data.gridSize) errors.push("El tablero debe declarar exactamente N×N casillas.");

      const assertUnique = (items, label) => {
        const seen = new Set();
        for (const item of items || []) {
          if (!item?.id) { errors.push(`${label} sin id.`); continue; }
          if (seen.has(item.id)) errors.push(`${label} duplicado: ${item.id}`);
          seen.add(item.id);
        }
      };
      assertUnique(data.regions, "Región");
      assertUnique(data.cells, "Casilla");
      assertUnique(data.objects, "Objeto");
      assertUnique(data.characters, "Personaje");
      assertUnique(data.clues, "Pista");

      if (!this.characters.has(data.victimId)) errors.push("victimId no referencia un personaje válido.");
      if (!this.characters.has(data.murdererId)) errors.push("murdererId no referencia un personaje válido.");
      const coordinates = new Set();
      for (const cell of data.cells || []) {
        const key = `${cell.row}:${cell.col}`;
        if (coordinates.has(key)) errors.push(`Coordenada duplicada: F${cell.row}-C${cell.col}.`);
        coordinates.add(key);
        if (!Number.isInteger(cell.row) || cell.row < 1 || cell.row > data.gridSize || !Number.isInteger(cell.col) || cell.col < 1 || cell.col > data.gridSize) errors.push(`Coordenada fuera del tablero en ${cell.id}.`);
        if (!this.regions.has(cell.regionId)) errors.push(`Región desconocida en ${cell.id}: ${cell.regionId}`);
        if (cell.objectId && !this.objects.has(cell.objectId)) errors.push(`Objeto desconocido en ${cell.id}: ${cell.objectId}`);
      }
      for (const object of data.objects || []) {
        const cell = this.cells.get(object.cellId);
        if (!cell) errors.push(`El objeto ${object.id} apunta a una casilla inexistente.`);
        else if (cell.objectId !== object.id) errors.push(`La casilla ${object.cellId} no referencia de vuelta al objeto ${object.id}.`);
      }
      for (const clue of data.clues || []) {
        if (!this.characters.has(clue.characterId)) errors.push(`La pista ${clue.id} usa un personaje desconocido.`);
        if (clue.otherCharacterId && !this.characters.has(clue.otherCharacterId)) errors.push(`La pista ${clue.id} usa otro personaje desconocido.`);
        if (clue.objectId && !this.objects.has(clue.objectId)) errors.push(`La pista ${clue.id} usa un objeto desconocido.`);
        if (clue.objectType && ![...this.objects.values()].some(object => object.type === clue.objectType)) errors.push(`La pista ${clue.id} usa un tipo de objeto desconocido: ${clue.objectType}.`);
        if (clue.regionId && !this.regions.has(clue.regionId)) errors.push(`La pista ${clue.id} usa una región desconocida.`);
      }
      const solution = data.solution || {};
      for (const character of data.characters || []) {
        if (!solution[character.id]) errors.push(`La solución no contiene a ${character.id}.`);
        else if (!this.cells.has(solution[character.id])) errors.push(`La solución de ${character.id} apunta a una casilla inexistente.`);
      }
      return errors;
    }

    isOccupable(cellId) {
      const cell = this.cells.get(cellId);
      if (!cell) return false;
      if (["blocked", "wall", "out"].includes(cell.kind)) return false;
      if (!cell.objectId) return true;
      const object = this.objects.get(cell.objectId);
      return !object || object.occupiable !== false;
    }

    getOccupableCells() { return [...this.cells.values()].filter(cell => this.isOccupable(cell.id)); }
    manhattan(a, b) { return (!a || !b) ? Number.POSITIVE_INFINITY : Math.abs(a.row - b.row) + Math.abs(a.col - b.col); }
    sameRegion(a, b) { return Boolean(a && b && a.regionId === b.regionId); }

    evaluateClue(clue, assignment, partial = true) {
      const cellId = assignment[clue.characterId];
      const cell = cellId ? this.cells.get(cellId) : null;
      if (!cell) return partial;
      const targetCell = clue.objectId ? this.objectCells.get(clue.objectId) : null;
      const otherId = clue.otherCharacterId;
      const otherCell = otherId && assignment[otherId] ? this.cells.get(assignment[otherId]) : null;
      switch (clue.type) {
        case "onObject": return cell.objectId === clue.objectId;
        case "onObjectType": return Boolean(cell.objectId && this.objects.get(cell.objectId)?.type === clue.objectType);
        case "notOnObjectType": return !(cell.objectId && this.objects.get(cell.objectId)?.type === clue.objectType);
        case "inRegion": return cell.regionId === clue.regionId;
        case "notInRegion": return cell.regionId !== clue.regionId;
        case "row": return cell.row === clue.row;
        case "column": return cell.col === clue.col;
        case "besideObject": return this.manhattan(cell, targetCell) === 1 && this.sameRegion(cell, targetCell);
        case "notBesideObject": return !(this.manhattan(cell, targetCell) === 1 && this.sameRegion(cell, targetCell));
        case "besideObjectType": return [...this.objects.values()].some(object => object.type === clue.objectType && this.manhattan(cell, this.objectCells.get(object.id)) === 1 && this.sameRegion(cell, this.objectCells.get(object.id)));
        case "notBesideObjectType": return ![...this.objects.values()].some(object => object.type === clue.objectType && this.manhattan(cell, this.objectCells.get(object.id)) === 1 && this.sameRegion(cell, this.objectCells.get(object.id)));
        case "sameRegionAs": return otherCell ? this.sameRegion(cell, otherCell) : partial;
        case "notSameRegionAs": return otherCell ? !this.sameRegion(cell, otherCell) : partial;
        case "northOf": return otherCell ? cell.row < otherCell.row && (!clue.sameColumn || cell.col === otherCell.col) : partial;
        case "southOf": return otherCell ? cell.row > otherCell.row && (!clue.sameColumn || cell.col === otherCell.col) : partial;
        case "westOf": return otherCell ? cell.col < otherCell.col && (!clue.sameRow || cell.row === otherCell.row) : partial;
        case "eastOf": return otherCell ? cell.col > otherCell.col && (!clue.sameRow || cell.row === otherCell.row) : partial;
        case "aloneInRegion": {
          if (clue.regionId && cell.regionId !== clue.regionId) return false;
          for (const [characterId, assignedCellId] of Object.entries(assignment)) {
            if (characterId === clue.characterId || !assignedCellId) continue;
            const assignedCell = this.cells.get(assignedCellId);
            if (assignedCell && assignedCell.regionId === cell.regionId) return false;
          }
          return true;
        }
        default: return true;
      }
    }

    checkAssignment(assignment, options = {}) {
      const partial = options.partial !== false;
      const errors = [];
      const rows = new Map(), cols = new Map(), occupied = new Map();
      for (const [characterId, cellId] of Object.entries(assignment || {})) {
        if (!cellId) continue;
        if (!this.characters.has(characterId)) errors.push(`Personaje desconocido: ${characterId}`);
        const cell = this.cells.get(cellId);
        if (!cell) { errors.push(`Casilla inexistente: ${cellId}`); continue; }
        if (!this.isOccupable(cellId)) errors.push(`${characterId} ocupa una casilla bloqueada (${cellId}).`);
        if (occupied.has(cellId)) errors.push(`${characterId} comparte casilla con ${occupied.get(cellId)}.`);
        occupied.set(cellId, characterId);
        if (rows.has(cell.row)) errors.push(`${characterId} comparte la fila ${cell.row} con ${rows.get(cell.row)}.`); else rows.set(cell.row, characterId);
        if (cols.has(cell.col)) errors.push(`${characterId} comparte la columna ${cell.col} con ${cols.get(cell.col)}.`); else cols.set(cell.col, characterId);
      }
      for (const clue of this.caseData.clues || []) if (!this.evaluateClue(clue, assignment, partial)) errors.push(`Pista incumplida: ${clue.id || clue.type}`);
      if (!partial) for (const characterId of this.characters.keys()) if (!assignment[characterId]) errors.push(`Falta colocar a ${characterId}.`);
      return { valid: errors.length === 0, errors };
    }

    candidateCellsFor(characterId, assignment = {}) {
      return this.getOccupableCells().filter(cell => this.checkAssignment({ ...assignment, [characterId]: cell.id }, { partial: true }).valid).map(cell => cell.id);
    }

    findMurderer(assignment) {
      const victimCell = this.cells.get(assignment[this.caseData.victimId]);
      if (!victimCell) return { murdererId: null, occupants: [], valid: false };
      const occupants = Object.entries(assignment).filter(([, cellId]) => this.cells.get(cellId)?.regionId === victimCell.regionId).map(([characterId]) => characterId);
      const suspects = occupants.filter(id => id !== this.caseData.victimId);
      return { murdererId: suspects.length === 1 ? suspects[0] : null, occupants, valid: suspects.length === 1 };
    }

    validateSolution(solution = this.caseData.solution, options = {}) {
      const result = this.checkAssignment(solution, { partial: false });
      const murder = this.findMurderer(solution);
      if (!murder.valid) result.errors.push("El área de la víctima no contiene exactamente a una persona más.");
      else if (options.requireDeclaredMurderer !== false && murder.murdererId !== this.caseData.murdererId) result.errors.push("El culpable deducido no coincide con murdererId.");
      result.valid = result.errors.length === 0;
      result.murder = murder;
      return result;
    }
  }
  window.DetectiveBlackRuleEngine = DetectiveBlackRuleEngine;
})();
