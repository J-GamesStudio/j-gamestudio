(() => {
  const STORAGE_KEY = "jgs-cartas-state";
  const BONUS_PACK_KEY = "jgs-bonus-packs";
  const PACK_COST = 100;
  const STARTING_COINS = 1000;
  const root = document.body.dataset.root || "../../";
  const markPath = `${root}assets/icons/mark.svg`;

  const rarityConfig = {
    common: { key: "common", label: "Común", color: "#8f949c", value: 15, short: "C" },
    uncommon: { key: "uncommon", label: "Poco común", color: "#58ce76", value: 30, short: "UC" },
    rare: { key: "rare", label: "Raro", color: "#49acff", value: 80, short: "R" },
    epic: { key: "epic", label: "Épico", color: "#b46bff", value: 220, short: "EP" },
    legendary: { key: "legendary", label: "Legendario", color: "#f0c45a", value: 600, short: "LG" }
  };

  const rarityNames = {
    common: "Carta común",
    uncommon: "Carta poco común",
    rare: "Carta rara",
    epic: "Carta épica",
    legendary: "Carta legendaria"
  };

  const romans = ["I", "II", "III", "IV", "V"];
  const pool = [];
  const poolByRarity = { common: [], uncommon: [], rare: [], epic: [], legendary: [] };
  const cardIndex = new Map();
  let serial = 1;

  ["common", "uncommon", "rare", "epic", "legendary"].forEach(rarity => {
    romans.forEach((roman, index) => {
      const card = {
        id: `jgs-${String(serial).padStart(3, "0")}`,
        number: serial,
        serial: `JGS-${String(serial).padStart(3, "0")}`,
        name: `${rarityNames[rarity]} ${roman}`,
        rarity,
        value: rarityConfig[rarity].value,
        edition: "1ª Edición",
        pattern: index % 5
      };
      pool.push(card);
      poolByRarity[rarity].push(card);
      cardIndex.set(card.id, card);
      serial += 1;
    });
  });

  const ui = {
    balance: document.getElementById("jcoin-balance"),
    wallet: document.getElementById("wallet-value"),
    ownedTotal: document.getElementById("owned-total"),
    bonusCount: document.getElementById("bonus-packs-count"),
    bonusInline: document.getElementById("bonus-packs-inline"),
    uniqueOwned: document.getElementById("unique-owned"),
    collectionValue: document.getElementById("collection-value"),
    pageIndicator: document.getElementById("album-page-indicator"),
    buyPack: document.getElementById("buy-pack-button"),
    openPack: document.getElementById("open-pack-button"),
    revealAll: document.getElementById("reveal-all-button"),
    boosterDisplay: document.getElementById("booster-display"),
    packMessage: document.getElementById("pack-message"),
    packSubmessage: document.getElementById("pack-submessage"),
    packCards: document.getElementById("pack-cards"),
    packSlots: Array.from(document.querySelectorAll(".pack-slot")),
    albumGrid: document.getElementById("album-grid"),
    albumPrev: document.getElementById("album-prev"),
    albumNext: document.getElementById("album-next"),
    detailCard: document.getElementById("detail-card"),
    detailName: document.getElementById("detail-name"),
    detailRarity: document.getElementById("detail-rarity"),
    detailSerial: document.getElementById("detail-serial"),
    detailValue: document.getElementById("detail-value"),
    detailCount: document.getElementById("detail-count"),
    sellOne: document.getElementById("sell-one-button"),
    sellDupes: document.getElementById("sell-dupes-button"),
    tabs: Array.from(document.querySelectorAll("[data-panel-target]")),
    panels: Array.from(document.querySelectorAll("[data-panel]"))
  };

  const defaultState = () => ({
    coins: STARTING_COINS,
    collection: {},
    totalOpened: 0,
    totalSold: 0,
    albumPage: 0,
    selectedCardId: pool[0].id,
    stage: "idle",
    pendingPack: [],
    revealed: [false, false, false],
    storedCurrentPack: false
  });

  const loadState = () => {
    try {
      const parsed = window.JGS_ECONOMY
        ? window.JGS_ECONOMY.getCartasState(defaultState())
        : JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!parsed || typeof parsed !== "object") return defaultState();
      return {
        coins: Number.isFinite(parsed.coins) ? parsed.coins : STARTING_COINS,
        collection: parsed.collection && typeof parsed.collection === "object" ? parsed.collection : {},
        totalOpened: Number.isFinite(parsed.totalOpened) ? parsed.totalOpened : 0,
        totalSold: Number.isFinite(parsed.totalSold) ? parsed.totalSold : 0,
        albumPage: Number.isFinite(parsed.albumPage) ? parsed.albumPage : 0,
        selectedCardId: typeof parsed.selectedCardId === "string" ? parsed.selectedCardId : pool[0].id,
        stage: typeof parsed.stage === "string" ? parsed.stage : "idle",
        pendingPack: Array.isArray(parsed.pendingPack) ? parsed.pendingPack : [],
        revealed: Array.isArray(parsed.revealed) && parsed.revealed.length === 3 ? parsed.revealed.map(Boolean) : [false, false, false],
        storedCurrentPack: Boolean(parsed.storedCurrentPack)
      };
    } catch {
      return defaultState();
    }
  };

  let state = loadState();
  let stage = state.stage || "idle";
  let currentPack = (state.pendingPack || []).map(cardId => cardIndex.get(cardId)).filter(Boolean);
  let revealed = Array.isArray(state.revealed) ? state.revealed.map(Boolean) : [false, false, false];
  let storedCurrentPack = Boolean(state.storedCurrentPack);
  let tearTimer = null;

  if (stage === "tearing") stage = currentPack.length ? "ready" : "idle";

  function persist() {
    const payload = {
      ...state,
      stage,
      pendingPack: currentPack.map(card => card.id),
      revealed,
      storedCurrentPack
    };
    if (window.JGS_ECONOMY) {
      window.JGS_ECONOMY.saveCartasState(payload);
    } else {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    }
  }

  function getCard(cardId) {
    return cardIndex.get(cardId) || pool[0];
  }

  function getBonusPacks() {
    if (window.JGS_ECONOMY) return window.JGS_ECONOMY.getBonusPacks();
    const parsed = Number.parseInt(localStorage.getItem(BONUS_PACK_KEY) || "0", 10);
    return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
  }

  function setBonusPacks(value) {
    if (window.JGS_ECONOMY) {
      window.JGS_ECONOMY.setBonusPacks(value);
      return;
    }
    localStorage.setItem(BONUS_PACK_KEY, String(Math.max(0, value)));
  }

  function totalOwned() {
    return Object.values(state.collection).reduce((sum, amount) => sum + Number(amount || 0), 0);
  }

  function uniqueOwned() {
    return Object.values(state.collection).filter(amount => Number(amount || 0) > 0).length;
  }

  function collectionValue() {
    return pool.reduce((sum, card) => sum + ((state.collection[card.id] || 0) * card.value), 0);
  }

  function randomFrom(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function weightedPremiumRarity() {
    const roll = Math.random() * 100;
    if (roll < 72) return "uncommon";
    if (roll < 90) return "rare";
    if (roll < 98) return "epic";
    return "legendary";
  }

  function generatePack() {
    return [
      randomFrom(poolByRarity.common),
      randomFrom(poolByRarity.common),
      randomFrom(poolByRarity[weightedPremiumRarity()])
    ];
  }

  function rarityLabel(key) {
    return rarityConfig[key]?.label || key;
  }

  function countCopies(cardId) {
    return state.collection[cardId] || 0;
  }

  function updateEconomy() {
    const coinsText = String(state.coins);
    const total = totalOwned();
    const unique = uniqueOwned();
    const bonusText = String(getBonusPacks());
    if (ui.balance) ui.balance.textContent = coinsText;
    if (ui.wallet) ui.wallet.textContent = coinsText;
    if (ui.ownedTotal) ui.ownedTotal.textContent = String(total);
    if (ui.bonusCount) ui.bonusCount.textContent = bonusText;
    if (ui.bonusInline) ui.bonusInline.textContent = bonusText;
    if (ui.uniqueOwned) ui.uniqueOwned.textContent = `${unique} / ${pool.length}`;
    if (ui.collectionValue) ui.collectionValue.textContent = `${collectionValue()} JCOIN`;
    if (ui.buyPack) {
      const bonusPacks = getBonusPacks();
      ui.buyPack.textContent = bonusPacks > 0 ? `Usar sobre bonus (${bonusPacks})` : (stage === "resolved" ? "Comprar otro sobre" : "Comprar sobre");
    }
  }

  function setPackMessage(message, submessage) {
    ui.packMessage.textContent = message;
    ui.packSubmessage.textContent = submessage;
  }

  function cardBackHtml(index) {
    return `
      <button type="button" class="card-face card-back" data-reveal-card="${index}" aria-label="Revelar carta ${index + 1}">
        <div class="card-back__frame">
          <img src="${markPath}" alt="">
          <strong>J-GAMES STUDIO</strong>
          <span>1ª EDICIÓN · DEMO SET</span>
        </div>
      </button>`;
  }

  function cardFaceHtml(card, count = 0) {
    const rarity = rarityConfig[card.rarity];
    return `
      <article class="jcard jcard--${card.rarity}">
        <div class="jcard__frame">
          <div class="jcard__top">
            <span class="jcard__rarity">${rarity.label}</span>
            <span class="jcard__edition">${card.edition}</span>
          </div>
          <div class="jcard__art" data-pattern="${card.pattern}">
            <div class="jcard__sigil">${rarity.short}</div>
            <div class="jcard__serial-overlay">${card.serial}</div>
          </div>
          <div class="jcard__body">
            <h3>${card.name}</h3>
            <p>${card.serial} · DEMO SET</p>
          </div>
          <div class="jcard__bottom">
            <span>${card.value} JCOIN</span>
            <span class="jcard__count">x${count}</span>
          </div>
        </div>
      </article>`;
  }

  function packCardHtml(card, index) {
    return `
      <div class="card-shell ${revealed[index] ? "is-revealed" : ""}" data-card-shell>
        <div class="card-shell__inner">
          ${cardBackHtml(index)}
          <div class="card-face card-front">${cardFaceHtml(card, 1)}</div>
        </div>
      </div>`;
  }

  function renderOpening() {
    const config = {
      idle: { buy: true, open: false, reveal: false, board: "is-idle" },
      sealed: { buy: false, open: true, reveal: false, board: "is-sealed" },
      tearing: { buy: false, open: false, reveal: false, board: "is-tearing" },
      ready: { buy: false, open: false, reveal: true, board: "is-ready" },
      resolved: { buy: true, open: false, reveal: false, board: "is-resolved" }
    };

    const view = config[stage];
    ui.buyPack.hidden = !view.buy;
    ui.openPack.hidden = !view.open;
    ui.revealAll.hidden = !view.reveal;
    const bonusPacks = getBonusPacks();
    ui.buyPack.textContent = bonusPacks > 0 ? `Usar sobre bonus (${bonusPacks})` : (stage === "resolved" ? "Comprar otro sobre" : "Comprar sobre");
    ui.boosterDisplay.className = `booster-display ${view.board}`;
    ui.packCards.classList.toggle("is-live", stage === "ready" || stage === "resolved");

    ui.packSlots.forEach((slot, index) => {
      slot.className = "pack-slot";
      slot.style.removeProperty("--deal-delay");
      slot.replaceChildren();

      if (!(stage === "ready" || stage === "resolved") || !currentPack[index]) {
        slot.classList.add("is-empty");
        return;
      }

      slot.style.setProperty("--deal-delay", `${index * 110}ms`);
      slot.innerHTML = packCardHtml(currentPack[index], index);
      const button = slot.querySelector("[data-reveal-card]");
      if (stage !== "ready") button.disabled = true;
      button?.addEventListener("click", () => revealCard(index));
      slot.classList.add("is-dealt");
    });
  }

  function purchasePack() {
    if (!["idle", "resolved"].includes(stage)) {
      setPackMessage("Termina la apertura actual.", "Revela las tres cartas antes de pasar al siguiente sobre.");
      return;
    }

    const bonusPacks = getBonusPacks();
    const usingBonus = bonusPacks > 0;

    if (!usingBonus && state.coins < PACK_COST) {
      setPackMessage("JCOIN insuficiente.", "Vende cartas desde el álbum para recuperar saldo o gana una partida de UNO para conseguir un sobre bonus.");
      return;
    }

    if (usingBonus) {
      setBonusPacks(bonusPacks - 1);
    } else {
      state.coins -= PACK_COST;
    }

    currentPack = generatePack();
    revealed = [false, false, false];
    storedCurrentPack = false;
    stage = "sealed";
    persist();
    updateEconomy();
    renderOpening();
    if (usingBonus) {
      setPackMessage("Sobre bonus listo.", "Este sobre viene de una victoria en UNO. Pulsa “Abrir sobre” para rasgarlo.");
    } else {
      setPackMessage("Sobre listo.", "Pulsa “Abrir sobre” para rasgar la parte superior y sacar las cartas.");
    }
  }

  function openPack() {
    if (stage !== "sealed") return;
    stage = "tearing";
    persist();
    renderOpening();
    setPackMessage("Abriendo sobre...", "Preparando las cartas para la revelación.");
    clearTimeout(tearTimer);
    tearTimer = window.setTimeout(() => {
      stage = "ready";
      persist();
      renderOpening();
      setPackMessage("Tres cartas listas.", "Pulsa sobre cada reverso para darles la vuelta o usa “Revelar todo”.");
    }, 980);
  }

  function storeCurrentPack() {
    if (storedCurrentPack) return;
    currentPack.forEach(card => {
      state.collection[card.id] = (state.collection[card.id] || 0) + 1;
    });
    state.totalOpened += 1;
    storedCurrentPack = true;
    if (currentPack[0]) state.selectedCardId = currentPack[0].id;
    persist();
    updateEconomy();
    renderAlbum();
  }

  function finishPack() {
    storeCurrentPack();
    stage = "resolved";
    persist();

    const highest = currentPack.reduce((best, card) => {
      if (!best) return card;
      return rarityConfig[card.rarity].value > rarityConfig[best.rarity].value ? card : best;
    }, null);

    if (highest?.rarity === "legendary") {
      setPackMessage("Legendaria conseguida.", `${highest.name} entra en el álbum. Este sobre ha merecido la pena.`);
    } else if (highest?.rarity === "epic") {
      setPackMessage("Apertura completada.", `Has conseguido una carta épica: ${highest.name}. Ya está guardada en el álbum.`);
    } else {
      setPackMessage("Apertura completada.", "Las tres cartas se han archivado correctamente en el álbum.");
    }
    renderOpening();
  }

  function revealCard(index) {
    if (stage !== "ready" || revealed[index]) return;
    revealed[index] = true;
    persist();
    renderOpening();

    const card = currentPack[index];
    if (card?.rarity === "legendary") {
      setPackMessage("Brillo legendario.", `${card.name} ha aparecido en el sobre.`);
    } else if (card?.rarity === "epic") {
      setPackMessage("Carta épica revelada.", `${card.name} se une a la tirada actual.`);
    }

    if (revealed.every(Boolean)) {
      window.setTimeout(finishPack, 420);
    }
  }

  function revealAllSequentially() {
    if (stage !== "ready") return;
    let delay = 0;
    revealed.forEach((isRevealed, index) => {
      if (isRevealed) return;
      window.setTimeout(() => revealCard(index), delay);
      delay += 180;
    });
  }

  function selectCard(cardId) {
    state.selectedCardId = cardId;
    persist();
    renderAlbum();
  }

  function renderAlbum() {
    const pageCount = Math.ceil(pool.length / 9);
    state.albumPage = Math.max(0, Math.min(state.albumPage, pageCount - 1));
    if (ui.pageIndicator) ui.pageIndicator.textContent = `${state.albumPage + 1} / ${pageCount}`;
    ui.albumPrev.disabled = state.albumPage <= 0;
    ui.albumNext.disabled = state.albumPage >= pageCount - 1;

    const start = state.albumPage * 9;
    const cards = pool.slice(start, start + 9);
    const fragment = document.createDocumentFragment();

    cards.forEach(card => {
      const count = countCopies(card.id);
      const button = document.createElement("button");
      button.type = "button";
      button.className = `album-card-button${state.selectedCardId === card.id ? " is-selected" : ""}`;
      button.innerHTML = cardFaceHtml(card, count);
      button.setAttribute("aria-label", `${card.name}. ${count} copias.`);
      if (count === 0) button.classList.add("is-ghost");
      const rendered = button.querySelector(".jcard");
      if (count === 0) rendered?.classList.add("jcard--ghost");
      button.addEventListener("click", () => selectCard(card.id));
      fragment.appendChild(button);
    });

    for (let i = cards.length; i < 9; i += 1) {
      const empty = document.createElement("div");
      empty.className = "empty-slot";
      empty.innerHTML = `<span>Vacío</span>`;
      fragment.appendChild(empty);
    }

    ui.albumGrid.replaceChildren(fragment);
    renderDetail();
  }

  function renderDetail() {
    const card = getCard(state.selectedCardId);
    const count = countCopies(card.id);
    ui.detailCard.innerHTML = cardFaceHtml(card, count);
    if (count === 0) ui.detailCard.querySelector(".jcard")?.classList.add("jcard--ghost");
    ui.detailName.textContent = card.name;
    ui.detailRarity.textContent = rarityLabel(card.rarity);
    ui.detailSerial.textContent = `${card.serial} / ${card.edition}`;
    ui.detailValue.textContent = `${card.value} JCOIN`;
    ui.detailCount.textContent = `${count} copia${count === 1 ? "" : "s"}`;
    ui.sellOne.disabled = count <= 0;
    ui.sellDupes.disabled = count <= 1;
  }

  function sellCard(mode) {
    const card = getCard(state.selectedCardId);
    const count = countCopies(card.id);
    if (count <= 0) return;

    if (mode === "one") {
      state.collection[card.id] = count - 1;
      state.coins += card.value;
      if (state.collection[card.id] <= 0) delete state.collection[card.id];
      setPackMessage("Venta completada.", `Has vendido una copia de ${card.name}.`);
    }

    if (mode === "dupes" && count > 1) {
      const soldCopies = count - 1;
      state.collection[card.id] = 1;
      state.coins += soldCopies * card.value;
      setPackMessage("Duplicadas vendidas.", `Has vendido ${soldCopies} copia${soldCopies === 1 ? "" : "s"} de ${card.name}.`);
    }

    persist();
    updateEconomy();
    renderAlbum();
  }

  function switchPanel(target) {
    ui.tabs.forEach(tab => {
      const active = tab.dataset.panelTarget === target;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
    });
    ui.panels.forEach(panel => {
      panel.hidden = panel.dataset.panel !== target;
    });
    if (target === "album") renderAlbum();
  }

  function bindEvents() {
    ui.buyPack.addEventListener("click", purchasePack);
    ui.openPack.addEventListener("click", openPack);
    ui.revealAll.addEventListener("click", revealAllSequentially);
    ui.albumPrev.addEventListener("click", () => {
      state.albumPage = Math.max(0, state.albumPage - 1);
      persist();
      renderAlbum();
    });
    ui.albumNext.addEventListener("click", () => {
      const pageCount = Math.ceil(pool.length / 9);
      state.albumPage = Math.min(pageCount - 1, state.albumPage + 1);
      persist();
      renderAlbum();
    });
    ui.sellOne.addEventListener("click", () => sellCard("one"));
    ui.sellDupes.addEventListener("click", () => sellCard("dupes"));
    ui.tabs.forEach(tab => tab.addEventListener("click", () => switchPanel(tab.dataset.panelTarget)));
  }

  bindEvents();
  updateEconomy();
  renderOpening();
  renderAlbum();
  switchPanel("opening");

  if (stage === "idle" && currentPack.length === 0) {
    setPackMessage("Compra un sobre para comenzar.", "El contenido se guardará en el álbum cuando la revelación termine.");
  }
  if (stage === "sealed") {
    if (usingBonus) {
      setPackMessage("Sobre bonus listo.", "Este sobre viene de una victoria en UNO. Pulsa “Abrir sobre” para rasgarlo.");
    } else {
      setPackMessage("Sobre listo.", "Pulsa “Abrir sobre” para rasgar la parte superior y sacar las cartas.");
    }
  }
  if (stage === "ready") {
    setPackMessage("Tres cartas listas.", "Pulsa sobre cada reverso para darles la vuelta o usa “Revelar todo”.");
  }
  if (stage === "resolved") {
    setPackMessage("Apertura completada.", "El último sobre ya se ha guardado en el álbum.");
  }
})();
