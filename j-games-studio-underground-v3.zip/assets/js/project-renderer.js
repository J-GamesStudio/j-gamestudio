(() => {
  const projects = Array.isArray(window.JGAMES_PROJECTS) ? window.JGAMES_PROJECTS : [];
  const root = document.body.dataset.root || "";
  const featured = projects.find(project => project.featured) || projects[0];

  const escapeHtml = value => String(value).replace(/[&<>'"]/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  }[character]));

  document.querySelectorAll("[data-project-count]").forEach(node => {
    node.textContent = String(projects.length).padStart(2, "0");
  });
  document.querySelectorAll("[data-project-label]").forEach(node => {
    node.textContent = projects.length === 1 ? "proyecto publicado" : "proyectos publicados";
  });
  document.querySelectorAll("[data-release-count]").forEach(node => {
    node.textContent = String(projects.filter(project => project.status === "Finalizado").length).padStart(2, "0");
  });

  if (featured) {
    document.querySelectorAll("[data-featured-title]").forEach(node => { node.textContent = featured.title; });
    document.querySelectorAll("[data-featured-link]").forEach(link => { link.href = `${root}${featured.url}`; });
    document.querySelectorAll("[data-featured-cover]").forEach(image => {
      image.src = `${root}${featured.cover}`;
      image.alt = `Portada de ${featured.title}`;
    });
    document.querySelectorAll("[data-featured-description]").forEach(node => { node.textContent = featured.description; });
    document.querySelectorAll("[data-featured-version]").forEach(node => { node.textContent = `V${featured.version}`; });
    document.querySelectorAll("[data-featured-category]").forEach(node => { node.textContent = featured.categoryLabel; });
  }

  const list = document.querySelector("[data-project-list]");
  if (!list) return;

  const base = list.dataset.base || "";
  const limit = Number(list.dataset.limit || 0);
  const featuredOnly = list.dataset.featured === "true";
  const excludeFeatured = list.dataset.excludeFeatured === "true";
  const empty = document.querySelector("[data-project-empty]");

  function createProjectCard(project) {
    const article = document.createElement("article");
    article.className = "project-card project-card--banner project-card--minimal";
    article.dataset.reveal = "";
    article.dataset.projectGroup = project.group || "all";
    article.dataset.projectId = project.id;
    article.style.setProperty("--card-accent", project.accent || "#ee173b");
    const cover = project.cover ? `${base}${project.cover}` : "";

    article.innerHTML = `
      <a class="project-card__link" href="${base}${escapeHtml(project.url)}" aria-label="Jugar ${escapeHtml(project.title)}">
        <div class="project-card__visual">
          ${cover ? `<img class="project-card__image" src="${escapeHtml(cover)}" alt="Banner de ${escapeHtml(project.title)}" loading="lazy">` : ""}
          <span class="project-card__scrim" aria-hidden="true"></span>
          <span class="project-card__play" aria-hidden="true">
            <span class="project-card__play-button"><i></i></span>
            <span class="project-card__play-label">Jugar</span>
          </span>
          <span class="project-card__edge project-card__edge--top" aria-hidden="true"></span>
          <span class="project-card__edge project-card__edge--bottom" aria-hidden="true"></span>
        </div>
      </a>`;
    return article;
  }

  let visible = projects.filter(project => {
    if (featuredOnly && !project.featured) return false;
    if (excludeFeatured && project.featured) return false;
    return true;
  });
  if (limit > 0) visible = visible.slice(0, limit);

  list.replaceChildren(...visible.map(createProjectCard));
  list.classList.toggle("is-single", visible.length === 1);
  if (empty) empty.hidden = visible.length > 0;

  requestAnimationFrame(() => {
    list.querySelectorAll("[data-reveal]").forEach(element => element.classList.add("is-visible"));
  });

  document.dispatchEvent(new CustomEvent("jgs:projects-rendered", { detail: { list, projects: visible } }));
})();
