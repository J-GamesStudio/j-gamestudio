(() => {
  const WIDTH = 960;
  const HEIGHT = 540;
  const WIN_SCORE = 7;
  const CREDIT_COST = 100;
  const STATS_KEY = "jgs-pong-stats";

  const canvas = document.getElementById("pong-canvas");
  const context = canvas?.getContext("2d");
  if (!canvas || !context) return;

  const ui = {
    balance: document.getElementById("pong-balance"),
    credit: document.getElementById("pong-credit"),
    wins: document.getElementById("pong-wins"),
    bestRally: document.getElementById("pong-best-rally"),
    overlay: document.getElementById("pong-overlay"),
    overlayKicker: document.getElementById("pong-overlay-kicker"),
    overlayTitle: document.getElementById("pong-overlay-title"),
    overlayCopy: document.getElementById("pong-overlay-copy"),
    screenCoinButton: document.getElementById("screen-coin-button"),
    countdown: document.getElementById("pong-countdown"),
    pointFlash: document.getElementById("pong-point-flash"),
    coinSlot: document.getElementById("coin-slot-button"),
    coinMessage: document.getElementById("coin-message"),
    pause: document.getElementById("pause-button"),
    sound: document.getElementById("sound-button"),
    touchUp: document.getElementById("touch-up-button"),
    touchDown: document.getElementById("touch-down-button")
  };

  const safeParse = value => {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === "object" ? parsed : null;
    } catch {
      return null;
    }
  };

  const loadStats = () => {
    try {
      const parsed = safeParse(localStorage.getItem(STATS_KEY) || "");
      return {
        wins: Number.isFinite(parsed?.wins) ? Math.max(0, parsed.wins) : 0,
        losses: Number.isFinite(parsed?.losses) ? Math.max(0, parsed.losses) : 0,
        bestRally: Number.isFinite(parsed?.bestRally) ? Math.max(0, parsed.bestRally) : 0
      };
    } catch {
      return { wins: 0, losses: 0, bestRally: 0 };
    }
  };

  const saveStats = () => {
    try {
      localStorage.setItem(STATS_KEY, JSON.stringify(state.stats));
    } catch {
      // The game remains playable when storage is restricted.
    }
  };

  const economy = window.JGS_ECONOMY || {
    getBalance() {
      try {
        const parsed = safeParse(localStorage.getItem("jgs-cartas-state") || "") || {};
        return Number.isFinite(parsed.coins) ? Math.max(0, parsed.coins) : 1000;
      } catch {
        return 1000;
      }
    },
    spend(amount) {
      const balance = this.getBalance();
      if (balance < amount) return false;
      try {
        const parsed = safeParse(localStorage.getItem("jgs-cartas-state") || "") || {};
        localStorage.setItem("jgs-cartas-state", JSON.stringify({ ...parsed, coins: balance - amount }));
      } catch {
        return false;
      }
      return true;
    }
  };

  const state = {
    mode: "attract",
    playerScore: 0,
    cpuScore: 0,
    credit: 0,
    lastTime: performance.now(),
    countdownEnds: 0,
    pointEnds: 0,
    nextServeDirection: 1,
    coinLocked: false,
    soundEnabled: true,
    pointerActive: false,
    pointerTarget: HEIGHT / 2,
    rally: 0,
    trail: [],
    keys: { up: false, down: false },
    stats: loadStats(),
    player: { x: 42, y: HEIGHT / 2 - 55, width: 14, height: 110, speed: 540 },
    cpu: { x: WIDTH - 56, y: HEIGHT / 2 - 55, width: 14, height: 110, speed: 385 },
    ball: { x: WIDTH / 2, y: HEIGHT / 2, radius: 8, vx: 330, vy: 120, speed: 350 },
    audioContext: null
  };

  function updateUi() {
    ui.balance.textContent = String(economy.getBalance());
    ui.credit.textContent = String(state.credit);
    ui.wins.textContent = String(state.stats.wins);
    ui.bestRally.textContent = String(state.stats.bestRally);
    ui.sound.textContent = state.soundEnabled ? "Sonido ON" : "Sonido OFF";
    ui.pause.textContent = state.mode === "paused" ? "Continuar" : "Pausa";
  }

  function showOverlay({ kicker, title, copy, button = "", buttonVisible = false }) {
    ui.overlayKicker.textContent = kicker;
    ui.overlayTitle.textContent = title;
    ui.overlayCopy.textContent = copy;
    ui.screenCoinButton.textContent = button;
    ui.screenCoinButton.hidden = !buttonVisible;
    ui.overlay.hidden = false;
  }

  function hideOverlay() {
    ui.overlay.hidden = true;
  }

  function ensureAudio() {
    if (!state.soundEnabled) return null;
    if (!state.audioContext) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return null;
      state.audioContext = new AudioContextClass();
    }
    if (state.audioContext.state === "suspended") state.audioContext.resume();
    return state.audioContext;
  }

  function beep(frequency, duration = .05, type = "square", volume = .04, delay = 0) {
    const audio = ensureAudio();
    if (!audio) return;
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    const start = audio.currentTime + delay;
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(volume, start);
    gain.gain.exponentialRampToValueAtTime(.0001, start + duration);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start(start);
    oscillator.stop(start + duration);
  }

  function playCoinSound() {
    beep(330, .08, "square", .05);
    beep(520, .11, "square", .045, .09);
    beep(760, .12, "square", .04, .2);
  }

  function playHitSound(isPaddle) {
    beep(isPaddle ? 330 : 180, .04, "square", .026);
  }

  function playScoreSound(playerScored) {
    if (playerScored) {
      beep(420, .08, "square", .04);
      beep(650, .12, "square", .04, .09);
    } else {
      beep(160, .1, "sawtooth", .035);
      beep(95, .18, "sawtooth", .03, .1);
    }
  }

  function resetPaddles() {
    state.player.y = HEIGHT / 2 - state.player.height / 2;
    state.cpu.y = HEIGHT / 2 - state.cpu.height / 2;
    state.pointerTarget = HEIGHT / 2;
  }

  function resetBall(direction = Math.random() > .5 ? 1 : -1, demo = false) {
    state.ball.x = WIDTH / 2;
    state.ball.y = HEIGHT / 2 + (Math.random() - .5) * 80;
    state.ball.speed = demo ? 285 : 350;
    const angle = (Math.random() * .7 - .35);
    state.ball.vx = Math.cos(angle) * state.ball.speed * direction;
    state.ball.vy = Math.sin(angle) * state.ball.speed;
    state.rally = 0;
    state.trail.length = 0;
  }

  function startMatch() {
    state.credit = 0;
    state.playerScore = 0;
    state.cpuScore = 0;
    state.mode = "countdown";
    state.countdownEnds = performance.now() + 3200;
    resetPaddles();
    resetBall(Math.random() > .5 ? 1 : -1);
    hideOverlay();
    ui.countdown.hidden = false;
    ui.coinMessage.textContent = "Crédito aceptado. Preparando servicio.";
    updateUi();
  }

  function insertCoin() {
    if (state.coinLocked || !["attract", "gameover"].includes(state.mode)) return;
    state.coinLocked = true;

    if (!economy.spend(CREDIT_COST)) {
      showOverlay({
        kicker: "JGS ARCADE SYSTEM",
        title: "NO CREDIT",
        copy: "Necesitas 100 JCOIN. Vende cartas en CARTAS para recuperar saldo.",
        button: "Revisar saldo",
        buttonVisible: true
      });
      ui.coinMessage.textContent = "Saldo insuficiente: necesitas 100 JCOIN.";
      updateUi();
      window.setTimeout(() => { state.coinLocked = false; }, 450);
      return;
    }

    state.credit = 1;
    updateUi();
    playCoinSound();
    showOverlay({
      kicker: "COIN ACCEPTED",
      title: "CREDIT 1",
      copy: "100 JCOIN INSERTADAS",
      buttonVisible: false
    });
    ui.coinMessage.textContent = "Moneda aceptada. La partida está arrancando.";
    window.setTimeout(() => {
      state.coinLocked = false;
      startMatch();
    }, 920);
  }

  function finishMatch(playerWon) {
    state.mode = "gameover";
    state.stats[playerWon ? "wins" : "losses"] += 1;
    state.stats.bestRally = Math.max(state.stats.bestRally, state.rally);
    saveStats();
    updateUi();
    ui.countdown.hidden = true;
    ui.pointFlash.hidden = true;
    showOverlay({
      kicker: playerWon ? "PLAYER ONE WINS" : "CPU WINS",
      title: playerWon ? "YOU WIN" : "GAME OVER",
      copy: `${state.playerScore.toString().padStart(2,"0")} — ${state.cpuScore.toString().padStart(2,"0")} · INSERT COIN TO REPLAY`,
      button: "Insertar 100 JCOIN",
      buttonVisible: true
    });
    ui.coinMessage.textContent = playerWon
      ? "Victoria registrada. Inserta otra moneda para volver a jugar."
      : "La CPU se lleva la partida. Inserta otra moneda para reintentar.";
    beep(playerWon ? 720 : 120, .18, playerWon ? "square" : "sawtooth", .045);
    beep(playerWon ? 920 : 80, .24, playerWon ? "square" : "sawtooth", .035, .18);
  }

  function registerPoint(playerScored) {
    if (playerScored) state.playerScore += 1;
    else state.cpuScore += 1;
    state.stats.bestRally = Math.max(state.stats.bestRally, state.rally);
    saveStats();
    playScoreSound(playerScored);
    state.mode = "point";
    state.pointEnds = performance.now() + 1150;
    state.nextServeDirection = playerScored ? -1 : 1;
    ui.pointFlash.textContent = playerScored ? "PLAYER POINT" : "CPU POINT";
    ui.pointFlash.hidden = false;

    if (state.playerScore >= WIN_SCORE || state.cpuScore >= WIN_SCORE) {
      state.pointEnds = performance.now() + 1250;
    }
  }

  function updatePaddleControls(dt) {
    let direction = 0;
    if (state.keys.up) direction -= 1;
    if (state.keys.down) direction += 1;

    if (direction !== 0) {
      state.pointerActive = false;
      state.player.y += direction * state.player.speed * dt;
    } else if (state.pointerActive) {
      const targetY = state.pointerTarget - state.player.height / 2;
      const difference = targetY - state.player.y;
      const maxMove = state.player.speed * 1.35 * dt;
      state.player.y += Math.max(-maxMove, Math.min(maxMove, difference));
    }

    state.player.y = Math.max(18, Math.min(HEIGHT - 18 - state.player.height, state.player.y));
  }

  function updateCpu(dt, demo = false) {
    const ballApproaching = demo || state.ball.vx > 0;
    const centerTarget = HEIGHT / 2 - state.cpu.height / 2;
    const projected = state.ball.y - state.cpu.height / 2;
    const noise = Math.sin(performance.now() / 420) * (demo ? 9 : 20);
    const target = ballApproaching ? projected + noise : centerTarget;
    const speed = demo ? 310 : state.cpu.speed + Math.min(70, (state.playerScore + state.cpuScore) * 4);
    const difference = target - state.cpu.y;
    const maxMove = speed * dt;
    state.cpu.y += Math.max(-maxMove, Math.min(maxMove, difference));
    state.cpu.y = Math.max(18, Math.min(HEIGHT - 18 - state.cpu.height, state.cpu.y));
  }

  function updateDemoPlayer(dt) {
    const target = state.ball.vx < 0 ? state.ball.y - state.player.height / 2 : HEIGHT / 2 - state.player.height / 2;
    const difference = target - state.player.y;
    const maxMove = 300 * dt;
    state.player.y += Math.max(-maxMove, Math.min(maxMove, difference));
  }

  function paddleCollision(paddle, movingLeft) {
    const ball = state.ball;
    const horizontalHit = movingLeft
      ? ball.x - ball.radius <= paddle.x + paddle.width && ball.x > paddle.x
      : ball.x + ball.radius >= paddle.x && ball.x < paddle.x + paddle.width;
    const verticalHit = ball.y + ball.radius >= paddle.y && ball.y - ball.radius <= paddle.y + paddle.height;
    if (!horizontalHit || !verticalHit) return false;

    const relative = (ball.y - (paddle.y + paddle.height / 2)) / (paddle.height / 2);
    const clamped = Math.max(-.92, Math.min(.92, relative));
    ball.speed = Math.min(760, ball.speed * 1.055 + 7);
    const angle = clamped * 1.02;
    ball.vx = Math.cos(angle) * ball.speed * (movingLeft ? 1 : -1);
    ball.vy = Math.sin(angle) * ball.speed;
    ball.x = movingLeft ? paddle.x + paddle.width + ball.radius + 1 : paddle.x - ball.radius - 1;
    state.rally += 1;
    state.stats.bestRally = Math.max(state.stats.bestRally, state.rally);
    playHitSound(true);
    return true;
  }

  function updateBall(dt, demo = false) {
    const ball = state.ball;
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;

    state.trail.unshift({ x: ball.x, y: ball.y });
    if (state.trail.length > 9) state.trail.pop();

    if (ball.y - ball.radius <= 12) {
      ball.y = 12 + ball.radius;
      ball.vy = Math.abs(ball.vy);
      playHitSound(false);
    }
    if (ball.y + ball.radius >= HEIGHT - 12) {
      ball.y = HEIGHT - 12 - ball.radius;
      ball.vy = -Math.abs(ball.vy);
      playHitSound(false);
    }

    if (ball.vx < 0) paddleCollision(state.player, true);
    if (ball.vx > 0) paddleCollision(state.cpu, false);

    if (ball.x < -30) {
      if (demo) resetBall(1, true);
      else registerPoint(false);
    }
    if (ball.x > WIDTH + 30) {
      if (demo) resetBall(-1, true);
      else registerPoint(true);
    }
  }

  function update(dt, now) {
    if (state.mode === "attract" || state.mode === "gameover") {
      updateDemoPlayer(dt);
      updateCpu(dt, true);
      updateBall(dt, true);
      return;
    }

    if (state.mode === "countdown") {
      const remaining = state.countdownEnds - now;
      const count = Math.max(1, Math.ceil(remaining / 1000));
      ui.countdown.textContent = remaining <= 250 ? "GO" : String(count);
      if (remaining <= 0) {
        state.mode = "playing";
        ui.countdown.hidden = true;
        ui.coinMessage.textContent = "Partida activa. Primero en alcanzar 7 puntos.";
      }
      return;
    }

    if (state.mode === "paused") return;

    if (state.mode === "point") {
      if (now >= state.pointEnds) {
        ui.pointFlash.hidden = true;
        if (state.playerScore >= WIN_SCORE || state.cpuScore >= WIN_SCORE) {
          finishMatch(state.playerScore >= WIN_SCORE);
        } else {
          state.mode = "countdown";
          state.countdownEnds = now + 1700;
          resetPaddles();
          resetBall(state.nextServeDirection);
          ui.countdown.hidden = false;
        }
      }
      return;
    }

    if (state.mode === "playing") {
      updatePaddleControls(dt);
      updateCpu(dt);
      updateBall(dt);
    }
  }

  function drawBackground() {
    context.fillStyle = "#020304";
    context.fillRect(0, 0, WIDTH, HEIGHT);

    context.strokeStyle = "rgba(255,255,255,.026)";
    context.lineWidth = 1;
    for (let x = 0; x <= WIDTH; x += 48) {
      context.beginPath();
      context.moveTo(x, 0);
      context.lineTo(x, HEIGHT);
      context.stroke();
    }
    for (let y = 0; y <= HEIGHT; y += 48) {
      context.beginPath();
      context.moveTo(0, y);
      context.lineTo(WIDTH, y);
      context.stroke();
    }

    context.fillStyle = "rgba(255,255,255,.46)";
    for (let y = 30; y < HEIGHT - 20; y += 28) context.fillRect(WIDTH / 2 - 2, y, 4, 14);
  }

  function drawText() {
    context.textAlign = "center";
    context.textBaseline = "top";
    context.font = "900 62px monospace";
    context.fillStyle = "rgba(255,255,255,.95)";
    context.shadowColor = "rgba(255,255,255,.62)";
    context.shadowBlur = 16;
    context.fillText(String(state.playerScore).padStart(2,"0"), WIDTH * .38, 34);
    context.fillStyle = "#ee173b";
    context.shadowColor = "rgba(238,23,59,.72)";
    context.fillText(String(state.cpuScore).padStart(2,"0"), WIDTH * .62, 34);

    context.shadowBlur = 0;
    context.font = "700 15px monospace";
    context.fillStyle = "rgba(255,255,255,.56)";
    context.fillText("PLAYER ONE", WIDTH * .25, 28);
    context.fillStyle = "rgba(238,23,59,.7)";
    context.fillText("CPU", WIDTH * .75, 28);

    context.textAlign = "left";
    context.textBaseline = "bottom";
    context.font = "12px monospace";
    context.fillStyle = "rgba(255,255,255,.38)";
    context.fillText("JGS ARCADE SYSTEM / UNIT 004", 24, HEIGHT - 18);
    context.textAlign = "right";
    context.fillText(`RALLY ${String(state.rally).padStart(2,"0")}`, WIDTH - 24, HEIGHT - 18);
  }

  function drawPaddles() {
    context.shadowBlur = 17;
    context.shadowColor = "rgba(255,255,255,.8)";
    context.fillStyle = "rgba(255,255,255,.14)";
    context.fillRect(state.player.x + 3, state.player.y, state.player.width, state.player.height);
    context.fillStyle = "#f5f2eb";
    context.fillRect(state.player.x, state.player.y, state.player.width, state.player.height);

    context.shadowColor = "rgba(238,23,59,.9)";
    context.fillStyle = "rgba(238,23,59,.18)";
    context.fillRect(state.cpu.x - 3, state.cpu.y, state.cpu.width, state.cpu.height);
    context.fillStyle = "#ee173b";
    context.fillRect(state.cpu.x, state.cpu.y, state.cpu.width, state.cpu.height);
    context.shadowBlur = 0;
  }

  function drawBall() {
    state.trail.forEach((point, index) => {
      const alpha = Math.max(0, .24 - index * .026);
      context.fillStyle = `rgba(255,255,255,${alpha})`;
      const size = Math.max(2, state.ball.radius * 1.4 - index * .7);
      context.fillRect(point.x - size / 2, point.y - size / 2, size, size);
    });
    context.shadowColor = "white";
    context.shadowBlur = 20;
    context.fillStyle = "#fff";
    context.fillRect(state.ball.x - state.ball.radius, state.ball.y - state.ball.radius, state.ball.radius * 2, state.ball.radius * 2);
    context.shadowBlur = 0;
  }

  function draw() {
    drawBackground();
    drawText();
    drawPaddles();
    drawBall();
  }

  function frame(now) {
    const delta = Math.min(.034, Math.max(0, (now - state.lastTime) / 1000));
    state.lastTime = now;
    update(delta, now);
    draw();
    updateUi();
    requestAnimationFrame(frame);
  }

  function setPointerTarget(clientY) {
    const rect = canvas.getBoundingClientRect();
    if (!rect.height) return;
    state.pointerTarget = ((clientY - rect.top) / rect.height) * HEIGHT;
    state.pointerActive = true;
  }

  function togglePause() {
    if (state.mode === "playing") {
      state.mode = "paused";
      showOverlay({ kicker: "SYSTEM PAUSED", title: "PAUSE", copy: "PULSA P O CONTINUAR", buttonVisible: false });
      ui.coinMessage.textContent = "Partida en pausa.";
    } else if (state.mode === "paused") {
      state.mode = "playing";
      hideOverlay();
      ui.coinMessage.textContent = "Partida reanudada.";
    }
    updateUi();
  }

  function bindHoldButton(button, direction) {
    const start = event => {
      event.preventDefault();
      state.pointerActive = false;
      state.keys[direction] = true;
    };
    const stop = event => {
      event.preventDefault();
      state.keys[direction] = false;
    };
    button.addEventListener("pointerdown", start);
    button.addEventListener("pointerup", stop);
    button.addEventListener("pointercancel", stop);
    button.addEventListener("pointerleave", stop);
  }

  function bindEvents() {
    ui.coinSlot.addEventListener("click", insertCoin);
    ui.screenCoinButton.addEventListener("click", insertCoin);
    ui.pause.addEventListener("click", togglePause);
    ui.sound.addEventListener("click", () => {
      state.soundEnabled = !state.soundEnabled;
      if (state.soundEnabled) beep(440, .06, "square", .035);
      updateUi();
    });

    window.addEventListener("keydown", event => {
      if (["ArrowUp", "ArrowDown", " "].includes(event.key)) event.preventDefault();
      if (["w", "W", "ArrowUp"].includes(event.key)) state.keys.up = true;
      if (["s", "S", "ArrowDown"].includes(event.key)) state.keys.down = true;
      if (["p", "P", "Escape"].includes(event.key)) togglePause();
      if ((event.key === " " || event.key === "Enter") && ["attract", "gameover"].includes(state.mode)) insertCoin();
    });
    window.addEventListener("keyup", event => {
      if (["w", "W", "ArrowUp"].includes(event.key)) state.keys.up = false;
      if (["s", "S", "ArrowDown"].includes(event.key)) state.keys.down = false;
    });

    canvas.addEventListener("pointermove", event => {
      if (state.mode === "playing") setPointerTarget(event.clientY);
    });
    canvas.addEventListener("pointerdown", event => {
      if (state.mode === "playing") setPointerTarget(event.clientY);
    });

    bindHoldButton(ui.touchUp, "up");
    bindHoldButton(ui.touchDown, "down");

    document.addEventListener("visibilitychange", () => {
      if (document.hidden && state.mode === "playing") togglePause();
    });
  }

  resetPaddles();
  resetBall(1, true);
  bindEvents();
  updateUi();
  showOverlay({
    kicker: "JGS ARCADE PRESENTS",
    title: "INSERT COIN",
    copy: "100 JCOIN / 1 PARTIDA",
    button: "Insertar 100 JCOIN",
    buttonVisible: true
  });
  requestAnimationFrame(frame);
})();
