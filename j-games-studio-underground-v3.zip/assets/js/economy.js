(() => {
  "use strict";
  const PLATFORM_KEY = "jgs-platform-v3";
  const SESSION_KEY = "jgs-platform-session-v3";
  const ACTIVE_KEY = "jgs-platform-active-v3";
  const CARTAS_KEY = "jgs-cartas-state";
  const BONUS_KEY = "jgs-bonus-packs";
  const WINDOW_PREFIX = "JGS_PLATFORM_V3:";
  const SIGNUP_BONUS = 1000;
  const FIRST_PLAY_POINTS = 100;
  const REPEAT_PLAY_POINTS = 50;
  const PLAY_COOLDOWN = 15 * 60 * 1000;
  const listeners = new Set();

  const safeParse = (value, fallback = null) => { try { return JSON.parse(value) ?? fallback; } catch { return fallback; } };
  const read = key => { try { return localStorage.getItem(key); } catch { return null; } };
  const write = (key, value) => { try { localStorage.setItem(key, value); return true; } catch { return false; } };
  const sessionRead = key => { try { return sessionStorage.getItem(key); } catch { return null; } };
  const sessionWrite = (key, value) => { try { sessionStorage.setItem(key, value); return true; } catch { return false; } };
  const nowIso = () => new Date().toISOString();
  const clampInt = (value, min = 0) => Math.max(min, Math.floor(Number(value) || 0));
  const randomId = () => String(Math.floor(1 + Math.random() * 99999)).padStart(5, "0");
  const randomSalt = () => { const bytes=new Uint8Array(16); if(globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes); else for(let i=0;i<bytes.length;i++) bytes[i]=Math.floor(Math.random()*256); return Array.from(bytes,b=>b.toString(16).padStart(2,"0")).join(""); };
  const toHex = buffer => Array.from(new Uint8Array(buffer), b => b.toString(16).padStart(2,"0")).join("");
  async function hashSecret(secret, salt) {
    const bytes = new TextEncoder().encode(`${salt}:${secret}`);
    if (globalThis.crypto?.subtle) return toHex(await globalThis.crypto.subtle.digest("SHA-256", bytes));
    let hash = 2166136261;
    for (const byte of bytes) { hash ^= byte; hash = Math.imul(hash, 16777619); }
    return `fallback-${(hash >>> 0).toString(16)}`;
  }

  const blank = () => ({ version:3, profile:null, wallet:{jcoins:0,score:0}, history:[], plays:{}, settings:{}, createdAt:null, updatedAt:null });
  function loadWindowFallback(){
    if (!window.name?.startsWith(WINDOW_PREFIX)) return null;
    return safeParse(window.name.slice(WINDOW_PREFIX.length), null);
  }
  function normalize(raw){
    const value = raw && typeof raw === "object" ? raw : blank();
    return {
      version:3,
      profile:value.profile && typeof value.profile === "object" ? value.profile : null,
      wallet:{jcoins:clampInt(value.wallet?.jcoins),score:clampInt(value.wallet?.score)},
      history:Array.isArray(value.history) ? value.history.slice(0,250) : [],
      plays:value.plays && typeof value.plays === "object" ? value.plays : {},
      settings:value.settings && typeof value.settings === "object" ? value.settings : {},
      createdAt:value.createdAt || null,
      updatedAt:value.updatedAt || null
    };
  }
  let state = normalize(safeParse(read(PLATFORM_KEY), null) || loadWindowFallback() || blank());
  let active = sessionRead(SESSION_KEY) === "1" || read(ACTIVE_KEY) === "1";

  function persist(){
    state.updatedAt = nowIso();
    write(PLATFORM_KEY, JSON.stringify(state));
    try { window.name = WINDOW_PREFIX + JSON.stringify(state); } catch {}
    listeners.forEach(fn => { try { fn(snapshot()); } catch {} });
    window.dispatchEvent(new CustomEvent("jgs:platform-change", { detail:snapshot() }));
  }
  function snapshot(){ return JSON.parse(JSON.stringify({ ...state, active, balance: active ? state.wallet.jcoins : 0, score: active ? state.wallet.score : 0 })); }
  function contextName(){
    const match = location.pathname.match(/\/projects\/([^/]+)/);
    if (!match) return "J-GAMES STUDIO";
    const names = {"detective-black":"DETECTIVE BLACK","tri-angle-ship":"TRI-ANGLE SHIP","pong":"PONG","uno":"UNO","cartas":"CARTAS","dados":"DADOS","nave":"NAVE"};
    return names[match[1]] || match[1].toUpperCase();
  }
  function pushHistory(kind, amount, source, reason, balance){
    state.history.unshift({ id:`TX-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, kind, amount, source:source || contextName(), reason:reason || "Movimiento", balance, at:nowIso() });
    state.history = state.history.slice(0,250);
  }
  function requireProfile(){ return Boolean(active && state.profile); }

  async function register({nick,email,password,keepSignedIn=true}){
    const cleanNick = String(nick || "").trim().slice(0,24);
    const cleanEmail = String(email || "").trim().toLowerCase().slice(0,120);
    const secret = String(password || "");
    if (state.profile) throw new Error("Ya existe un perfil local en este navegador.");
    if (cleanNick.length < 3) throw new Error("El nick debe tener al menos 3 caracteres.");
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) throw new Error("Introduce un e-mail válido.");
    if (secret.length < 6) throw new Error("La clave local debe tener al menos 6 caracteres.");
    const salt = randomSalt();
    const passwordHash = await hashSecret(secret, salt);
    const created = nowIso();
    state = blank();
    state.profile = { id:randomId(), nick:cleanNick, email:cleanEmail, salt, passwordHash, keepSignedIn:Boolean(keepSignedIn), createdAt:created };
    state.wallet = { jcoins:SIGNUP_BONUS, score:0 };
    state.createdAt = created;
    active = true;
    sessionWrite(SESSION_KEY, "1");
    write(ACTIVE_KEY, keepSignedIn ? "1" : "0");
    pushHistory("jcoins", SIGNUP_BONUS, "J-GAMES STUDIO", "BONUS DE REGISTRO", SIGNUP_BONUS);
    persist();
    return snapshot();
  }
  async function login({email,password}){
    if (!state.profile) throw new Error("No existe un perfil local en este navegador.");
    if (String(email || "").trim().toLowerCase() !== state.profile.email) throw new Error("El e-mail no coincide con el perfil local.");
    const test = await hashSecret(String(password || ""), state.profile.salt);
    if (test !== state.profile.passwordHash) throw new Error("Clave local incorrecta.");
    active = true; sessionWrite(SESSION_KEY,"1"); write(ACTIVE_KEY,"1"); persist(); return snapshot();
  }
  function logout(){ active = false; sessionWrite(SESSION_KEY,"0"); write(ACTIVE_KEY,"0"); persist(); }
  function deleteProfile(){ state = blank(); active=false; write(PLATFORM_KEY, JSON.stringify(state)); sessionWrite(SESSION_KEY,"0"); write(ACTIVE_KEY,"0"); persist(); }

  function setJcoins(next, source="J-GAMES STUDIO", reason="AJUSTE", shouldLog=true){
    if (!requireProfile()) return 0;
    const previous = state.wallet.jcoins;
    state.wallet.jcoins = clampInt(next);
    const delta = state.wallet.jcoins - previous;
    if (shouldLog && delta) pushHistory("jcoins", delta, source, reason, state.wallet.jcoins);
    persist(); return state.wallet.jcoins;
  }
  function addJcoins(amount, source=contextName(), reason="RECOMPENSA"){ return setJcoins(state.wallet.jcoins + clampInt(amount), source, reason, true); }
  function spendJcoins(amount, source=contextName(), reason="GASTO"){
    const cost = clampInt(amount);
    if (!requireProfile() || state.wallet.jcoins < cost) return false;
    setJcoins(state.wallet.jcoins - cost, source, reason, true); return true;
  }
  function addScore(amount, source=contextName(), reason="PARTIDA"){
    if (!requireProfile()) return 0;
    const points = clampInt(amount); if (!points) return state.wallet.score;
    state.wallet.score += points;
    pushHistory("score", points, source, reason, state.wallet.score);
    persist(); return state.wallet.score;
  }
  function recordPlay(gameId, gameName){
    if (!requireProfile()) return {awarded:0,reason:"no-profile"};
    const id = String(gameId || "unknown");
    const now = Date.now();
    const current = state.plays[id] || {count:0,lastAt:0};
    if (current.lastAt && now - current.lastAt < PLAY_COOLDOWN) return {awarded:0,reason:"cooldown",remaining:PLAY_COOLDOWN-(now-current.lastAt)};
    const first = current.count === 0;
    const awarded = first ? FIRST_PLAY_POINTS : REPEAT_PLAY_POINTS;
    state.plays[id] = {count:current.count+1,lastAt:now};
    state.wallet.score += awarded;
    pushHistory("score", awarded, gameName || contextName(), first ? "PRIMERA PARTIDA" : "NUEVA PARTIDA", state.wallet.score);
    persist();
    return {awarded,first,count:state.plays[id].count};
  }
  function getStats(){
    const plays = Object.values(state.plays);
    return { gamesPlayed:plays.filter(p=>p.count>0).length, totalSessions:plays.reduce((n,p)=>n+(p.count||0),0), transactions:state.history.length };
  }
  function adminAdjust({jcoins=0,score=0,reason="AJUSTE LOCAL"}={}){
    if (!state.profile) throw new Error("No existe un perfil local.");
    const jc = Math.trunc(Number(jcoins)||0), sc = Math.trunc(Number(score)||0);
    if (jc){ state.wallet.jcoins = clampInt(state.wallet.jcoins+jc); pushHistory("jcoins",jc,"ADMIN LOCAL",reason,state.wallet.jcoins); }
    if (sc){ state.wallet.score = clampInt(state.wallet.score+sc); pushHistory("score",sc,"ADMIN LOCAL",reason,state.wallet.score); }
    persist(); return snapshot();
  }

  // Compatibility with the existing games.
  const readCartas = () => safeParse(read(CARTAS_KEY), {}) || {};
  const getCartasState = defaults => ({ ...(defaults||{}), ...readCartas(), coins:requireProfile()?state.wallet.jcoins:0 });
  const saveCartasState = next => {
    const incoming = next && typeof next === "object" ? next : {};
    const desired = clampInt(incoming.coins);
    if (requireProfile() && desired !== state.wallet.jcoins) setJcoins(desired, "CARTAS", desired>state.wallet.jcoins?"VENTA / RECOMPENSA":"COMPRA DE SOBRE", true);
    const payload = {...incoming, coins:requireProfile()?state.wallet.jcoins:0};
    write(CARTAS_KEY, JSON.stringify(payload));
    return payload;
  };
  const getBonusPacks = () => clampInt(read(BONUS_KEY));
  const setBonusPacks = value => { const v=clampInt(value); write(BONUS_KEY,String(v)); return v; };

  window.JGS_PLATFORM = Object.freeze({
    snapshot, subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)}, register, login, logout, deleteProfile,
    isActive:requireProfile, getProfile:()=>requireProfile()?{...state.profile}:null, getBalance:()=>requireProfile()?state.wallet.jcoins:0,
    getScore:()=>requireProfile()?state.wallet.score:0, getHistory:(kind)=>state.history.filter(x=>!kind||x.kind===kind), getStats,
    addJcoins, spendJcoins, addScore, recordPlay, adminAdjust, exportData:()=>JSON.stringify(state,null,2)
  });
  window.JGS_ECONOMY = Object.freeze({
    getBalance:()=>requireProfile()?state.wallet.jcoins:0,
    spend:(amount)=>spendJcoins(amount,contextName(),"CRÉDITO DE JUEGO"),
    add:(amount)=>addJcoins(amount,contextName(),"RECOMPENSA DE JUEGO"),
    updateCoins:(amount)=>setJcoins(amount,contextName(),"AJUSTE DEL JUEGO",true),
    getCartasState,saveCartasState,getBonusPacks,setBonusPacks,
    addBonusPacks:(amount)=>setBonusPacks(getBonusPacks()+clampInt(amount))
  });
  persist();
})();